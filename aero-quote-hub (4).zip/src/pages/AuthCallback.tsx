import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Plane } from 'lucide-react';

const AuthCallback = () => {
  const [status, setStatus] = useState('Procesando autenticación...');
  const navigate = useNavigate();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        console.log('Processing auth callback, current URL:', window.location.href);
        
        // Get the URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        
        // Check if this is a password recovery
        const type = urlParams.get('type') || hashParams.get('type');
        const isRecovery = type === 'recovery';
        
        console.log('Auth callback type:', type);
        
        // Handle the session from URL
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Auth callback error:', error);
          setStatus('Error en la autenticación. Redirigiendo...');
          setTimeout(() => navigate('/auth'), 2000);
          return;
        }

        if (data.session) {
          console.log('Session established successfully');
          setStatus('¡Autenticación exitosa! Redirigiendo...');
          
          if (isRecovery) {
            // For password recovery, redirect to reset password page
            setTimeout(() => navigate('/reset-password'), 1000);
          } else {
            // For normal login/signup confirmation, redirect to main page
            setTimeout(() => navigate('/'), 1000);
          }
        } else {
          console.log('No session found, redirecting to auth');
          setStatus('No se pudo establecer la sesión. Redirigiendo...');
          setTimeout(() => navigate('/auth'), 2000);
        }
      } catch (error) {
        console.error('Unexpected error in auth callback:', error);
        setStatus('Error inesperado. Redirigiendo...');
        setTimeout(() => navigate('/auth'), 2000);
      }
    };

    handleAuthCallback();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-6">
          <Plane className="h-8 w-8 text-primary" />
          <h1 className="text-2xl font-bold">AeroSourcing</h1>
        </div>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="text-muted-foreground">{status}</p>
      </div>
    </div>
  );
};

export default AuthCallback;