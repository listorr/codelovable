import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plane, FileText, Package, Users, Plus, Search, Filter, AlertTriangle, Mail, LogOut } from "lucide-react";
import { RFQsList } from "@/components/RFQsList";
import { QuotesList } from "@/components/QuotesList";
import { SuppliersList } from "@/components/SuppliersList";
import { EmailProcessingSetup } from "@/components/EmailProcessingSetup";
import { TestEmailFlow } from "@/components/TestEmailFlow";
import { CreateRFQDialog } from "@/components/CreateRFQDialog";
import { CreateSupplierDialog } from "@/components/CreateSupplierDialog";
import { EmailConfigDialog } from "@/components/EmailConfigDialog";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";

const Index = () => {
  const [activeTab, setActiveTab] = useState("rfqs");
  const [showCreateRFQ, setShowCreateRFQ] = useState(false);
  const [showCreateSupplier, setShowCreateSupplier] = useState(false);
  const { user, signOut } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Plane className="h-8 w-8 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">AeroSourcing</h1>
              </div>
              <Badge variant="secondary" className="text-sm">
                Aviation Parts RFQ Platform
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Bienvenido, {user?.email}
              </span>
              <EmailConfigDialog />
              <Button 
                onClick={() => setShowCreateRFQ(true)}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                New RFQ
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowCreateSupplier(true)}
                className="gap-2"
              >
                <Users className="h-4 w-4" />
                Add Supplier
              </Button>
              <Button 
                variant="outline" 
                onClick={signOut}
                className="gap-2"
              >
                <LogOut className="h-4 w-4" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active RFQs</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">
                +2 from yesterday
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Quotes</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">34</div>
              <p className="text-xs text-muted-foreground">
                +5 from yesterday
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Suppliers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">156</div>
              <p className="text-xs text-muted-foreground">
                +12 this month
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AOG Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">3</div>
              <p className="text-xs text-muted-foreground">
                Urgent attention needed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="rfqs" className="gap-2">
              <FileText className="h-4 w-4" />
              RFQs
            </TabsTrigger>
            <TabsTrigger value="quotes" className="gap-2">
              <Package className="h-4 w-4" />
              Quotes
            </TabsTrigger>
            <TabsTrigger value="suppliers" className="gap-2">
              <Users className="h-4 w-4" />
              Suppliers
            </TabsTrigger>
            <TabsTrigger value="email" className="gap-2">
              <Mail className="h-4 w-4" />
              Email Processing
            </TabsTrigger>
            <TabsTrigger value="test" className="gap-2">
              🧪 Test Flow
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rfqs" className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search RFQs by part number, airline..." 
                  className="pl-10"
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filter
              </Button>
            </div>
            <RFQsList />
          </TabsContent>

          <TabsContent value="quotes" className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search quotes by supplier, part number..." 
                  className="pl-10"
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filter
              </Button>
            </div>
            <QuotesList />
          </TabsContent>

          <TabsContent value="suppliers" className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search suppliers by name, region..." 
                  className="pl-10"
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filter
              </Button>
            </div>
            <SuppliersList />
          </TabsContent>

          <TabsContent value="email" className="space-y-6">
            <EmailProcessingSetup />
          </TabsContent>

          <TabsContent value="test" className="space-y-6">
            <TestEmailFlow />
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      <CreateRFQDialog 
        open={showCreateRFQ} 
        onOpenChange={setShowCreateRFQ}
        onSuccess={() => setShowCreateRFQ(false)}
      />
      <CreateSupplierDialog open={showCreateSupplier} onOpenChange={setShowCreateSupplier} />
    </div>
  );
};

export default Index;
