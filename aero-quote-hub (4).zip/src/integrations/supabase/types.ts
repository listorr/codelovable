export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action_type: string
          created_at: string
          details: Json | null
          entity_id: string
          entity_type: string
          id: string
          user_id: string | null
        }
        Insert: {
          action_type: string
          created_at?: string
          details?: Json | null
          entity_id: string
          entity_type: string
          id?: string
          user_id?: string | null
        }
        Update: {
          action_type?: string
          created_at?: string
          details?: Json | null
          entity_id?: string
          entity_type?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      communication_history: {
        Row: {
          attachments: string[] | null
          communication_type: string
          content: string | null
          created_at: string
          email_thread_id: string | null
          id: string
          metadata: Json | null
          received_at: string | null
          rfq_id: string
          sent_at: string | null
          subject: string | null
          supplier_id: string
        }
        Insert: {
          attachments?: string[] | null
          communication_type: string
          content?: string | null
          created_at?: string
          email_thread_id?: string | null
          id?: string
          metadata?: Json | null
          received_at?: string | null
          rfq_id: string
          sent_at?: string | null
          subject?: string | null
          supplier_id: string
        }
        Update: {
          attachments?: string[] | null
          communication_type?: string
          content?: string | null
          created_at?: string
          email_thread_id?: string | null
          id?: string
          metadata?: Json | null
          received_at?: string | null
          rfq_id?: string
          sent_at?: string | null
          subject?: string | null
          supplier_id?: string
        }
        Relationships: []
      }
      email_config: {
        Row: {
          created_at: string
          from_email: string
          from_name: string
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          from_email?: string
          from_name?: string
          id?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          from_email?: string
          from_name?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      email_threads: {
        Row: {
          created_at: string
          id: string
          last_message_at: string | null
          rfq_id: string
          subject: string | null
          supplier_id: string
          thread_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          last_message_at?: string | null
          rfq_id: string
          subject?: string | null
          supplier_id: string
          thread_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          last_message_at?: string | null
          rfq_id?: string
          subject?: string | null
          supplier_id?: string
          thread_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_threads_rfq_id_fkey"
            columns: ["rfq_id"]
            isOneToOne: false
            referencedRelation: "rfqs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_threads_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      part_lines: {
        Row: {
          condition_req: Database["public"]["Enums"]["condition_type"] | null
          created_at: string
          id: string
          notes: string | null
          part_number: string
          quantity: number
          rfq_id: string
        }
        Insert: {
          condition_req?: Database["public"]["Enums"]["condition_type"] | null
          created_at?: string
          id?: string
          notes?: string | null
          part_number: string
          quantity: number
          rfq_id: string
        }
        Update: {
          condition_req?: Database["public"]["Enums"]["condition_type"] | null
          created_at?: string
          id?: string
          notes?: string | null
          part_number?: string
          quantity?: number
          rfq_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "part_lines_rfq_id_fkey"
            columns: ["rfq_id"]
            isOneToOne: false
            referencedRelation: "rfqs"
            referencedColumns: ["id"]
          },
        ]
      }
      quotes: {
        Row: {
          ai_analysis: Json | null
          attachments: string[] | null
          certs: string | null
          condition: Database["public"]["Enums"]["condition_type"] | null
          created_at: string
          currency: string | null
          delivery_point: string | null
          description: string | null
          id: string
          incoterm: string | null
          is_relevant: boolean | null
          lead_time_days: number | null
          moq: number | null
          part_number: string
          processed_at: string | null
          processing_status: string | null
          qty_available: number | null
          quote_status: string | null
          relevance_score: number | null
          rfq_id: string
          score: number | null
          supplier_id: string
          unit_price: number | null
          updated_at: string
          valid_until: string | null
          warranty_months: number | null
        }
        Insert: {
          ai_analysis?: Json | null
          attachments?: string[] | null
          certs?: string | null
          condition?: Database["public"]["Enums"]["condition_type"] | null
          created_at?: string
          currency?: string | null
          delivery_point?: string | null
          description?: string | null
          id?: string
          incoterm?: string | null
          is_relevant?: boolean | null
          lead_time_days?: number | null
          moq?: number | null
          part_number: string
          processed_at?: string | null
          processing_status?: string | null
          qty_available?: number | null
          quote_status?: string | null
          relevance_score?: number | null
          rfq_id: string
          score?: number | null
          supplier_id: string
          unit_price?: number | null
          updated_at?: string
          valid_until?: string | null
          warranty_months?: number | null
        }
        Update: {
          ai_analysis?: Json | null
          attachments?: string[] | null
          certs?: string | null
          condition?: Database["public"]["Enums"]["condition_type"] | null
          created_at?: string
          currency?: string | null
          delivery_point?: string | null
          description?: string | null
          id?: string
          incoterm?: string | null
          is_relevant?: boolean | null
          lead_time_days?: number | null
          moq?: number | null
          part_number?: string
          processed_at?: string | null
          processing_status?: string | null
          qty_available?: number | null
          quote_status?: string | null
          relevance_score?: number | null
          rfq_id?: string
          score?: number | null
          supplier_id?: string
          unit_price?: number | null
          updated_at?: string
          valid_until?: string | null
          warranty_months?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "quotes_rfq_id_fkey"
            columns: ["rfq_id"]
            isOneToOne: false
            referencedRelation: "rfqs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      rfqs: {
        Row: {
          aircraft_type: string | null
          attachments: string[] | null
          created_at: string
          deadline: string | null
          deleted_at: string | null
          deleted_by: string | null
          deletion_reason: string | null
          delivery_to: string | null
          id: string
          notes: string | null
          priority: Database["public"]["Enums"]["priority_type"]
          status: Database["public"]["Enums"]["status_type"]
          updated_at: string
        }
        Insert: {
          aircraft_type?: string | null
          attachments?: string[] | null
          created_at?: string
          deadline?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          deletion_reason?: string | null
          delivery_to?: string | null
          id?: string
          notes?: string | null
          priority?: Database["public"]["Enums"]["priority_type"]
          status?: Database["public"]["Enums"]["status_type"]
          updated_at?: string
        }
        Update: {
          aircraft_type?: string | null
          attachments?: string[] | null
          created_at?: string
          deadline?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          deletion_reason?: string | null
          delivery_to?: string | null
          id?: string
          notes?: string | null
          priority?: Database["public"]["Enums"]["priority_type"]
          status?: Database["public"]["Enums"]["status_type"]
          updated_at?: string
        }
        Relationships: []
      }
      suppliers: {
        Row: {
          active: boolean
          capabilities: string | null
          contact_name: string | null
          created_at: string
          emails: string[]
          id: string
          language: string | null
          name: string
          notes: string | null
          opt_out: boolean
          phone: string | null
          region: string | null
          tags: string[] | null
          types: Database["public"]["Enums"]["supplier_type"][] | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          capabilities?: string | null
          contact_name?: string | null
          created_at?: string
          emails: string[]
          id?: string
          language?: string | null
          name: string
          notes?: string | null
          opt_out?: boolean
          phone?: string | null
          region?: string | null
          tags?: string[] | null
          types?: Database["public"]["Enums"]["supplier_type"][] | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          capabilities?: string | null
          contact_name?: string | null
          created_at?: string
          emails?: string[]
          id?: string
          language?: string | null
          name?: string
          notes?: string | null
          opt_out?: boolean
          phone?: string | null
          region?: string | null
          tags?: string[] | null
          types?: Database["public"]["Enums"]["supplier_type"][] | null
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      analyze_quote_relevance: {
        Args: { quote_text: string; subject_text?: string }
        Returns: Json
      }
      soft_delete_rfq: {
        Args: { reason?: string; rfq_id: string }
        Returns: undefined
      }
    }
    Enums: {
      condition_type: "FN" | "OH" | "SV" | "AR" | "NS"
      priority_type: "AOG" | "Routine" | "Planned"
      status_type: "open" | "quoted" | "closed"
      supplier_type: "MRO" | "Trader" | "OEM" | "Distributor"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      condition_type: ["FN", "OH", "SV", "AR", "NS"],
      priority_type: ["AOG", "Routine", "Planned"],
      status_type: ["open", "quoted", "closed"],
      supplier_type: ["MRO", "Trader", "OEM", "Distributor"],
    },
  },
} as const
