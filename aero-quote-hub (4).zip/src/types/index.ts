export type ConditionType = 'FN' | 'OH' | 'SV' | 'AR' | 'NS';
export type PriorityType = 'AOG' | 'Routine' | 'Planned';
export type StatusType = 'open' | 'quoted' | 'closed';
export type SupplierType = 'MRO' | 'Trader' | 'OEM' | 'Distributor';

export interface RFQ {
  id: string;
  priority: PriorityType;
  aircraft_type?: string;
  delivery_to?: string;
  deadline?: string;
  notes?: string;
  status: StatusType;
  attachments?: string[];
  created_at: string;
  updated_at: string;
  part_lines?: PartLine[];
  quotes?: Quote[];
}

export interface PartLine {
  id: string;
  rfq_id: string;
  part_number: string;
  quantity: number;
  condition_req?: ConditionType;
  notes?: string;
  created_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact_name?: string;
  emails: string[];
  phone?: string;
  region?: string;
  capabilities?: string;
  types: SupplierType[];
  tags?: string[];
  language?: string;
  opt_out: boolean;
  notes?: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Quote {
  id: string;
  rfq_id: string;
  supplier_id: string;
  part_number: string;
  description?: string;
  condition?: ConditionType;
  qty_available?: number;
  unit_price?: number;
  currency?: string;
  lead_time_days?: number;
  moq?: number;
  valid_until?: string;
  warranty_months?: number;
  incoterm?: string;
  delivery_point?: string;
  certs?: string;
  score: number;
  attachments?: string[];
  created_at: string;
  updated_at: string;
  supplier?: Supplier;
  rfq?: RFQ;
}

export interface EmailThread {
  id: string;
  rfq_id: string;
  supplier_id: string;
  thread_id?: string;
  subject?: string;
  last_message_at: string;
  created_at: string;
}

export interface FileUpload {
  file: File;
  progress: number;
  uploaded: boolean;
  url?: string;
}