import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send, Mail, AlertTriangle, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { RFQ, Supplier, PartLine } from "@/types";

interface SendRFQDialogProps {
  rfq: RFQ;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const SendRFQDialog = ({ rfq, open, onOpenChange }: SendRFQDialogProps) => {
  const [selectedSuppliers, setSelectedSuppliers] = useState<string[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState("");
  const [sendResults, setSendResults] = useState<any>(null);

  useEffect(() => {
    if (open) {
      fetchSuppliers();
      setSelectedSuppliers([]);
      setMessage("");
      setSendResults(null);
    }
  }, [open]);

  const fetchSuppliers = async () => {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .eq('active', true)
        .eq('opt_out', false)
        .order('name');

      if (error) {
        console.error('Error fetching suppliers:', error);
        toast({
          title: "Error",
          description: "Failed to load suppliers",
          variant: "destructive",
        });
        return;
      }

      setSuppliers(data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSupplierToggle = (supplierId: string) => {
    setSelectedSuppliers(prev => 
      prev.includes(supplierId)
        ? prev.filter(id => id !== supplierId)
        : [...prev, supplierId]
    );
  };

  const handleSelectAll = () => {
    if (selectedSuppliers.length === suppliers.length) {
      setSelectedSuppliers([]);
    } else {
      setSelectedSuppliers(suppliers.map(s => s.id));
    }
  };

  const handleSendRFQ = async () => {
    if (selectedSuppliers.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one supplier",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('send-rfq', {
        body: {
          rfq_id: rfq.id,
          supplier_ids: selectedSuppliers,
          message: message.trim() || undefined
        }
      });

      if (error) {
        throw error;
      }

      const result = data;
      if (result.success) {
        setSendResults(result);
        toast({
          title: "RFQ Sent Successfully!",
          description: `Sent to ${result.summary.successful_sends} suppliers. ${result.summary.failed_sends} failed.`,
        });
      } else {
        throw new Error(result.error || 'Failed to send RFQ');
      }
    } catch (error: any) {
      console.error('Error sending RFQ:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to send RFQ",
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  const getSupplierTypeBadges = (types: string[]) => {
    return types.map(type => (
      <Badge key={type} variant="outline" className="text-xs mr-1">
        {type}
      </Badge>
    ));
  };

  const getPartLinesSummary = (partLines: PartLine[]) => {
    if (!partLines || partLines.length === 0) return 'No parts';
    if (partLines.length === 1) return partLines[0].part_number;
    return `${partLines.length} parts (${partLines[0].part_number}${partLines.length > 1 ? ` +${partLines.length - 1} more` : ''})`;
  };

  if (sendResults) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Check className="h-5 w-5 text-success" />
              RFQ Sent Successfully
            </DialogTitle>
            <DialogDescription>
              Your RFQ has been sent to the selected suppliers via email.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-success/10 p-4 rounded-lg">
                <div className="text-2xl font-bold text-success">{sendResults.summary.successful_sends}</div>
                <div className="text-sm text-muted-foreground">Sent Successfully</div>
              </div>
              <div className="bg-destructive/10 p-4 rounded-lg">
                <div className="text-2xl font-bold text-destructive">{sendResults.summary.failed_sends}</div>
                <div className="text-sm text-muted-foreground">Failed</div>
              </div>
              <div className="bg-primary/10 p-4 rounded-lg">
                <div className="text-2xl font-bold text-primary">{sendResults.summary.total_suppliers}</div>
                <div className="text-sm text-muted-foreground">Total Suppliers</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Sending Results:</h4>
              {sendResults.results.map((result: any, index: number) => {
                const supplier = suppliers.find(s => s.id === result.supplier_id);
                return (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <div className="flex items-center gap-2">
                      {result.status === 'sent' ? 
                        <Check className="h-4 w-4 text-success" /> : 
                        <X className="h-4 w-4 text-destructive" />
                      }
                      <span>{supplier?.name || 'Unknown Supplier'}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {result.status === 'sent' ? 
                        `${result.emails_sent} emails sent` : 
                        'Failed to send'
                      }
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">What happens next?</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Suppliers will receive the RFQ via email with all part details</li>
                <li>• They can respond directly by replying to the email</li>
                <li>• Incoming quotes will be automatically processed and appear in the Quotes section</li>
                <li>• You'll receive notifications when new quotes are received</li>
              </ul>
            </div>
          </div>

          <DialogFooter>
            <Button onClick={() => onOpenChange(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            Send RFQ to Suppliers
          </DialogTitle>
          <DialogDescription>
            Select suppliers to send this RFQ via email. They'll receive all part details and can respond directly.
          </DialogDescription>
        </DialogHeader>

        {/* RFQ Summary */}
        <Card className="mb-4">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">RFQ Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Priority:</span>
              <Badge className={
                rfq.priority === 'AOG' ? 'bg-destructive' : 
                rfq.priority === 'Routine' ? 'bg-primary' : 'bg-success'
              }>
                {rfq.priority}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Parts:</span>
              <span>{getPartLinesSummary(rfq.part_lines || [])}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Aircraft:</span>
              <span>{rfq.aircraft_type || 'Not specified'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Delivery:</span>
              <span>{rfq.delivery_to || 'Not specified'}</span>
            </div>
            {rfq.deadline && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Deadline:</span>
                <span>{new Date(rfq.deadline).toLocaleDateString()}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Additional Message */}
        <div className="space-y-2">
          <Label htmlFor="message">Additional Message (Optional)</Label>
          <Textarea
            id="message"
            placeholder="Add any additional information or special requirements..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
          />
        </div>

        {/* Supplier Selection */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Select Suppliers</h3>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleSelectAll}
              disabled={loading}
            >
              {selectedSuppliers.length === suppliers.length ? 'Deselect All' : 'Select All'}
            </Button>
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : suppliers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No active suppliers found. Please add suppliers first.
            </div>
          ) : (
            <div className="grid gap-3 max-h-64 overflow-y-auto">
              {suppliers.map((supplier) => (
                <div 
                  key={supplier.id}
                  className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                    selectedSuppliers.includes(supplier.id) 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:bg-muted/50'
                  }`}
                  onClick={() => handleSupplierToggle(supplier.id)}
                >
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      checked={selectedSuppliers.includes(supplier.id)}
                      onChange={() => handleSupplierToggle(supplier.id)}
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium">{supplier.name}</h4>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                            <Mail className="h-3 w-3" />
                            <span>{supplier.emails[0]}</span>
                            {supplier.emails.length > 1 && (
                              <span>+{supplier.emails.length - 1} more</span>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          {supplier.region && (
                            <Badge variant="secondary" className="text-xs">
                              {supplier.region}
                            </Badge>
                          )}
                          <div className="flex gap-1">
                            {getSupplierTypeBadges(supplier.types || [])}
                          </div>
                        </div>
                      </div>
                      {supplier.capabilities && (
                        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                          {supplier.capabilities}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSendRFQ}
            disabled={selectedSuppliers.length === 0 || sending}
            className="gap-2"
          >
            {sending ? (
              <>
                <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
                Sending...
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                Send RFQ ({selectedSuppliers.length})
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};