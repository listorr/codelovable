import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useState } from "react";
import { Loader2, Activity, CheckCircle, XCircle, Copy, AlertTriangle } from "lucide-react";

interface DiagnosticCheck {
  ok: boolean;
  status?: number;
  error?: string;
  details?: any;
  body?: any;
  missing?: string[];
  rows?: number;
  url?: string;
}

interface DiagnosticResult {
  success: boolean;
  checks: {
    env: DiagnosticCheck;
    graph_token: DiagnosticCheck;
    graph_list_subs: DiagnosticCheck;
    graph_inbox_probe: DiagnosticCheck;
    webhook_validation: DiagnosticCheck;
    resend_domains: DiagnosticCheck;
    openai_models: DiagnosticCheck;
    supabase_db: DiagnosticCheck;
  };
  hints?: string[];
}

interface DiagnosticsPanelProps {
  trigger?: React.ReactNode;
}

export const DiagnosticsPanel = ({ trigger }: DiagnosticsPanelProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DiagnosticResult | null>(null);
  const [open, setOpen] = useState(false);

  const runDiagnostics = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('diagnostics');
      
      if (error) {
        console.error('Diagnostics error:', error);
        toast.error(`Error running diagnostics: ${error.message}`);
        return;
      }
      
      setResult(data);
      
      if (data.success) {
        toast.success('All diagnostics passed!');
      } else {
        toast.error('Some diagnostic checks failed');
      }
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResults = () => {
    if (result) {
      navigator.clipboard.writeText(JSON.stringify(result, null, 2));
      toast.success('Results copied to clipboard');
    }
  };

  const getCheckIcon = (check: DiagnosticCheck) => {
    if (check.ok) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getCheckDetails = (checkName: string, check: DiagnosticCheck) => {
    if (check.ok) {
      if (checkName === 'supabase_db' && check.rows !== undefined) {
        return `Connected (${check.rows} RFQs found)`;
      }
      return 'OK';
    }
    
    if (check.missing) {
      return `Missing: ${check.missing.join(', ')}`;
    }
    
    if (check.error) {
      return check.error;
    }
    
    if (check.status) {
      return `HTTP ${check.status}`;
    }
    
    return 'Failed';
  };

  const defaultTrigger = (
    <Button variant="outline" size="sm">
      <Activity className="h-4 w-4 mr-2" />
      Diagnostics
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>System Diagnostics</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex space-x-2">
            <Button 
              onClick={runDiagnostics} 
              disabled={isLoading}
              className="flex-1"
            >
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Run Checks
            </Button>
            {result && (
              <Button variant="outline" onClick={copyResults}>
                <Copy className="h-4 w-4 mr-2" />
                Copy Results
              </Button>
            )}
          </div>

          {result && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-base">
                    Overall Status
                    <Badge variant={result.success ? "default" : "destructive"}>
                      {result.success ? "All OK" : "Issues Found"}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {result.hints && result.hints.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                        <span className="font-medium text-sm">Recommendations:</span>
                      </div>
                      <ul className="ml-6 space-y-1 text-sm text-muted-foreground">
                        {result.hints.map((hint, i) => (
                          <li key={i} className="list-disc">{hint}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Service Checks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3">
                    {Object.entries(result.checks).map(([name, check]) => (
                      <div key={name} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          {getCheckIcon(check)}
                          <div>
                            <div className="font-medium text-sm capitalize">
                              {name.replace(/_/g, ' ')}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {getCheckDetails(name, check)}
                            </div>
                          </div>
                        </div>
                        <Badge variant={check.ok ? "secondary" : "destructive"} className="text-xs">
                          {check.ok ? "Pass" : "Fail"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};