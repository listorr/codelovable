import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Filter, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export interface SupplierFilters {
  regions: string[];
  types: string[];
  tags: string[];
  activeOnly: boolean;
  optedInOnly: boolean;
}

interface SupplierFilterDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  filters: SupplierFilters;
  onFiltersChange: (filters: SupplierFilters) => void;
  availableRegions: string[];
  availableTypes: string[];
  availableTags: string[];
}

export const SupplierFilterDialog = ({ 
  open, 
  onOpenChange, 
  filters, 
  onFiltersChange,
  availableRegions,
  availableTypes,
  availableTags
}: SupplierFilterDialogProps) => {
  const [localFilters, setLocalFilters] = useState<SupplierFilters>(filters);

  const handleApplyFilters = () => {
    onFiltersChange(localFilters);
    onOpenChange(false);
  };

  const handleResetFilters = () => {
    const resetFilters: SupplierFilters = {
      regions: [],
      types: [],
      tags: [],
      activeOnly: false,
      optedInOnly: false
    };
    setLocalFilters(resetFilters);
    onFiltersChange(resetFilters);
    onOpenChange(false);
  };

  const toggleArrayFilter = (array: string[], value: string, field: keyof SupplierFilters) => {
    const newArray = array.includes(value) 
      ? array.filter(item => item !== value)
      : [...array, value];
    setLocalFilters(prev => ({ ...prev, [field]: newArray }));
  };

  const activeFiltersCount = 
    localFilters.regions.length + 
    localFilters.types.length + 
    localFilters.tags.length + 
    (localFilters.activeOnly ? 1 : 0) + 
    (localFilters.optedInOnly ? 1 : 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Suppliers
            {activeFiltersCount > 0 && (
              <Badge variant="secondary">{activeFiltersCount} active</Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            Filter suppliers by region, type, tags and status for targeted RFQ sending.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Status Filters */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Status</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="active-only"
                  checked={localFilters.activeOnly}
                  onCheckedChange={(checked) => 
                    setLocalFilters(prev => ({ ...prev, activeOnly: checked === true }))
                  }
                />
                <Label htmlFor="active-only" className="text-sm">Active suppliers only</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="opted-in-only"
                  checked={localFilters.optedInOnly}
                  onCheckedChange={(checked) => 
                    setLocalFilters(prev => ({ ...prev, optedInOnly: checked === true }))
                  }
                />
                <Label htmlFor="opted-in-only" className="text-sm">Opted-in suppliers only</Label>
              </div>
            </div>
          </div>

          {/* Region Filters */}
          {availableRegions.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Regions</Label>
              <div className="grid grid-cols-2 gap-2">
                {availableRegions.map((region) => (
                  <div key={region} className="flex items-center space-x-2">
                    <Checkbox
                      id={`region-${region}`}
                      checked={localFilters.regions.includes(region)}
                      onCheckedChange={() => 
                        toggleArrayFilter(localFilters.regions, region, 'regions')
                      }
                    />
                    <Label htmlFor={`region-${region}`} className="text-sm">{region}</Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Type Filters */}
          {availableTypes.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Supplier Types</Label>
              <div className="grid grid-cols-2 gap-2">
                {availableTypes.map((type) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={`type-${type}`}
                      checked={localFilters.types.includes(type)}
                      onCheckedChange={() => 
                        toggleArrayFilter(localFilters.types, type, 'types')
                      }
                    />
                    <Label htmlFor={`type-${type}`} className="text-sm">{type}</Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tag Filters */}
          {availableTags.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Tags</Label>
              <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                {availableTags.map((tag) => (
                  <div key={tag} className="flex items-center space-x-2">
                    <Checkbox
                      id={`tag-${tag}`}
                      checked={localFilters.tags.includes(tag)}
                      onCheckedChange={() => 
                        toggleArrayFilter(localFilters.tags, tag, 'tags')
                      }
                    />
                    <Label htmlFor={`tag-${tag}`} className="text-sm">{tag}</Label>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={handleResetFilters}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Clear All
          </Button>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button onClick={handleApplyFilters}>
            Apply Filters
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};