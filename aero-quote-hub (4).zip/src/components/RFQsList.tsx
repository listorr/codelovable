import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Send, Trash2, AlertTriangle, Clock, Plus, FileDown } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";
import { CreateRFQDialog } from "./CreateRFQDialog";
import { RFQDetailDialog } from "./RFQDetailDialog";
import { SendRFQDialog } from "./SendRFQDialog";
import { DeleteRFQDialog } from "./DeleteRFQDialog";
import { RFQ } from "@/types";

const getPartLinesSummary = (partLines: Array<{part_number: string}>) => {
  if (!partLines || partLines.length === 0) return 'No parts';
  if (partLines.length === 1) return partLines[0].part_number;
  return `${partLines[0].part_number} +${partLines.length - 1} more`;
};

const getPriorityColor = (priority: RFQ['priority']) => {
  switch (priority) {
    case 'AOG':
      return 'bg-warning text-warning-foreground';
    case 'Routine':
      return 'bg-primary text-primary-foreground';
    case 'Planned':
      return 'bg-success text-success-foreground';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getStatusColor = (status: RFQ['status']) => {
  switch (status) {
    case 'open':
      return 'bg-warning text-warning-foreground';
    case 'quoted':
      return 'bg-primary text-primary-foreground';
    case 'closed':
      return 'bg-success text-success-foreground';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

export const RFQsList = () => {
  const [rfqs, setRfqs] = useState<RFQ[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRFQ, setSelectedRFQ] = useState<RFQ | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  useEffect(() => {
    fetchRFQs();
  }, []);

  const fetchRFQs = async () => {
    try {
      const { data: rfqsData, error } = await supabase
        .from('rfqs')
        .select(`
          *,
          part_lines(*)
        `)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching RFQs:', error);
        toast({
          title: "Error",
          description: "Failed to load RFQs",
          variant: "destructive",
        });
        return;
      }

      setRfqs((rfqsData || []) as RFQ[]);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load RFQs",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const isDeadlineApproaching = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const diffInDays = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diffInDays <= 2;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>RFQs</CardTitle>
          <CardDescription>Loading RFQs...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (rfqs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>RFQs</CardTitle>
          <CardDescription>No RFQs found. Create your first RFQ to get started.</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground mb-4">No RFQs available</p>
          <Button>Create First RFQ</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>RFQs ({rfqs.length})</CardTitle>
          <CardDescription>Manage your Request for Quotations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>RFQ Details</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Aircraft</TableHead>
                  <TableHead>Delivery</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rfqs.map((rfq) => (
                  <TableRow key={rfq.id}>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{getPartLinesSummary(rfq.part_lines || [])}</div>
                        <div className="text-sm text-muted-foreground">
                          {rfq.part_lines?.length || 0} parts • Created {format(new Date(rfq.created_at), 'MMM dd, yyyy')}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge className={getPriorityColor(rfq.priority)}>
                          {rfq.priority}
                        </Badge>
                        {rfq.priority === 'AOG' && (
                          <AlertTriangle className="h-4 w-4 text-warning" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{rfq.aircraft_type}</TableCell>
                    <TableCell>{rfq.delivery_to}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {rfq.deadline ? format(new Date(rfq.deadline), 'MMM dd, yyyy') : 'No deadline'}
                        {rfq.deadline && isDeadlineApproaching(rfq.deadline) && (
                          <Clock className="h-4 w-4 text-warning" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(rfq.status)}>
                        {rfq.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedRFQ(rfq);
                            setShowDetailDialog(true);
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedRFQ(rfq);
                            setShowSendDialog(true);
                          }}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedRFQ(rfq);
                            setShowDeleteDialog(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {selectedRFQ && (
        <RFQDetailDialog 
          open={showDetailDialog} 
          onOpenChange={setShowDetailDialog}
          rfq={selectedRFQ}
          onUpdate={fetchRFQs}
        />
      )}

      {selectedRFQ && (
        <SendRFQDialog 
          open={showSendDialog} 
          onOpenChange={(open) => {
            setShowSendDialog(open);
            if (!open) {
              setSelectedRFQ(null);
            }
          }}
          rfq={selectedRFQ}
        />
      )}

      {selectedRFQ && (
        <DeleteRFQDialog 
          open={showDeleteDialog} 
          onOpenChange={(open) => {
            setShowDeleteDialog(open);
            if (!open) {
              setSelectedRFQ(null);
            }
          }}
          rfqId={selectedRFQ.id}
          onDeleted={fetchRFQs}
        />
      )}
    </>
  );
};