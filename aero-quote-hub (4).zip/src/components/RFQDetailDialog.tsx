import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Star, AlertTriangle, Clock, FileText } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { RFQ, Quote, PartLine } from "@/types";

interface RFQDetailDialogProps {
  rfq: RFQ;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: () => void;
}

export const RFQDetailDialog = ({ rfq, open, onOpenChange, onUpdate }: RFQDetailDialogProps) => {
  const [partLines, setPartLines] = useState<PartLine[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && rfq) {
      fetchRFQDetails();
    }
  }, [open, rfq]);

  const fetchRFQDetails = async () => {
    setLoading(true);
    try {
      // Fetch part lines
      const { data: partLinesData, error: partLinesError } = await supabase
        .from('part_lines')
        .select('*')
        .eq('rfq_id', rfq.id)
        .order('created_at');

      if (partLinesError) {
        console.error('Error fetching part lines:', partLinesError);
      } else {
        setPartLines(partLinesData || []);
      }

      // Fetch quotes with supplier info
      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select(`
          *,
          supplier:suppliers (*)
        `)
        .eq('rfq_id', rfq.id)
        .order('score', { ascending: false });

      if (quotesError) {
        console.error('Error fetching quotes:', quotesError);
      } else {
        setQuotes(quotesData || []);
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load RFQ details",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getPriorityColor = (priority: RFQ['priority']) => {
    switch (priority) {
      case 'AOG':
        return 'bg-warning text-warning-foreground';
      case 'Routine':
        return 'bg-primary text-primary-foreground';
      case 'Planned':
        return 'bg-success text-success-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status: RFQ['status']) => {
    switch (status) {
      case 'open':
        return 'bg-warning text-warning-foreground';
      case 'quoted':
        return 'bg-primary text-primary-foreground';
      case 'closed':
        return 'bg-success text-success-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const isValidityExpiring = (validUntil: string) => {
    const expiryDate = new Date(validUntil);
    const now = new Date();
    const diffInHours = (expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    return diffInHours <= 48;
  };

  const getQuotesForPart = (partNumber: string) => {
    return quotes.filter(q => q.part_number === partNumber);
  };

  const formatPrice = (price: number | undefined, currency = 'USD') => {
    if (!price) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD'
    }).format(price);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            RFQ Details
            <Badge className={getPriorityColor(rfq.priority)}>
              {rfq.priority}
            </Badge>
            {rfq.priority === 'AOG' && (
              <AlertTriangle className="h-4 w-4 text-warning" />
            )}
          </DialogTitle>
          <DialogDescription>
            Created {format(new Date(rfq.created_at), 'PPP')}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-20 bg-muted rounded" />
            ))}
          </div>
        ) : (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="parts">Part Lines ({partLines.length})</TabsTrigger>
              <TabsTrigger value="quotes">Quotes ({quotes.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">RFQ Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge className={getStatusColor(rfq.status)}>
                        {rfq.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Aircraft Type:</span>
                      <span>{rfq.aircraft_type || 'Not specified'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Delivery To:</span>
                      <span>{rfq.delivery_to || 'Not specified'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Deadline:</span>
                      <div className="flex items-center gap-2">
                        {rfq.deadline ? (
                          <>
                            <span>{format(new Date(rfq.deadline), 'PPP')}</span>
                            {new Date(rfq.deadline) < new Date(Date.now() + 2 * 24 * 60 * 60 * 1000) && (
                              <Clock className="h-4 w-4 text-warning" />
                            )}
                          </>
                        ) : (
                          <span>Not specified</span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Statistics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Part Lines:</span>
                      <span>{partLines.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Quotes:</span>
                      <span>{quotes.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Best Score:</span>
                      <span>{quotes.length > 0 ? Math.max(...quotes.map(q => q.score)) : 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Attachments:</span>
                      <span>{rfq.attachments?.length || 0}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {rfq.notes && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Notes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="whitespace-pre-wrap">{rfq.notes}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="parts" className="space-y-4">
              {partLines.map((partLine) => (
                <Card key={partLine.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{partLine.part_number}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Qty: {partLine.quantity}</Badge>
                        {partLine.condition_req && (
                          <Badge variant="outline">{partLine.condition_req}</Badge>
                        )}
                      </div>
                    </div>
                    {partLine.notes && (
                      <CardDescription>{partLine.notes}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <h4 className="font-medium">Quotes for this part ({getQuotesForPart(partLine.part_number).length})</h4>
                      {getQuotesForPart(partLine.part_number).length > 0 ? (
                        <div className="rounded-md border">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Supplier</TableHead>
                                <TableHead>Condition</TableHead>
                                <TableHead>Price</TableHead>
                                <TableHead>Available</TableHead>
                                <TableHead>Lead Time</TableHead>
                                <TableHead>Score</TableHead>
                                <TableHead>Valid Until</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {getQuotesForPart(partLine.part_number).map((quote) => (
                                <TableRow key={quote.id}>
                                  <TableCell>{quote.supplier?.name || 'Unknown'}</TableCell>
                                  <TableCell>
                                    {quote.condition && (
                                      <Badge variant="outline">{quote.condition}</Badge>
                                    )}
                                  </TableCell>
                                  <TableCell>{formatPrice(quote.unit_price, quote.currency)}</TableCell>
                                  <TableCell>{quote.qty_available || 'N/A'}</TableCell>
                                  <TableCell>{quote.lead_time_days ? `${quote.lead_time_days} days` : 'N/A'}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-1">
                                      <Star className="h-3 w-3 fill-current" />
                                      {quote.score}
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      {quote.valid_until ? (
                                        <>
                                          {format(new Date(quote.valid_until), 'MMM dd')}
                                          {isValidityExpiring(quote.valid_until) && (
                                            <AlertTriangle className="h-3 w-3 text-warning" />
                                          )}
                                        </>
                                      ) : (
                                        'N/A'
                                      )}
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <p className="text-muted-foreground">No quotes received for this part yet.</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="quotes" className="space-y-4">
              {quotes.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Supplier</TableHead>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Condition</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Available</TableHead>
                        <TableHead>Lead Time</TableHead>
                        <TableHead>MOQ</TableHead>
                        <TableHead>Score</TableHead>
                        <TableHead>Valid Until</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {quotes.map((quote) => (
                        <TableRow key={quote.id}>
                          <TableCell className="font-medium">{quote.supplier?.name || 'Unknown'}</TableCell>
                          <TableCell>{quote.part_number}</TableCell>
                          <TableCell>
                            {quote.condition && (
                              <Badge variant="outline">{quote.condition}</Badge>
                            )}
                          </TableCell>
                          <TableCell>{formatPrice(quote.unit_price, quote.currency)}</TableCell>
                          <TableCell>{quote.qty_available || 'N/A'}</TableCell>
                          <TableCell>{quote.lead_time_days ? `${quote.lead_time_days} days` : 'N/A'}</TableCell>
                          <TableCell>{quote.moq || 'N/A'}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-current" />
                              <span className="font-medium">{quote.score}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {quote.valid_until ? (
                                <>
                                  {format(new Date(quote.valid_until), 'MMM dd, yyyy')}
                                  {isValidityExpiring(quote.valid_until) && (
                                    <AlertTriangle className="h-4 w-4 text-warning" />
                                  )}
                                </>
                              ) : (
                                'N/A'
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-8">
                    <p className="text-muted-foreground">No quotes received yet for this RFQ.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
};