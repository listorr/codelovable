import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Download, FileText, CheckCircle, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

interface SupplierImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImported: () => void;
}

interface ImportResult {
  success: number;
  errors: Array<{ row: number; error: string; data: any }>;
}

export const SupplierImportDialog = ({ open, onOpenChange, onImported }: SupplierImportDialogProps) => {
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const downloadTemplate = () => {
    const csvHeaders = [
      'Company Name',
      'Contact Name', 
      'Email',
      'Phone',
      'Region',
      'Tags',
      'Language',
      'Notes'
    ];
    
    const csvExample = [
      'AeroTech Solutions',
      'John Smith',
      'john@aerotech.com',
      '+1-555-0123',
      'North America',
      'MRO;Avionics',
      'en',
      'Specialized in Boeing parts'
    ];

    const csvContent = [
      csvHeaders.join(','),
      csvExample.join(','),
      // Add empty rows for user to fill
      Array(csvHeaders.length).fill('').join(','),
      Array(csvHeaders.length).fill('').join(',')
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'supplier-import-template.csv';
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Template Downloaded",
      description: "CSV template has been downloaded to your computer",
    });
  };

  const parseCSV = (text: string): any[] => {
    const lines = text.split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim()) {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        data.push(row);
      }
    }

    return data;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      toast({
        title: "Invalid File",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }

    setIsImporting(true);
    setImportResult(null);

    try {
      const text = await file.text();
      const csvData = parseCSV(text);
      
      const result: ImportResult = { success: 0, errors: [] };

      for (let i = 0; i < csvData.length; i++) {
        const row = csvData[i];
        
        // Validate required fields
        if (!row['Company Name'] || !row['Email']) {
          result.errors.push({
            row: i + 2, // +2 because we start from row 1 and skip header
            error: 'Company Name and Email are required',
            data: row
          });
          continue;
        }

        try {
          // Prepare supplier data
          const supplierData = {
            name: row['Company Name'],
            contact_name: row['Contact Name'] || null,
            emails: [row['Email']],
            phone: row['Phone'] || null,
            region: row['Region'] || null,
            tags: row['Tags'] ? row['Tags'].split(';').map((t: string) => t.trim()) : [],
            language: row['Language'] || 'en',
            notes: row['Notes'] || null,
            active: true,
            opt_out: false
          };

          const { error } = await supabase
            .from('suppliers')
            .insert(supplierData);

          if (error) {
            result.errors.push({
              row: i + 2,
              error: error.message,
              data: row
            });
          } else {
            result.success++;
          }
        } catch (error: any) {
          result.errors.push({
            row: i + 2,
            error: error.message || 'Unknown error',
            data: row
          });
        }
      }

      setImportResult(result);

      if (result.success > 0) {
        toast({
          title: "Import Completed",
          description: `Successfully imported ${result.success} suppliers${result.errors.length > 0 ? ` with ${result.errors.length} errors` : ''}`,
        });
        onImported();
      }

    } catch (error: any) {
      console.error('Import error:', error);
      toast({
        title: "Import Failed",
        description: "Failed to process the CSV file",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  const resetDialog = () => {
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => {
      onOpenChange(open);
      if (!open) resetDialog();
    }}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Import Suppliers
          </DialogTitle>
          <DialogDescription>
            Upload a CSV file to bulk import suppliers into your system.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Download Template */}
          <div className="space-y-2">
            <Label>Step 1: Download Template</Label>
            <Button 
              variant="outline" 
              onClick={downloadTemplate}
              className="w-full justify-start gap-2"
            >
              <Download className="h-4 w-4" />
              Download CSV Template
            </Button>
            <p className="text-sm text-muted-foreground">
              Download the template with required columns and example data
            </p>
          </div>

          {/* Upload File */}
          <div className="space-y-2">
            <Label htmlFor="file-upload">Step 2: Upload Completed CSV</Label>
            <Input
              id="file-upload"
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              disabled={isImporting}
            />
            <p className="text-sm text-muted-foreground">
              Required columns: Company Name, Email. Optional: Contact Name, Phone, Region, Tags, Language, Notes
            </p>
          </div>

          {/* Import Results */}
          {importResult && (
            <div className="space-y-4 p-4 border rounded-lg">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                <h4 className="font-medium">Import Results</h4>
              </div>
              
              <div className="flex items-center gap-4">
                <Badge variant="default" className="gap-1">
                  <CheckCircle className="h-3 w-3" />
                  {importResult.success} Success
                </Badge>
                {importResult.errors.length > 0 && (
                  <Badge variant="destructive" className="gap-1">
                    <XCircle className="h-3 w-3" />
                    {importResult.errors.length} Errors
                  </Badge>
                )}
              </div>

              {importResult.errors.length > 0 && (
                <div className="space-y-2">
                  <h5 className="text-sm font-medium">Errors:</h5>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {importResult.errors.slice(0, 5).map((error, index) => (
                      <div key={index} className="text-xs p-2 bg-destructive/10 rounded">
                        <span className="font-medium">Row {error.row}:</span> {error.error}
                      </div>
                    ))}
                    {importResult.errors.length > 5 && (
                      <p className="text-xs text-muted-foreground">
                        ... and {importResult.errors.length - 5} more errors
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
          >
            {importResult?.success ? 'Close' : 'Cancel'}
          </Button>
          {isImporting && (
            <Button disabled>
              Importing...
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};