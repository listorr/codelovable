import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Send, MessageSquare, Clock, User, FileText } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface CommunicationRecord {
  id: string;
  rfq_id: string;
  supplier_id: string;
  communication_type: string;
  subject?: string;
  content?: string;
  sent_at?: string;
  received_at?: string;
  created_at: string;
  metadata?: any;
}

interface CommunicationHistoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  supplierId: string;
  supplierName: string;
  rfqId?: string;
}

export const CommunicationHistoryDialog = ({ 
  open, 
  onOpenChange, 
  supplierId, 
  supplierName,
  rfqId 
}: CommunicationHistoryDialogProps) => {
  const [communications, setCommunications] = useState<CommunicationRecord[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      fetchCommunications();
    }
  }, [open, supplierId, rfqId]);

  const fetchCommunications = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('communication_history')
        .select('*')
        .eq('supplier_id', supplierId);

      if (rfqId) {
        query = query.eq('rfq_id', rfqId);
      }

      const { data, error } = await query
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching communications:', error);
        toast({
          title: "Error",
          description: "Failed to load communication history",
          variant: "destructive",
        });
        return;
      }

      setCommunications(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load communication history",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email_sent':
        return <Send className="h-4 w-4 text-primary" />;
      case 'quote_received':
        return <Mail className="h-4 w-4 text-success" />;
      case 'follow_up':
        return <MessageSquare className="h-4 w-4 text-warning" />;
      default:
        return <FileText className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'email_sent':
        return 'bg-primary text-primary-foreground';
      case 'quote_received':
        return 'bg-success text-success-foreground';
      case 'follow_up':
        return 'bg-warning text-warning-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatCommunicationType = (type: string) => {
    return type.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Communication History: {supplierName}
          </DialogTitle>
          <DialogDescription>
            Complete communication timeline {rfqId ? 'for this RFQ' : 'with this supplier'}
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh] pr-4">
          {loading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="pb-3">
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="h-16 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : communications.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No communications found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {communications.map((comm) => (
                <Card key={comm.id} className="relative">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(comm.communication_type)}
                        <Badge className={getTypeColor(comm.communication_type)}>
                          {formatCommunicationType(comm.communication_type)}
                        </Badge>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {format(new Date(comm.created_at), 'MMM dd, yyyy HH:mm')}
                        </div>
                      </div>
                      {comm.metadata?.ai_analysis && (
                        <Badge variant="outline" className="gap-1">
                          AI Processed
                        </Badge>
                      )}
                    </div>
                    {comm.subject && (
                      <CardTitle className="text-base">{comm.subject}</CardTitle>
                    )}
                  </CardHeader>
                  <CardContent>
                    {comm.content && (
                      <div className="text-sm text-muted-foreground mb-3 max-h-24 overflow-y-auto">
                        {comm.content.length > 200 
                          ? `${comm.content.substring(0, 200)}...` 
                          : comm.content
                        }
                      </div>
                    )}
                    {comm.metadata?.ai_analysis && (
                      <div className="bg-muted/50 p-3 rounded-lg space-y-2">
                        <div className="text-xs font-medium text-muted-foreground">AI Analysis</div>
                        <div className="flex flex-wrap gap-1">
                          {comm.metadata.ai_analysis.hasPrice && (
                            <Badge variant="outline">Price Info</Badge>
                          )}
                          {comm.metadata.ai_analysis.hasAvailability && (
                            <Badge variant="outline">Availability</Badge>
                          )}
                          {comm.metadata.ai_analysis.hasCommercialTerms && (
                            <Badge variant="outline">Commercial Terms</Badge>
                          )}
                          {comm.metadata.ai_analysis.isNegativeResponse && (
                            <Badge variant="destructive">No Quote</Badge>
                          )}
                        </div>
                        {comm.metadata.ai_analysis.reasoning && (
                          <p className="text-xs text-muted-foreground">
                            {comm.metadata.ai_analysis.reasoning}
                          </p>
                        )}
                      </div>
                    )}
                    {comm.metadata?.quote_id && (
                      <div className="mt-2">
                        <Badge variant="secondary">
                          Quote Created: {comm.metadata.quote_id.substring(0, 8)}...
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};