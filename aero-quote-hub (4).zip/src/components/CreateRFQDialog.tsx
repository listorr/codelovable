import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Minus, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { PriorityType, ConditionType, PartLine, FileUpload } from "@/types";

interface CreateRFQDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

interface PartLineInput {
  part_number: string;
  quantity: number;
  condition_req?: ConditionType;
  notes?: string;
}

export const CreateRFQDialog = ({ open, onOpenChange, onSuccess }: CreateRFQDialogProps) => {
  const [priority, setPriority] = useState<PriorityType>('Routine');
  const [aircraftType, setAircraftType] = useState('');
  const [deliveryTo, setDeliveryTo] = useState('');
  const [deadline, setDeadline] = useState('');
  const [notes, setNotes] = useState('');
  const [partLines, setPartLines] = useState<PartLineInput[]>([
    { part_number: '', quantity: 1 }
  ]);
  const [attachments, setAttachments] = useState<FileUpload[]>([]);
  const [loading, setLoading] = useState(false);

  const addPartLine = () => {
    setPartLines([...partLines, { part_number: '', quantity: 1 }]);
  };

  const removePartLine = (index: number) => {
    if (partLines.length > 1) {
      setPartLines(partLines.filter((_, i) => i !== index));
    }
  };

  const updatePartLine = (index: number, field: keyof PartLineInput, value: any) => {
    const updated = [...partLines];
    updated[index] = { ...updated[index], [field]: value };
    setPartLines(updated);
  };

  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;
    
    Array.from(files).forEach(file => {
      setAttachments(prev => [...prev, {
        file,
        progress: 0,
        uploaded: false
      }]);
    });
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const uploadFile = async (fileUpload: FileUpload): Promise<string | null> => {
    try {
      const fileExt = fileUpload.file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `rfq-attachments/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('attachments')
        .upload(filePath, fileUpload.file);

      if (uploadError) {
        console.error('Upload error:', uploadError);
        return null;
      }

      return filePath;
    } catch (error) {
      console.error('File upload error:', error);
      return null;
    }
  };

  const handleSubmit = async () => {
    if (partLines.some(pl => !pl.part_number.trim())) {
      toast({
        title: "Validation Error",
        description: "All part numbers are required",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Upload attachments first
      const uploadedFiles: string[] = [];
      for (const attachment of attachments) {
        const filePath = await uploadFile(attachment);
        if (filePath) {
          uploadedFiles.push(filePath);
        }
      }

      // Create RFQ
      const rfqData = {
        priority,
        aircraft_type: aircraftType.trim() || null,
        delivery_to: deliveryTo.trim() || null,
        deadline: deadline || null,
        notes: notes.trim() || null,
        attachments: uploadedFiles.length > 0 ? uploadedFiles : null
      };

      const { data: rfq, error: rfqError } = await supabase
        .from('rfqs')
        .insert(rfqData)
        .select()
        .single();

      if (rfqError) {
        console.error('RFQ creation error:', rfqError);
        toast({
          title: "Error",
          description: "Failed to create RFQ",
          variant: "destructive",
        });
        return;
      }

      // Create part lines
      const partLinesData = partLines.map(pl => ({
        rfq_id: rfq.id,
        part_number: pl.part_number.trim(),
        quantity: pl.quantity,
        condition_req: pl.condition_req || null,
        notes: pl.notes?.trim() || null
      }));

      const { error: partLinesError } = await supabase
        .from('part_lines')
        .insert(partLinesData);

      if (partLinesError) {
        console.error('Part lines creation error:', partLinesError);
        toast({
          title: "Error",
          description: "Failed to create part lines",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Success",
        description: "RFQ created successfully",
      });

      // Reset form
      setPriority('Routine');
      setAircraftType('');
      setDeliveryTo('');
      setDeadline('');
      setNotes('');
      setPartLines([{ part_number: '', quantity: 1 }]);
      setAttachments([]);

      onSuccess();
    } catch (error) {
      console.error('Error creating RFQ:', error);
      toast({
        title: "Error",
        description: "Failed to create RFQ",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New RFQ</DialogTitle>
          <DialogDescription>
            Create a new Request for Quotation with multiple part lines
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select value={priority} onValueChange={(value: PriorityType) => setPriority(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AOG">AOG</SelectItem>
                  <SelectItem value="Routine">Routine</SelectItem>
                  <SelectItem value="Planned">Planned</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="aircraft_type">Aircraft Type (Optional)</Label>
              <Input
                id="aircraft_type"
                value={aircraftType}
                onChange={(e) => setAircraftType(e.target.value)}
                placeholder="e.g., A320, B737"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_to">Delivery To (Optional)</Label>
              <Input
                id="delivery_to"
                value={deliveryTo}
                onChange={(e) => setDeliveryTo(e.target.value)}
                placeholder="e.g., LAX, JFK"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="deadline">Deadline (Optional)</Label>
              <Input
                id="deadline"
                type="datetime-local"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
          </div>

          {/* Part Lines */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Part Lines</CardTitle>
                <Button size="sm" onClick={addPartLine}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Part
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {partLines.map((partLine, index) => (
                <div key={index} className="grid grid-cols-12 gap-4 items-end p-4 border rounded-lg">
                  <div className="col-span-3 space-y-2">
                    <Label>Part Number *</Label>
                    <Input
                      value={partLine.part_number}
                      onChange={(e) => updatePartLine(index, 'part_number', e.target.value)}
                      placeholder="Part number"
                    />
                  </div>
                  
                  <div className="col-span-2 space-y-2">
                    <Label>Quantity *</Label>
                    <Input
                      type="number"
                      min="1"
                      value={partLine.quantity}
                      onChange={(e) => updatePartLine(index, 'quantity', parseInt(e.target.value) || 1)}
                    />
                  </div>
                  
                  <div className="col-span-2 space-y-2">
                    <Label>Condition</Label>
                    <Select 
                      value={partLine.condition_req || 'none'} 
                      onValueChange={(value: string) => updatePartLine(index, 'condition_req', value === 'none' ? undefined : value as ConditionType)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="FN">FN</SelectItem>
                        <SelectItem value="OH">OH</SelectItem>
                        <SelectItem value="SV">SV</SelectItem>
                        <SelectItem value="AR">AR</SelectItem>
                        <SelectItem value="NS">NS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="col-span-4 space-y-2">
                    <Label>Notes</Label>
                    <Input
                      value={partLine.notes || ''}
                      onChange={(e) => updatePartLine(index, 'notes', e.target.value)}
                      placeholder="Optional notes"
                    />
                  </div>
                  
                  <div className="col-span-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removePartLine(index)}
                      disabled={partLines.length === 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Attachments */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="attachments">Attachments</Label>
              <div className="mt-2">
                <input
                  id="attachments"
                  type="file"
                  multiple
                  onChange={(e) => handleFileUpload(e.target.files)}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('attachments')?.click()}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Files
                </Button>
              </div>
            </div>
            
            {attachments.length > 0 && (
              <div className="space-y-2">
                {attachments.map((attachment, index) => (
                  <div key={index} className="flex items-center justify-between p-2 border rounded">
                    <span className="text-sm">{attachment.file.name}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeAttachment(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes for this RFQ"
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? "Creating..." : "Create RFQ"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};