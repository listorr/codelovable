import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface DeleteRFQDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rfqId: string;
  onDeleted: () => void;
}

export const DeleteRFQDialog = ({ open, onOpenChange, rfqId, onDeleted }: DeleteRFQDialogProps) => {
  const [reason, setReason] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!reason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for deleting this RFQ",
        variant: "destructive",
      });
      return;
    }

    setIsDeleting(true);

    try {
      const { error } = await supabase.rpc('soft_delete_rfq', {
        rfq_id: rfqId,
        reason: reason.trim()
      });

      if (error) {
        console.error('Error deleting RFQ:', error);
        toast({
          title: "Error",
          description: "Failed to delete RFQ",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "RFQ Deleted",
        description: "The RFQ has been successfully deleted and logged for audit trail",
      });

      onDeleted();
      onOpenChange(false);
      setReason("");
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to delete RFQ",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Delete RFQ
          </DialogTitle>
          <DialogDescription>
            This action will mark the RFQ as deleted but preserve it for audit purposes. 
            This action cannot be undone from the interface.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="reason">Deletion Reason *</Label>
            <Textarea
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Please provide a reason for deleting this RFQ (e.g., duplicate, cancelled, incorrect data...)"
              className="min-h-[100px]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => {
              onOpenChange(false);
              setReason("");
            }}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleDelete}
            disabled={isDeleting || !reason.trim()}
          >
            {isDeleting ? "Deleting..." : "Delete RFQ"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};