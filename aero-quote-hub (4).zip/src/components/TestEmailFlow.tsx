import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle2, Clock, Mail, MessageSquare, RefreshCw, Loader2, Database, Eye, Trash2, Send, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Subscription {
  id: string;
  resource: string;
  notificationUrl: string;
  expirationDateTime: string;
}

interface TestResult {
  step: string;
  status: 'success' | 'error' | 'loading';
  message: string;
  data?: any;
}

interface Quote {
  id: string;
  rfq_id: string;
  supplier_id: string;
  part_number: string;
  unit_price: number;
  currency: string;
  lead_time_days: number;
  relevance_score: number;
  ai_analysis: any;
  quote_status: string;
  created_at: string;
}

export const TestEmailFlow = () => {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [results, setResults] = useState<TestResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [rfqs, setRfqs] = useState<any[]>([]);
  const [communications, setCommunications] = useState<any[]>([]);
  const [subscriptionsData, setSubscriptionsData] = useState<any>(null);

  const handleListSubscriptions = async () => {
    try {
      const result = await supabase.functions.invoke('test-email-flow', {
        body: { action: 'list-subscriptions' }
      });
      
      setSubscriptionsData(result);
    } catch (error) {
      console.error('Error listing subscriptions:', error);
      setSubscriptionsData({ error: String(error) });
    }
  };

  const handleCreateSubscription = async () => {
    try {
      const result = await supabase.functions.invoke('test-email-flow', {
        body: { action: 'create-subscription' }
      });
      
      setSubscriptionsData(result);
    } catch (error) {
      console.error('Error creating subscription:', error);
      setSubscriptionsData({ error: String(error) });
    }
  };

  const handleTestWebhook = async () => {
    try {
      const result = await supabase.functions.invoke('test-email-flow', {
        body: { action: 'test-webhook' }
      });
      
      console.log('Webhook test result:', result);
      setSubscriptionsData({ ...subscriptionsData, webhookTest: result });
    } catch (error) {
      console.error('Error testing webhook:', error);
      setSubscriptionsData({ ...subscriptionsData, webhookTest: { error: String(error) } });
    }
  };

  const handleTestProcessMsgraph = async () => {
    try {
      const result = await supabase.functions.invoke('test-email-flow', {
        body: { action: 'test-process-msgraph' }
      });
      
      setSubscriptionsData(result);
      toast({
        title: result.data?.success ? "Success" : "Error",
        description: result.data?.success ? "Process-msgraph-email function is working" : "Process-msgraph-email function failed",
        variant: result.data?.success ? "default" : "destructive"
      });
    } catch (error) {
      console.error('Error testing process-msgraph-email:', error);
      setSubscriptionsData({ error: String(error) });
    }
  };

  const handleRenewSubscription = async (subscriptionId: string) => {
    try {
      const result = await supabase.functions.invoke('test-email-flow', {
        body: { action: 'renew-subscription', subscriptionId }
      });
      
      setSubscriptionsData(result);
      toast({
        title: result.data?.success ? "Success" : "Error",
        description: result.data?.success ? "Subscription renewed successfully" : "Failed to renew subscription",
        variant: result.data?.success ? "default" : "destructive"
      });
    } catch (error) {
      console.error('Error renewing subscription:', error);
      setSubscriptionsData({ error: String(error) });
    }
  };
  const [testEmail, setTestEmail] = useState({
    to: 'rfqs@suatfuels.com',
    subject: 'Re: Planned RFQ - 2 Parts - Ref: 15C0A68F',
    body: `Quote Response for RFQ 15C0A68F:

Item: Widget Pro Max
Price: $150 USD
Lead Time: 3-5 days  
Availability: In Stock (25 units)
Valid Until: 2025-09-20
Warranty: 24 months
MOQ: 1 unit
Incoterm: FOB Miami

Best regards,
Aerospace Supplier`
  });

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    await Promise.all([fetchQuotes(), fetchRfqs(), fetchCommunications()]);
  };

  const addResult = (step: string, status: 'success' | 'error' | 'loading', message: string, data?: any) => {
    setResults(prev => [...prev.filter(r => r.step !== step), { step, status, message, data }]);
  };

  const fetchQuotes = async () => {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      setQuotes(data || []);
    } catch (error) {
      console.error('Error fetching quotes:', error);
    }
  };

  const fetchCommunications = async () => {
    try {
      const { data, error } = await supabase
        .from('communication_history')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      setCommunications(data || []);
      console.log('💬 Recent communications:', data);
    } catch (error) {
      console.error('Error fetching communications:', error);
    }
  };

  const fetchRfqs = async () => {
    try {
      const { data, error } = await supabase
        .from('rfqs')
        .select('id, status, created_at')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      setRfqs(data || []);
    } catch (error) {
      console.error('Error fetching RFQs:', error);
    }
  };

  const deleteSubscription = async (subscriptionId: string) => {
    try {
      addResult('delete-subscription', 'loading', `Deleting subscription ${subscriptionId}...`);
      
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'delete', subscriptionId }
      });

      if (error) throw error;

      if (data.success) {
        addResult('delete-subscription', 'success', `Subscription ${subscriptionId} deleted successfully`);
        listSubscriptions(); // Refresh list
        toast({
          title: "Success",
          description: "Subscription deleted successfully"
        });
      } else {
        addResult('delete-subscription', 'error', data.error || 'Failed to delete subscription');
      }
    } catch (error: any) {
      addResult('delete-subscription', 'error', error.message);
    }
  };

  const listSubscriptions = async () => {
    try {
      setLoading(true);
      addResult('list-subscriptions', 'loading', 'Listing active subscriptions...');
      
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'list' }
      });

      if (error) throw error;

      console.log('📋 Subscription response:', data);
      
      if (data.success && data.subscriptions) {
        setSubscriptions(data.subscriptions);
        addResult('list-subscriptions', 'success', 
          `Found ${data.subscriptions.length} active subscriptions`, data.subscriptions);
        
        // Log details for debugging
        data.subscriptions.forEach((sub: Subscription, index: number) => {
          console.log(`📋 Subscription ${index + 1}:`);
          console.log(`   ID: ${sub.id}`);
          console.log(`   Resource: ${sub.resource}`);
          console.log(`   NotificationURL: ${sub.notificationUrl}`);
          console.log(`   Expiration: ${sub.expirationDateTime}`);
        });
        
        toast({
          title: "Success", 
          description: `Found ${data.subscriptions.length} active subscriptions`
        });
      } else {
        addResult('list-subscriptions', 'error', data.error || 'Failed to list subscriptions');
        toast({
          title: "Error",
          description: "Failed to list subscriptions",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('❌ Failed to list subscriptions:', error);
      addResult('list-subscriptions', 'error', error.message);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sendTestEmail = async () => {
    try {
      console.log('📧 Step 3: Sending test email...');
      addResult('send-email', 'loading', 'Sending test email...');
      
      const { data, error } = await supabase.functions.invoke('test-email-flow', {
        body: { 
          action: 'send-test-email',
          emailData: testEmail
        }
      });

      if (error) throw error;

      console.log('✅ Test email sent:', data);
      addResult('send-email', data.success ? 'success' : 'error', 
        data.success ? 'Test email sent successfully' : data.response, data);
      
      if (data.success) {
        toast({
          title: "Success",
          description: "Test email sent! Check for new quotes in ~10 seconds."
        });
        // Wait a bit then check for new quotes
        setTimeout(() => {
          checkQuotes();
          fetchAllData();
        }, 8000);
      } else {
        toast({
          title: "Error",
          description: "Failed to send test email",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('❌ Failed to send test email:', error);
      addResult('send-email', 'error', error.message);
      toast({
        title: "Error", 
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const checkQuotes = async () => {
    try {
      addResult('check-quotes', 'loading', 'Checking quotes table...');
      
      const { data: allQuotes, error } = await supabase
        .from('quotes')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      
      console.log('📊 Recent quotes:', allQuotes);
      setQuotes(allQuotes || []);
      
      const recentQuote = allQuotes?.find(q => {
        const isRecent = new Date(q.created_at) > new Date(Date.now() - 10 * 60 * 1000); // Last 10 minutes
        const hasTestContent = q.part_number?.toLowerCase().includes('widget') || 
                              q.description?.toLowerCase().includes('widget') ||
                              (q.ai_analysis as any)?.extractedData?.prices?.some((p: string) => p.includes('150'));
        return isRecent && hasTestContent;
      });
      
      if (recentQuote) {
        console.log('🎯 Found recent test quote:', recentQuote);
        console.log('🤖 AI Analysis:', recentQuote.ai_analysis);
        
        addResult('check-quotes', 'success', 
          `Found test quote! Part: ${recentQuote.part_number}, Score: ${recentQuote.relevance_score}%`, 
          recentQuote);
          
        toast({
          title: "Success!",
          description: `Test quote found! Relevance: ${recentQuote.relevance_score}%`
        });
      } else if (allQuotes?.length === 0) {
        addResult('check-quotes', 'error', 'No quotes found in database');
        toast({
          title: "Info",
          description: "No quotes found. Email may still be processing or not reaching webhook.",
          variant: "destructive"
        });
      } else {
        addResult('check-quotes', 'error', `Found ${allQuotes?.length} quotes but none match test criteria`);
        console.log('⚠️ No matching test quote found. Existing quotes:', allQuotes?.slice(0, 3));
      }
    } catch (error: any) {
      console.error('❌ Error checking quotes:', error);
      addResult('check-quotes', 'error', error.message);
      toast({
        title: "Error",
        description: "Error checking quotes table",
        variant: "destructive"
      });
    }
  };

  const createTestQuote = async () => {
    try {
      addResult('create-test-quote', 'loading', 'Creating test quote directly...');
      
      const { data, error } = await supabase.functions.invoke('test-quote-direct', {
        body: {}
      });

      if (error) throw error;

      if (data.success) {
        addResult('create-test-quote', 'success', `Test quote created: ${data.quote.part_number}`, data.quote);
        fetchAllData(); // Refresh all data
        toast({
          title: "Success",
          description: "Test quote created successfully!"
        });
      } else {
        addResult('create-test-quote', 'error', data.error || 'Failed to create test quote');
      }
    } catch (error: any) {
      addResult('create-test-quote', 'error', error.message);
      toast({
        title: "Error",
        description: "Failed to create test quote",
        variant: "destructive"
      });
    }
  };

  const createNewSubscription = async () => {
    try {
      addResult('create-subscription', 'loading', 'Creating new subscription...');
      
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'create' }
      });

      if (error) throw error;

      if (data.success) {
        addResult('create-subscription', 'success', 'New subscription created successfully', data);
        listSubscriptions(); // Refresh list
        toast({
          title: "Success",
          description: "New subscription created successfully"
        });
      } else {
        addResult('create-subscription', 'error', data.error || 'Failed to create subscription');
      }
    } catch (error: any) {
      addResult('create-subscription', 'error', error.message);
    }
  };

  const getStatusIcon = (status: 'success' | 'error' | 'loading') => {
    switch (status) {
      case 'success': return <CheckCircle2 className="h-4 w-4 text-success" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-destructive" />;
      case 'loading': return <Loader2 className="h-4 w-4 animate-spin" />;
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🧪 Email Flow Test Suite
            <Badge variant="outline">Debug Mode</Badge>
          </CardTitle>
          <CardDescription>
            Test and debug the complete email processing flow from Microsoft Graph to Supabase quotes
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-6">
            {/* Action Buttons */}
            <div className="flex gap-2 flex-wrap">
              <Button onClick={listSubscriptions} disabled={loading}>
                <RefreshCw className="h-4 w-4 mr-2" />
                List Subscriptions
              </Button>
              
              <Button onClick={createNewSubscription} disabled={loading} variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Create Subscription
              </Button>
              
              <Button onClick={sendTestEmail} disabled={loading}>
                <Send className="h-4 w-4 mr-2" />
                Send Test Email
              </Button>
              
              <Button onClick={checkQuotes} disabled={loading}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Check Quotes
              </Button>

              <Button onClick={createTestQuote} disabled={loading} variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Create Test Quote
              </Button>
            </div>

            {/* Enhanced Subscription Debug Section */}
            <Card>
              <CardHeader>
                <CardTitle>🔧 Subscription & Webhook Debug</CardTitle>
                <CardDescription>Advanced debugging tools for Graph API subscriptions and webhook connectivity</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                  <Button onClick={handleListSubscriptions} className="w-full">
                    📋 List Subscriptions
                  </Button>
                  <Button onClick={handleCreateSubscription} className="w-full">
                    ➕ Create Subscription
                  </Button>
                  <Button 
                    onClick={handleTestProcessMsgraph}
                    className="w-full"
                  >
                    🧪 Test Process-Msgraph Function
                  </Button>
                  <Button 
                    onClick={() => {
                      if (subscriptionsData?.data?.details?.length > 0) {
                        handleRenewSubscription(subscriptionsData.data.details[0].id);
                      }
                    }}
                    disabled={!subscriptionsData?.data?.details?.length}
                    className="w-full"
                  >
                    🔄 Renew Subscription
                  </Button>
                  <Button onClick={handleTestWebhook} className="w-full">
                    🔧 Test Webhook
                  </Button>
                </div>

                {subscriptionsData && (
                  <div className="mt-4 space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Debug Information:</h4>
                      
                      {subscriptionsData?.data?.success && (
                        <div className="mb-4">
                          <h5 className="font-medium text-green-600 mb-2">✅ Active Subscriptions ({subscriptionsData.data.count || 0}):</h5>
                          {subscriptionsData.data.details?.map((sub: any) => (
                            <div key={sub.id} className="bg-green-50 p-3 rounded mb-2 text-sm">
                              <div><strong>ID:</strong> {sub.id}</div>
                              <div><strong>Resource:</strong> {sub.resource}</div>
                              <div><strong>Notification URL:</strong> {sub.notificationUrl}</div>
                              <div><strong>Expires:</strong> {sub.expirationDateTime}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {subscriptionsData?.webhookTest && (
                        <div className="mb-4">
                          <h5 className="font-medium mb-2">
                            {subscriptionsData.webhookTest.data?.success ? '✅' : '❌'} Webhook Test:
                          </h5>
                          <div className="bg-gray-50 p-3 rounded text-sm">
                            <div><strong>URL:</strong> {subscriptionsData.webhookTest.data?.webhookUrl}</div>
                            <div><strong>Status:</strong> {subscriptionsData.webhookTest.data?.status}</div>
                            <div><strong>Response:</strong> {subscriptionsData.webhookTest.data?.response}</div>
                          </div>
                        </div>
                      )}
                      
                      <details className="mt-4">
                        <summary className="font-medium cursor-pointer">🔍 Full Response Data</summary>
                        <pre className="bg-gray-100 p-3 rounded text-xs overflow-auto mt-2 max-h-96">
                          {JSON.stringify(subscriptionsData, null, 2)}
                        </pre>
                      </details>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Test Email Configuration */}
            <Card>
              <CardHeader>
                <CardTitle>Test Email Configuration</CardTitle>
                <CardDescription>Configure the test email that will be sent to verify the processing flow</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="to">To Email</Label>
                    <Input 
                      id="to"
                      value={testEmail.to}
                      onChange={(e) => setTestEmail(prev => ({...prev, to: e.target.value}))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="subject">Subject (with RFQ reference)</Label>
                    <Input 
                      id="subject"
                      value={testEmail.subject}
                      onChange={(e) => setTestEmail(prev => ({...prev, subject: e.target.value}))}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="body">Email Body (with quote details)</Label>
                  <Textarea 
                    id="body"
                    value={testEmail.body}
                    onChange={(e) => setTestEmail(prev => ({...prev, body: e.target.value}))}
                    rows={8}
                    className="font-mono text-sm"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Results Status */}
            {results.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {results.map((result, index) => (
                      <div key={index} className="flex items-center gap-2 p-2 border rounded">
                        {getStatusIcon(result.status)}
                        <span className="font-medium">{result.step}:</span>
                        <span className={result.status === 'error' ? 'text-destructive' : ''}>{result.message}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Current Database Status */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Current RFQs ({rfqs.length})</CardTitle>
                  <CardDescription>Available RFQs for testing (showing last 8 chars of ID)</CardDescription>
                </CardHeader>
                <CardContent>
                  {rfqs.length > 0 ? (
                    <div className="space-y-2">
                      {rfqs.slice(0, 5).map(rfq => (
                        <div key={rfq.id} className="text-sm flex items-center justify-between">
                          <span className="font-mono bg-muted px-2 py-1 rounded">{rfq.id.slice(-8)}</span>
                          <Badge variant="outline">{rfq.status}</Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No RFQs found</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Quotes ({quotes.length})</CardTitle>
                  <CardDescription>Quotes processed from emails</CardDescription>
                </CardHeader>
                <CardContent>
                  {quotes.length === 0 ? (
                    <p className="text-muted-foreground">No quotes found. Emails may not be processing correctly.</p>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {quotes.slice(0, 5).map((quote) => (
                        <div key={quote.id} className="text-sm border-l-2 border-primary pl-2">
                           <p><strong>Sender:</strong> {(quote as any).sender || 'Unknown'}</p>
                           <p><strong>Part:</strong> {quote.part_number}</p>
                           <p><strong>Price:</strong> {quote.unit_price ? `${quote.currency || 'USD'} ${quote.unit_price}` : 'N/A'}</p>
                           <p><strong>Status:</strong> {quote.quote_status || (quote as any).processing_status}</p>
                           {(quote as any).rfq_id && (
                             <p><strong>RFQ ID:</strong> {(quote as any).rfq_id}</p>
                           )}
                           {(quote as any).extracted_data && typeof (quote as any).extracted_data === 'object' && (
                             <div>
                               <p><strong>AI Extracted:</strong></p>
                               <div className="ml-2 text-xs">
                                 {(quote as any).extracted_data.items && (quote as any).extracted_data.items.length > 0 && (
                                   <p>Items: {(quote as any).extracted_data.items.join(', ')}</p>
                                 )}
                                 {(quote as any).extracted_data.prices && (quote as any).extracted_data.prices.length > 0 && (
                                   <p>Prices: {(quote as any).extracted_data.prices.join(', ')}</p>
                                 )}
                                 {(quote as any).extracted_data.dates && (quote as any).extracted_data.dates.length > 0 && (
                                   <p>Dates: {(quote as any).extracted_data.dates.join(', ')}</p>
                                 )}
                                 {(quote as any).extracted_data.rates && (quote as any).extracted_data.rates.length > 0 && (
                                   <p>Rates: {(quote as any).extracted_data.rates.join(', ')}</p>
                                 )}
                               </div>
                             </div>
                           )}
                           {quote.ai_analysis?.extractedData && (
                             <p><strong>Legacy Extracted:</strong> {JSON.stringify(quote.ai_analysis.extractedData)}</p>
                           )}
                          <p className="text-xs text-muted-foreground">{new Date(quote.created_at).toLocaleString()}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Communications ({communications.length})</CardTitle>
                  <CardDescription>Email processing logs</CardDescription>
                </CardHeader>
                <CardContent>
                  {communications.length === 0 ? (
                    <p className="text-muted-foreground">No communications logged</p>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {communications.slice(0, 5).map((comm) => (
                        <div key={comm.id} className="text-sm border-l-2 border-secondary pl-2">
                          <p><strong>Type:</strong> {comm.communication_type}</p>
                          <p><strong>Subject:</strong> {comm.subject?.substring(0, 40)}...</p>
                          <p><strong>From:</strong> {comm.metadata?.email_from || comm.metadata?.from_email || 'N/A'}</p>
                          {comm.metadata?.rfq_reference && (
                            <p><strong>RFQ Ref:</strong> {comm.metadata.rfq_reference}</p>
                          )}
                          <p className="text-xs text-muted-foreground">{new Date(comm.created_at).toLocaleString()}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Active Subscriptions */}
            {subscriptions.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Active Subscriptions ({subscriptions.length})</CardTitle>
                  <CardDescription>Microsoft Graph email subscriptions monitoring for new messages</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Resource</TableHead>
                        <TableHead>Expiration</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subscriptions.map((sub) => (
                        <TableRow key={sub.id}>
                          <TableCell className="font-mono text-sm">{sub.id.slice(0, 8)}...</TableCell>
                          <TableCell className="text-sm">{sub.resource}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {new Date(sub.expirationDateTime).toLocaleDateString()}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button 
                              size="sm" 
                              variant="destructive" 
                              onClick={() => deleteSubscription(sub.id)}
                              disabled={loading}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}

            {/* Detailed Quotes Table */}
            {quotes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Recent Quotes Analysis</CardTitle>
                  <CardDescription>AI-processed quotes with extraction details</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Lead Time</TableHead>
                        <TableHead>Relevance</TableHead>
                        <TableHead>AI Analysis</TableHead>
                        <TableHead>Created</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {quotes.slice(0, 10).map((quote) => (
                        <TableRow key={quote.id}>
                          <TableCell className="font-medium">{quote.part_number}</TableCell>
                          <TableCell>
                            {quote.unit_price ? `$${quote.unit_price} ${quote.currency}` : 'N/A'}
                          </TableCell>
                          <TableCell>
                            {quote.lead_time_days ? `${quote.lead_time_days} days` : 'N/A'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={quote.relevance_score > 70 ? 'default' : 'secondary'}>
                              {quote.relevance_score}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {(quote.ai_analysis as any)?.hasPrice && (
                                <Badge variant="outline" className="text-xs">Price</Badge>
                              )}
                              {(quote.ai_analysis as any)?.hasAvailability && (
                                <Badge variant="outline" className="text-xs">Stock</Badge>
                              )}
                              {(quote.ai_analysis as any)?.isNegativeResponse && (
                                <Badge variant="destructive" className="text-xs">Negative</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {new Date(quote.created_at).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}

            {/* Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>📋 Testing Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li><strong>List Subscriptions:</strong> Check existing Microsoft Graph subscriptions for inbox monitoring</li>
                  <li><strong>Delete Duplicates:</strong> Remove extra subscriptions if multiple are found (keep only one active)</li>
                  <li><strong>Create Subscription:</strong> Create new subscription if none exists or all were deleted</li>
                  <li><strong>Send Test Email:</strong> Send a test RFQ response email to trigger the processing flow</li>
                  <li><strong>Check Quotes:</strong> Verify the email was received, processed by AI, and saved as a quote</li>
                </ol>
                
                <Separator className="my-4" />
                
                <div className="space-y-2">
                  <p className="text-sm font-medium">🔗 Manual Webhook Test:</p>
                  <code className="block bg-muted p-2 rounded text-xs">
                    curl -X POST "https://pibbqroawdvfsouronmn.supabase.co/functions/v1/msgraph-webhook?validationToken=test123"
                  </code>
                  <p className="text-xs text-muted-foreground">Should return: <code>test123</code> with status 200</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TestEmailFlow;