import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Settings } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface EmailConfig {
  id: string;
  from_email: string;
  from_name: string;
}

export function EmailConfigDialog() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState<EmailConfig | null>(null);
  const [formData, setFormData] = useState({
    from_email: '',
    from_name: ''
  });

  useEffect(() => {
    if (open) {
      loadEmailConfig();
    }
  }, [open]);

  const loadEmailConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('email_config')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setConfig(data);
        setFormData({
          from_email: data.from_email,
          from_name: data.from_name
        });
      } else {
        // No config exists, use defaults
        setFormData({
          from_email: 'rfqs@suatfuels.com',
          from_name: 'AeroSourcing'
        });
      }
    } catch (error) {
      console.error('Error loading email config:', error);
      toast.error("Error loading email configuration");
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      if (config) {
        // Update existing config
        const { error } = await supabase
          .from('email_config')
          .update({
            from_email: formData.from_email,
            from_name: formData.from_name
          })
          .eq('id', config.id);

        if (error) throw error;
      } else {
        // Create new config
        const { error } = await supabase
          .from('email_config')
          .insert({
            from_email: formData.from_email,
            from_name: formData.from_name
          });

        if (error) throw error;
      }

      toast.success("Email configuration updated successfully");
      setOpen(false);
    } catch (error) {
      console.error('Error saving email config:', error);
      toast.error("Error saving email configuration");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Settings className="h-4 w-4 mr-2" />
          Email Config
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Email Configuration</DialogTitle>
          <DialogDescription>
            Configure the sender email address for RFQ notifications.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="from_name" className="text-right">
              From Name
            </Label>
            <Input
              id="from_name"
              className="col-span-3"
              value={formData.from_name}
              onChange={(e) => setFormData({ ...formData, from_name: e.target.value })}
              placeholder="AeroSourcing"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="from_email" className="text-right">
              From Email
            </Label>
            <Input
              id="from_email"
              type="email"
              className="col-span-3"
              value={formData.from_email}
              onChange={(e) => setFormData({ ...formData, from_email: e.target.value })}
              placeholder="rfqs@suatfuels.com"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button type="button" onClick={handleSave} disabled={loading}>
            {loading ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}