import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { Loader2, Mail, Settings, CheckCircle, AlertTriangle, Trash2, RefreshCw, Activity } from "lucide-react";
import { DiagnosticsPanel } from "./DiagnosticsPanel";

interface Subscription {
  id: string;
  resource: string;
  changeType: string;
  notificationUrl: string;
  expirationDateTime: string;
  clientState: string;
}

export const EmailProcessingSetup = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessingEmails, setIsProcessingEmails] = useState(false);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [isSubscriptionsLoading, setIsSubscriptionsLoading] = useState(true);
  const [listFailed, setListFailed] = useState(false);
  const [errorDetails, setErrorDetails] = useState<any>(null);
  const [showErrorModal, setShowErrorModal] = useState(false);

  const loadSubscriptions = async () => {
    setIsSubscriptionsLoading(true);
    setListFailed(false);
    try {
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'list' }
      });
      
      if (error) {
        console.error('Function error:', error);
        toast.error(error.message || "Edge Function error");
        setSubscriptions([]);
        setListFailed(true);
        return;
      }
      
      if (data?.success === false) {
        console.error('Graph API error:', data.details);
        const errorMsg = `Status: ${data.details?.status || 'unknown'}\n${JSON.stringify(data.details?.body || data.error, null, 2)}`;
        toast.error(errorMsg);
        setSubscriptions([]);
        setListFailed(true);
        return;
      }
      
      // Handle new response format: data.data.value contains the subscriptions
      const subscriptionData = data?.data?.value || [];
      setSubscriptions(subscriptionData);
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
      setSubscriptions([]);
      setListFailed(true);
    } finally {
      setIsSubscriptionsLoading(false);
    }
  };

  useEffect(() => {
    loadSubscriptions();
  }, []);

  const handleCreateSubscription = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'create' }
      });
      
      if (error) {
        console.error('Function error:', error);
        toast.error(error.message || "Edge Function error");
        return;
      }
      
      if (data?.success === false) {
        console.error('Graph API error:', data.details);
        setErrorDetails(data);
        setShowErrorModal(true);
        return;
      }
      
      toast.success('Microsoft Graph subscription created successfully!');
      console.log('Webhook URL:', data.webhook_url);
      console.log('Subscription:', data.subscription);
      
      // Try to reload subscriptions, but don't fail if it doesn't work
      await loadSubscriptions();
      if (listFailed) {
        toast.info("Subscription created successfully, but listing failed. Check diagnostics for permissions.");
      }
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleProcessInboxEmails = async () => {
    setIsProcessingEmails(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-emails-from-inbox', {});
      
      if (error) {
        console.error('Function error:', error);
        toast.error(error.message || "Edge Function error");
        return;
      }
      
      if (data?.success === false) {
        console.error('Processing error:', data.error);
        toast.error(data.error || "Failed to process emails");
        return;
      }
      
      toast.success(`Procesado: ${data.processed} exitosos, ${data.failed} fallos de ${data.total} emails`);
      console.log('Email processing results:', data);
      
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
    } finally {
      setIsProcessingEmails(false);
    }
  };

  const handleDeleteSubscription = async (subscriptionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('setup-graph-subscription', {
        body: { action: 'delete', id: subscriptionId }
      });
      
      if (error) {
        console.error('Function error:', error);
        toast.error(error.message || "Edge Function error");
        return;
      }
      
      if (data?.success === false) {
        console.error('Graph API error:', data.details);
        setErrorDetails(data);
        setShowErrorModal(true);
        return;
      }
      
      toast.success('Subscription deleted successfully!');
      await loadSubscriptions();
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
    }
  };

  const isExpiringSoon = (expirationDateTime: string) => {
    const expiration = new Date(expirationDateTime);
    const now = new Date();
    const hoursUntilExpiration = (expiration.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilExpiration < 24;
  };

  const rfqSubscriptions = subscriptions.filter(sub => {
    const now = new Date();
    const expiration = new Date(sub.expirationDateTime);
    return sub.notificationUrl?.endsWith('/functions/v1/msgraph-webhook') && expiration > now;
  });

  return (
    <div className="space-y-6">
      {/* Setup Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Mail className="h-5 w-5" />
              <CardTitle>Microsoft 365 Email Processing</CardTitle>
            </div>
            <DiagnosticsPanel />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Configura el procesamiento automático de correos de respuesta de proveedores desde rfqs@suatfuels.com usando Microsoft Graph API y OpenAI.
          </p>

          <Alert>
            <Settings className="h-4 w-4" />
            <AlertDescription>
              <strong>Configuración requerida:</strong>
              <ul className="mt-2 ml-4 list-disc space-y-1 text-sm">
                <li>Microsoft 365 tenant configurado con permisos Mail.Read para aplicación</li>
                <li>Secrets configurados: MS_TENANT_ID, MS_CLIENT_ID, MS_CLIENT_SECRET</li>
                <li>OpenAI API key configurado para procesamiento con GPT-4.1-mini</li>
                <li><strong>Proceso emails pendientes:</strong> Usa el botón <Activity className="inline h-3 w-3 mx-1" /> para procesar emails ya recibidos en inbox</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="flex space-x-2">
            <Button 
              onClick={handleCreateSubscription} 
              disabled={isLoading}
              className="flex-1"
            >
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Crear/Renovar Suscripción
            </Button>
            <Button 
              variant="outline" 
              onClick={handleProcessInboxEmails}
              disabled={isProcessingEmails}
            >
              {isProcessingEmails ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Activity className="h-4 w-4" />
              )}
            </Button>
            <Button 
              variant="outline" 
              onClick={loadSubscriptions}
              disabled={isSubscriptionsLoading}
            >
              {isSubscriptionsLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Subscriptions Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Estado de Suscripciones
            <Badge variant={rfqSubscriptions.length > 0 ? "default" : "secondary"}>
              {rfqSubscriptions.length} activa{rfqSubscriptions.length !== 1 ? 's' : ''}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isSubscriptionsLoading ? (
            <div className="flex items-center justify-center p-4">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span className="ml-2">Cargando suscripciones...</span>
            </div>
          ) : rfqSubscriptions.length === 0 ? (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {listFailed ? (
                  <>
                    No se pudo listar suscripciones (ver Diagnostics), pero puedes intentar crear una nueva.
                  </>
                ) : (
                  <>
                    No hay suscripciones activas para el procesamiento de emails de RFQ. 
                    Crear una suscripción para comenzar a recibir notificaciones automáticas.
                  </>
                )}
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-3">
              {rfqSubscriptions.map((subscription) => (
                <div key={subscription.id} className="border rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium text-sm">Suscripción Activa</span>
                      {isExpiringSoon(subscription.expirationDateTime) && (
                        <Badge variant="destructive">Expira Pronto</Badge>
                      )}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteSubscription(subscription.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div><strong>ID:</strong> {subscription.id}</div>
                    <div><strong>Recurso:</strong> {subscription.resource}</div>
                    <div><strong>Tipo:</strong> {subscription.changeType}</div>
                    <div><strong>Webhook:</strong> {subscription.notificationUrl}</div>
                    <div>
                      <strong>Expira:</strong> {new Date(subscription.expirationDateTime).toLocaleString('es-ES')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Error Details Modal */}
      <Dialog open={showErrorModal} onOpenChange={setShowErrorModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Error Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold">Error:</h4>
              <p className="text-sm text-muted-foreground">{errorDetails?.error}</p>
            </div>
            {errorDetails?.details && (
              <div>
                <h4 className="font-semibold">Details:</h4>
                <div className="text-sm text-muted-foreground">
                  <p><strong>Status:</strong> {errorDetails.details.status}</p>
                  <div className="mt-2">
                    <strong>Response:</strong>
                    <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-auto max-h-64">
                      {typeof errorDetails.details.body === 'string' 
                        ? errorDetails.details.body 
                        : JSON.stringify(errorDetails.details.body, null, 2)
                      }
                    </pre>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* How it Works */}
      <Card>
        <CardHeader>
          <CardTitle>Cómo Funciona</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 text-sm">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary font-semibold text-xs">1</span>
              </div>
              <div>
                <strong>Ingesta:</strong> Microsoft Graph envía webhooks cuando llegan nuevos emails a rfqs@suatfuels.com
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary font-semibold text-xs">2</span>
              </div>
              <div>
                <strong>Vinculación:</strong> Extrae RFQ ID del destinatario (rfqs+rfq{'{ID}'}@suatfuels.com), asunto, o headers
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary font-semibold text-xs">3</span>
              </div>
              <div>
                <strong>Procesamiento:</strong> OpenAI GPT-4.1-mini extrae datos estructurados (precios, plazos, disponibilidad)
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary font-semibold text-xs">4</span>
              </div>
              <div>
                <strong>Almacenamiento:</strong> Crea quotes automáticamente para respuestas positivas o las marca para revisión
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};