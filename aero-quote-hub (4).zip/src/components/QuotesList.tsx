import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Award, Clock, AlertTriangle, CheckCircle, XCircle, TrendingUp, Filter, Brain } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";
import { TestQuoteProcessor } from "./TestQuoteProcessor";

interface Quote {
  id: string;
  rfq_id: string;
  supplier_id: string;
  part_number: string;
  condition?: 'FN' | 'OH' | 'SV' | 'AR' | 'NS';
  qty_available?: number;
  unit_price?: number;
  currency?: string;
  lead_time_days?: number;
  moq?: number;
  valid_until?: string;
  warranty_months?: number;
  incoterm?: string | null;
  delivery_point?: string | null;
  certs?: string | null;
  score: number;
  created_at: string;
  // New AI fields
  processing_status?: string;
  relevance_score?: number;
  ai_analysis?: any;
  quote_status?: string;
  processed_at?: string;
  is_relevant?: boolean;
  suppliers?: {
    name: string;
    region?: string;
  };
}

const getConditionColor = (condition: Quote['condition']) => {
  switch (condition) {
    case 'FN':
      return 'bg-success text-success-foreground';
    case 'OH':
      return 'bg-primary text-primary-foreground';
    case 'SV':
      return 'bg-warning text-warning-foreground';
    case 'AR':
      return 'bg-muted text-muted-foreground';
    case 'NS':
      return 'bg-destructive text-destructive-foreground';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getScoreColor = (score: number) => {
  if (score >= 80) return 'text-success';
  if (score >= 60) return 'text-primary';
  if (score >= 40) return 'text-warning';
  return 'text-destructive';
};

const getStatusColor = (status?: string) => {
  switch (status) {
    case 'pending_review':
      return 'bg-warning text-warning-foreground';
    case 'accepted':
      return 'bg-success text-success-foreground';
    case 'rejected':
      return 'bg-destructive text-destructive-foreground';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getRelevanceColor = (score?: number) => {
  if (!score) return 'text-muted-foreground';
  if (score >= 80) return 'text-success';
  if (score >= 60) return 'text-primary';
  if (score >= 40) return 'text-warning';
  return 'text-destructive';
};

export const QuotesList = () => {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRelevantOnly, setShowRelevantOnly] = useState(true);

  useEffect(() => {
    fetchQuotes();
  }, []);

  const fetchQuotes = async () => {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          *,
          suppliers:supplier_id (name, region)
        `)
        .order('relevance_score', { ascending: false })
        .order('score', { ascending: false });

      if (error) {
        console.error('Error fetching quotes:', error);
        toast({
          title: "Error",
          description: "Failed to load quotes",
          variant: "destructive",
        });
        return;
      }

      setQuotes(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load quotes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredQuotes = showRelevantOnly 
    ? quotes.filter(quote => quote.is_relevant !== false)
    : quotes;

  const updateQuoteStatus = async (quoteId: string, status: string) => {
    try {
      const { error } = await supabase
        .from('quotes')
        .update({ quote_status: status })
        .eq('id', quoteId);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to update quote status",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Success",
        description: `Quote ${status}`,
      });

      fetchQuotes();
    } catch (error) {
      console.error('Error updating quote status:', error);
    }
  };

  const isValidityExpiring = (validUntil?: string) => {
    if (!validUntil) return false;
    const validDate = new Date(validUntil);
    const now = new Date();
    const diffInHours = Math.ceil((validDate.getTime() - now.getTime()) / (1000 * 60 * 60));
    return diffInHours <= 48;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Quotes</CardTitle>
          <CardDescription>Loading quotes...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (filteredQuotes.length === 0) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Quotes</CardTitle>
              <CardDescription>
                {showRelevantOnly 
                  ? "No relevant quotes found. AI has filtered out non-commercial responses." 
                  : "No quotes found. Quotes will appear here when suppliers respond to RFQs."
                }
              </CardDescription>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowRelevantOnly(!showRelevantOnly)}
              className="gap-2"
            >
              <Filter className="h-4 w-4" />
              {showRelevantOnly ? 'Show All' : 'Show Relevant'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground">
            {quotes.length === 0 ? "No quotes available" : `${quotes.length} quotes filtered out`}
          </p>
          {quotes.length > 0 && showRelevantOnly && (
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={() => setShowRelevantOnly(false)}
            >
              Show all quotes including filtered ones
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <TestQuoteProcessor />
      <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Quotes ({filteredQuotes.length}{quotes.length !== filteredQuotes.length ? ` of ${quotes.length}` : ''})</CardTitle>
            <CardDescription>
              AI-processed supplier quotes ranked by relevance and score
              {showRelevantOnly && (
                <span className="ml-2 text-primary">• Showing relevant quotes only</span>
              )}
            </CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowRelevantOnly(!showRelevantOnly)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" />
            {showRelevantOnly ? 'Show All' : 'Show Relevant'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Quote Details</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>AI Analysis</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Lead Time</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredQuotes.map((quote) => (
                <TableRow key={quote.id} className={quote.is_relevant === false ? 'opacity-60' : ''}>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="font-medium">{quote.part_number}</div>
                      <div className="text-sm text-muted-foreground">
                        {quote.qty_available ? `Qty: ${quote.qty_available}` : 'Quantity not specified'}
                        {quote.condition && (
                          <Badge className={`ml-2 ${getConditionColor(quote.condition)}`}>
                            {quote.condition}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="font-medium">{quote.suppliers?.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {quote.suppliers?.region || 'Region not specified'}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1">
                        <Brain className="h-4 w-4 text-primary" />
                        <span className={`font-medium ${getRelevanceColor(quote.relevance_score)}`}>
                          {quote.relevance_score || 'N/A'}%
                        </span>
                      </div>
                      <div className="flex gap-1">
                        {quote.ai_analysis?.hasPrice && (
                          <Badge variant="outline" className="text-xs">
                            <TrendingUp className="h-3 w-3 mr-1" />
                            Price
                          </Badge>
                        )}
                        {quote.ai_analysis?.hasAvailability && (
                          <Badge variant="outline" className="text-xs">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Stock
                          </Badge>
                        )}
                        {quote.ai_analysis?.isNegativeResponse && (
                          <Badge variant="destructive" className="text-xs">
                            <XCircle className="h-3 w-3 mr-1" />
                            No Quote
                          </Badge>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    {quote.unit_price ? (
                      <div className="font-medium">
                        ${quote.unit_price.toLocaleString()} {quote.currency || 'USD'}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">Not specified</span>
                    )}
                    {quote.moq && (
                      <div className="text-sm text-muted-foreground">
                        MOQ: {quote.moq}
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {quote.lead_time_days ? `${quote.lead_time_days} days` : 'Not specified'}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <Badge className={getStatusColor(quote.quote_status)}>
                        {quote.quote_status?.replace('_', ' ') || 'pending'}
                      </Badge>
                      {quote.valid_until && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          {format(new Date(quote.valid_until), 'MMM dd')}
                          {isValidityExpiring(quote.valid_until) && (
                            <Clock className="h-3 w-3 text-warning" />
                          )}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${getScoreColor(quote.score)}`}>
                        {quote.score}
                      </span>
                      {quote.score >= 80 && (
                        <Award className="h-4 w-4 text-success" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4" />
                      </Button>
                      {quote.quote_status === 'pending_review' && (
                        <>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateQuoteStatus(quote.id, 'accepted')}
                          >
                            <CheckCircle className="h-4 w-4 text-success" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateQuoteStatus(quote.id, 'rejected')}
                          >
                            <XCircle className="h-4 w-4 text-destructive" />
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
    </div>
  );
};