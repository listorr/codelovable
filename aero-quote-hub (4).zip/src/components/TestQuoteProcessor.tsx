import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export const TestQuoteProcessor = () => {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleTestProcessing = async () => {
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('test-quote-processing');
      
      if (error) {
        console.error('Function error:', error);
        toast.error(`Error: ${error.message}`);
      } else {
        console.log('Processing result:', data);
        toast.success('Quote procesado exitosamente!');
        // Refresh the page to see the new quote
        window.location.reload();
      }
    } catch (error: any) {
      console.error('Request error:', error);
      toast.error(`Error: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle>Test Quote Processing</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          Procesar manualmente el email de respuesta de Luis Torrente para RFQ 588D0F3E
        </p>
        <Button 
          onClick={handleTestProcessing} 
          disabled={isProcessing}
          className="w-full"
        >
          {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Procesar Quote Manual
        </Button>
      </CardContent>
    </Card>
  );
};