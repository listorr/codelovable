import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Edit, Mail, UserMinus, UserCheck, Plus, FileDown, Upload, Filter, MessageSquare } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { CreateSupplierDialog } from "./CreateSupplierDialog";
import { SupplierImportDialog } from "./SupplierImportDialog";
import { SupplierFilterDialog, SupplierFilters } from "./SupplierFilterDialog";
import { CommunicationHistoryDialog } from "./CommunicationHistoryDialog";
import { Supplier } from "@/types";

export const SuppliersList = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showFilterDialog, setShowFilterDialog] = useState(false);
  const [showCommHistoryDialog, setShowCommHistoryDialog] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [filters, setFilters] = useState<SupplierFilters>({
    regions: [],
    types: [],
    tags: [],
    activeOnly: false,
    optedInOnly: false
  });

  useEffect(() => {
    fetchSuppliers();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [suppliers, filters]);

  const applyFilters = () => {
    let filtered = [...suppliers];

    // Apply status filters
    if (filters.activeOnly) {
      filtered = filtered.filter(s => s.active);
    }
    if (filters.optedInOnly) {
      filtered = filtered.filter(s => !s.opt_out);
    }

    // Apply region filters
    if (filters.regions.length > 0) {
      filtered = filtered.filter(s => s.region && filters.regions.includes(s.region));
    }

    // Apply type filters
    if (filters.types.length > 0) {
      filtered = filtered.filter(s => 
        s.types.some(type => filters.types.includes(type))
      );
    }

    // Apply tag filters
    if (filters.tags.length > 0) {
      filtered = filtered.filter(s => 
        s.tags && s.tags.some(tag => filters.tags.includes(tag))
      );
    }

    setFilteredSuppliers(filtered);
  };

  const fetchSuppliers = async () => {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching suppliers:', error);
        toast({
          title: "Error",
          description: "Failed to load suppliers",
          variant: "destructive",
        });
        return;
      }

      setSuppliers(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load suppliers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (supplierId: string, currentActive: boolean) => {
    try {
      const { error } = await supabase
        .from('suppliers')
        .update({ active: !currentActive })
        .eq('id', supplierId);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to update supplier status",
          variant: "destructive",
        });
        return;
      }

      setSuppliers(suppliers.map(s => 
        s.id === supplierId 
          ? { ...s, active: !currentActive }
          : s
      ));

      toast({
        title: "Success",
        description: `Supplier ${!currentActive ? 'activated' : 'deactivated'} successfully`,
      });
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to update supplier status",
        variant: "destructive",
      });
    }
  };

  const toggleOptOut = async (supplierId: string, currentOptOut: boolean) => {
    try {
      const { error } = await supabase
        .from('suppliers')
        .update({ opt_out: !currentOptOut })
        .eq('id', supplierId);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to update opt-out status",
          variant: "destructive",
        });
        return;
      }

      setSuppliers(suppliers.map(s => 
        s.id === supplierId 
          ? { ...s, opt_out: !currentOptOut }
          : s
      ));

      toast({
        title: "Success",
        description: `Supplier ${!currentOptOut ? 'opted out' : 'opted in'} successfully`,
      });
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to update opt-out status",
        variant: "destructive",
      });
    }
  };

  const exportSuppliers = () => {
    const headers = ['Name', 'Emails', 'Region', 'Capabilities', 'Types', 'Active', 'Opt Out'];
    const csvContent = [
      headers.join(','),
      ...suppliers.map(supplier => [
        supplier.name,
        supplier.emails.join(';'),
        supplier.region || '',
        supplier.capabilities || '',
        supplier.types.join(';'),
        supplier.active,
        supplier.opt_out
      ].map(field => `"${field}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'suppliers.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const getSupplierTypeBadges = (types: string[]) => {
    return types.map(type => (
      <Badge key={type} variant="outline" className="text-xs mr-1">
        {type}
      </Badge>
    ));
  };

  // Get unique values for filter options
  const availableRegions = [...new Set(suppliers.map(s => s.region).filter(Boolean))];
  const availableTypes = [...new Set(suppliers.flatMap(s => s.types || []))];
  const availableTags = [...new Set(suppliers.flatMap(s => s.tags || []))];

  const activeFiltersCount = 
    filters.regions.length + 
    filters.types.length + 
    filters.tags.length + 
    (filters.activeOnly ? 1 : 0) + 
    (filters.optedInOnly ? 1 : 0);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Suppliers</CardTitle>
          <CardDescription>Loading suppliers...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const activeSuppliers = filteredSuppliers.filter(s => s.active && !s.opt_out).length;
  const inactiveSuppliers = filteredSuppliers.filter(s => !s.active || s.opt_out).length;

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Suppliers ({filteredSuppliers.length}{suppliers.length !== filteredSuppliers.length ? ` of ${suppliers.length}` : ''})</CardTitle>
              <CardDescription>
                {activeSuppliers} active • {inactiveSuppliers} inactive/opted out
                {activeFiltersCount > 0 && (
                  <span className="ml-2 text-primary">• {activeFiltersCount} filters applied</span>
                )}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowFilterDialog(true)}
                className={activeFiltersCount > 0 ? "border-primary" : ""}
              >
                <Filter className="h-4 w-4 mr-2" />
                Filter {activeFiltersCount > 0 && `(${activeFiltersCount})`}
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowImportDialog(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
              <Button variant="outline" size="sm" onClick={exportSuppliers}>
                <FileDown className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Supplier
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredSuppliers.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                {suppliers.length === 0 ? 'No suppliers available' : 'No suppliers match the current filters'}
              </p>
              {suppliers.length === 0 ? (
                <Button onClick={() => setShowCreateDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Supplier
                </Button>
              ) : (
                <Button variant="outline" onClick={() => setFilters({
                  regions: [],
                  types: [],
                  tags: [],
                  activeOnly: false,
                  optedInOnly: false
                })}>
                  Clear Filters
                </Button>
              )}
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Supplier Details</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Types</TableHead>
                    <TableHead>Capabilities</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSuppliers.map((supplier) => (
                    <TableRow key={supplier.id} className={(!supplier.active || supplier.opt_out) ? 'opacity-60' : ''}>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">{supplier.name}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-1">
                            <Mail className="h-3 w-3" />
                            {supplier.emails[0]}
                            {supplier.emails.length > 1 && (
                              <span className="text-xs">+{supplier.emails.length - 1} more</span>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {supplier.region ? (
                          <Badge variant="secondary">{supplier.region}</Badge>
                        ) : (
                          <span className="text-muted-foreground text-sm">Not specified</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {supplier.types && supplier.types.length > 0 ? (
                            getSupplierTypeBadges(supplier.types)
                          ) : (
                            <span className="text-muted-foreground text-sm">Not specified</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs truncate text-sm">
                          {supplier.capabilities || (
                            <span className="text-muted-foreground">Not specified</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {supplier.opt_out ? (
                            <Badge variant="destructive" className="gap-1">
                              <UserMinus className="h-3 w-3" />
                              Opted Out
                            </Badge>
                          ) : supplier.active ? (
                            <Badge variant="default" className="gap-1 bg-success text-success-foreground">
                              <UserCheck className="h-3 w-3" />
                              Active
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="gap-1">
                              Inactive
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              setSelectedSupplier(supplier);
                              setShowCommHistoryDialog(true);
                            }}
                          >
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant={supplier.active ? "destructive" : "default"}
                            onClick={() => toggleActive(supplier.id, supplier.active)}
                          >
                            {supplier.active ? "Deactivate" : "Activate"}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <CreateSupplierDialog 
        open={showCreateDialog} 
        onOpenChange={setShowCreateDialog}
      />

      <SupplierImportDialog 
        open={showImportDialog} 
        onOpenChange={setShowImportDialog}
        onImported={fetchSuppliers}
      />

      <SupplierFilterDialog 
        open={showFilterDialog} 
        onOpenChange={setShowFilterDialog}
        filters={filters}
        onFiltersChange={setFilters}
        availableRegions={availableRegions}
        availableTypes={availableTypes}
        availableTags={availableTags}
      />

      {selectedSupplier && (
        <CommunicationHistoryDialog 
          open={showCommHistoryDialog} 
          onOpenChange={setShowCommHistoryDialog}
          supplierId={selectedSupplier.id}
          supplierName={selectedSupplier.name}
        />
      )}
    </>
  );
};