-- Create enum types
CREATE TYPE public.priority_type AS ENUM ('AOG', 'Routine', 'Planned');
CREATE TYPE public.status_type AS ENUM ('open', 'quoted', 'closed');
CREATE TYPE public.condition_type AS ENUM ('FN', 'OH', 'SV', 'AR', 'NS');

-- Create RFQ table
CREATE TABLE public.rfqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  airline TEXT NOT NULL,
  priority priority_type NOT NULL,
  aircraft_type TEXT NOT NULL,
  delivery_to TEXT NOT NULL,
  deadline TIMESTAMP WITH TIME ZONE NOT NULL,
  part_number TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  notes TEXT,
  status status_type NOT NULL DEFAULT 'open',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create Supplier table
CREATE TABLE public.suppliers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  region TEXT,
  capabilities TEXT,
  opt_out BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create Quote table
CREATE TABLE public.quotes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rfq_id UUID NOT NULL REFERENCES public.rfqs(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  condition condition_type NOT NULL,
  qty_available INTEGER NOT NULL CHECK (qty_available > 0),
  unit_price DECIMAL(12, 2) NOT NULL CHECK (unit_price > 0),
  currency TEXT NOT NULL DEFAULT 'USD',
  lead_time_days INTEGER NOT NULL CHECK (lead_time_days >= 0),
  moq INTEGER NOT NULL DEFAULT 1 CHECK (moq > 0),
  valid_until TIMESTAMP WITH TIME ZONE NOT NULL,
  warranty_months INTEGER DEFAULT 0 CHECK (warranty_months >= 0),
  incoterm TEXT,
  delivery_point TEXT,
  certs TEXT,
  score DECIMAL(5, 2) DEFAULT 0 CHECK (score >= 0 AND score <= 100),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(rfq_id, supplier_id)
);

-- Enable Row Level Security
ALTER TABLE public.rfqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since this is a business app)
CREATE POLICY "Enable all operations for authenticated users" 
ON public.rfqs 
FOR ALL 
USING (true);

CREATE POLICY "Enable all operations for authenticated users" 
ON public.suppliers 
FOR ALL 
USING (true);

CREATE POLICY "Enable all operations for authenticated users" 
ON public.quotes 
FOR ALL 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_rfqs_updated_at
BEFORE UPDATE ON public.rfqs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_suppliers_updated_at
BEFORE UPDATE ON public.suppliers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_quotes_updated_at
BEFORE UPDATE ON public.quotes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_rfqs_status ON public.rfqs(status);
CREATE INDEX idx_rfqs_priority ON public.rfqs(priority);
CREATE INDEX idx_rfqs_airline ON public.rfqs(airline);
CREATE INDEX idx_quotes_rfq_id ON public.quotes(rfq_id);
CREATE INDEX idx_quotes_supplier_id ON public.quotes(supplier_id);
CREATE INDEX idx_quotes_score ON public.quotes(score DESC);
CREATE INDEX idx_suppliers_region ON public.suppliers(region);
CREATE INDEX idx_suppliers_opt_out ON public.suppliers(opt_out);