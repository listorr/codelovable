-- Add soft delete functionality to RFQs
ALTER TABLE public.rfqs ADD COLUMN deleted_at timestamp with time zone;
ALTER TABLE public.rfqs ADD COLUMN deleted_by uuid;
ALTER TABLE public.rfqs ADD COLUMN deletion_reason text;

-- Create activity log table for audit trail
CREATE TABLE public.activity_logs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  entity_type text NOT NULL, -- 'rfq', 'supplier', 'quote'
  entity_id uuid NOT NULL,
  action_type text NOT NULL, -- 'created', 'updated', 'deleted', 'sent'
  user_id uuid,
  details jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on activity logs
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for activity logs
CREATE POLICY "Authenticated users can view activity logs" 
ON public.activity_logs 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can create activity logs" 
ON public.activity_logs 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Add region and tags columns to suppliers for better filtering
ALTER TABLE public.suppliers ADD COLUMN tags text[] DEFAULT ARRAY[]::text[];
ALTER TABLE public.suppliers ADD COLUMN contact_name text;
ALTER TABLE public.suppliers ADD COLUMN phone text;
ALTER TABLE public.suppliers ADD COLUMN language text DEFAULT 'en';

-- Update RFQs query to exclude soft deleted by default
CREATE OR REPLACE VIEW public.active_rfqs AS 
SELECT * FROM public.rfqs WHERE deleted_at IS NULL;

-- Create function to soft delete RFQ
CREATE OR REPLACE FUNCTION public.soft_delete_rfq(
  rfq_id uuid,
  reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update RFQ with deletion info
  UPDATE public.rfqs 
  SET 
    deleted_at = now(),
    deleted_by = auth.uid(),
    deletion_reason = reason
  WHERE id = rfq_id;
  
  -- Log the deletion
  INSERT INTO public.activity_logs (
    entity_type,
    entity_id,
    action_type,
    user_id,
    details
  ) VALUES (
    'rfq',
    rfq_id,
    'deleted',
    auth.uid(),
    jsonb_build_object('reason', reason)
  );
END;
$$;