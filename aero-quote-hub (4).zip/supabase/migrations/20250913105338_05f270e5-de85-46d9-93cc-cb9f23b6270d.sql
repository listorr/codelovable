-- Create email configuration table
CREATE TABLE public.email_config (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_email TEXT NOT NULL DEFAULT 'rfqs@suatfuels.com',
  from_name TEXT NOT NULL DEFAULT 'AeroSourcing',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.email_config ENABLE ROW LEVEL SECURITY;

-- Create policy for reading email config (everyone can read)
CREATE POLICY "Email config is readable by everyone" 
ON public.email_config 
FOR SELECT 
USING (true);

-- Create policy for updating email config (authenticated users only)
CREATE POLICY "Authenticated users can update email config" 
ON public.email_config 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- Create policy for inserting email config (authenticated users only)
CREATE POLICY "Authenticated users can insert email config" 
ON public.email_config 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Insert default configuration
INSERT INTO public.email_config (from_email, from_name) VALUES ('rfqs@suatfuels.com', 'AeroSourcing');

-- Add trigger for timestamps
CREATE TRIGGER update_email_config_updated_at
BEFORE UPDATE ON public.email_config
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();