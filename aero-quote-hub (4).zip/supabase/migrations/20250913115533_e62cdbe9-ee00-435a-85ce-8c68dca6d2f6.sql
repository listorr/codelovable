-- Fix security issues from previous migration

-- Drop the security definer view and replace with a regular view
DROP VIEW IF EXISTS public.active_rfqs;

-- Create regular view without security definer
CREATE VIEW public.active_rfqs AS 
SELECT * FROM public.rfqs WHERE deleted_at IS NULL;

-- Fix the function search path
CREATE OR REPLACE FUNCTION public.soft_delete_rfq(
  rfq_id uuid,
  reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update RFQ with deletion info
  UPDATE public.rfqs 
  SET 
    deleted_at = now(),
    deleted_by = auth.uid(),
    deletion_reason = reason
  WHERE id = rfq_id;
  
  -- Log the deletion
  INSERT INTO public.activity_logs (
    entity_type,
    entity_id,
    action_type,
    user_id,
    details
  ) VALUES (
    'rfq',
    rfq_id,
    'deleted',
    auth.uid(),
    jsonb_build_object('reason', reason)
  );
END;
$$;