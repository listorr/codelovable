-- Fix security issue: Restrict access to core business tables to authenticated users only

-- Update RLS policies for rfqs table
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON public.rfqs;
CREATE POLICY "Authenticated users can manage rfqs" 
ON public.rfqs 
FOR ALL 
TO authenticated 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Update RLS policies for part_lines table
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON public.part_lines;
CREATE POLICY "Authenticated users can manage part_lines" 
ON public.part_lines 
FOR ALL 
TO authenticated 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Update RLS policies for email_threads table
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON public.email_threads;
CREATE POLICY "Authenticated users can manage email_threads" 
ON public.email_threads 
FOR ALL 
TO authenticated 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Update RLS policies for quotes table
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON public.quotes;
CREATE POLICY "Authenticated users can manage quotes" 
ON public.quotes 
FOR ALL 
TO authenticated 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Also update suppliers table for consistency
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON public.suppliers;
CREATE POLICY "Authenticated users can manage suppliers" 
ON public.suppliers 
FOR ALL 
TO authenticated 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);