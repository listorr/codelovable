-- Fix security definer view issue by dropping redundant view
-- The active_rfqs table already exists and serves the same purpose
DROP VIEW IF EXISTS public.active_rfqs;