-- Add AI processing and status tracking to quotes
ALTER TABLE public.quotes ADD COLUMN processing_status text DEFAULT 'pending';
ALTER TABLE public.quotes ADD COLUMN relevance_score numeric DEFAULT 0;
ALTER TABLE public.quotes ADD COLUMN ai_analysis jsonb;
ALTER TABLE public.quotes ADD COLUMN quote_status text DEFAULT 'pending_review';
ALTER TABLE public.quotes ADD COLUMN processed_at timestamp with time zone;
ALTER TABLE public.quotes ADD COLUMN is_relevant boolean DEFAULT true;

-- Create communication_history table
CREATE TABLE public.communication_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rfq_id uuid NOT NULL,
  supplier_id uuid NOT NULL,
  email_thread_id uuid,
  communication_type text NOT NULL, -- 'email_sent', 'quote_received', 'follow_up'
  subject text,
  content text,
  attachments text[],
  sent_at timestamp with time zone,
  received_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  metadata jsonb
);

-- Enable RLS on communication_history
ALTER TABLE public.communication_history ENABLE ROW LEVEL SECURITY;

-- Create policies for communication_history
CREATE POLICY "Authenticated users can view communication history" 
ON public.communication_history 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can create communication history" 
ON public.communication_history 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Add indexes for better performance
CREATE INDEX idx_quotes_processing_status ON public.quotes(processing_status);
CREATE INDEX idx_quotes_relevance_score ON public.quotes(relevance_score DESC);
CREATE INDEX idx_quotes_is_relevant ON public.quotes(is_relevant);
CREATE INDEX idx_communication_history_rfq_supplier ON public.communication_history(rfq_id, supplier_id);
CREATE INDEX idx_communication_history_created_at ON public.communication_history(created_at DESC);

-- Create function to analyze quote relevance with AI
CREATE OR REPLACE FUNCTION public.analyze_quote_relevance(
  quote_text text,
  subject_text text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  combined_text text;
  analysis_result jsonb;
BEGIN
  -- Combine subject and content for analysis
  combined_text := COALESCE(subject_text, '') || ' ' || COALESCE(quote_text, '');
  
  -- Simple pattern matching for now (will be enhanced by AI processing)
  analysis_result := jsonb_build_object(
    'has_pricing', (
      combined_text ~* '(\$|USD|EUR|price|cost|quote|total|amount|\d+\.\d+)' OR
      combined_text ~* '(pricing|rates|fees|charges)'
    ),
    'has_availability', (
      combined_text ~* '(available|in stock|qty|quantity|lead time|delivery|ship)' OR
      combined_text ~* '(available|stock|inventory)'
    ),
    'has_negative_response', (
      combined_text ~* '(no quote|nq|not available|out of stock|cannot quote|unable to quote)' OR
      combined_text ~* '(discontinued|obsolete|no longer available|not in stock)'
    ),
    'has_commercial_terms', (
      combined_text ~* '(payment terms|warranty|incoterm|fob|cif|moq|minimum order)' OR
      combined_text ~* '(terms and conditions|payment|warranty|guarantee)'
    )
  );
  
  RETURN analysis_result;
END;
$$;