-- Fix function search path security issue
CREATE OR REPLACE FUNCTION public.calculate_quote_score()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
DECLARE
  base_score NUMERIC := 50;
  price_score NUMERIC := 0;
  lead_time_score NUMERIC := 0;
  condition_bonus NUMERIC := 0;
  rfq_condition condition_type;
BEGIN
  -- Get RFQ condition requirement for this part
  SELECT pl.condition_req INTO rfq_condition
  FROM public.part_lines pl
  WHERE pl.rfq_id = NEW.rfq_id 
    AND pl.part_number = NEW.part_number
  LIMIT 1;

  -- Price scoring (lower price = higher score)
  IF NEW.unit_price IS NOT NULL AND NEW.unit_price > 0 THEN
    price_score := GREATEST(0, 30 - (NEW.unit_price / 1000)); -- Adjust scale as needed
  END IF;

  -- Lead time scoring (shorter lead time = higher score)
  IF NEW.lead_time_days IS NOT NULL THEN
    lead_time_score := GREATEST(0, 20 - NEW.lead_time_days);
  END IF;

  -- Condition match bonus
  IF rfq_condition IS NOT NULL AND NEW.condition = rfq_condition THEN
    condition_bonus := 20;
  END IF;

  -- Calculate final score (0-100)
  NEW.score := GREATEST(0, LEAST(100, base_score + price_score + lead_time_score + condition_bonus));

  RETURN NEW;
END;
$$;