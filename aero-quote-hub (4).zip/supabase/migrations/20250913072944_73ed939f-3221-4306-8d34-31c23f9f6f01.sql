-- Drop existing tables to recreate with new schema
DROP TABLE IF EXISTS public.quotes CASCADE;
DROP TABLE IF EXISTS public.rfqs CASCADE;
DROP TABLE IF EXISTS public.suppliers CASCADE;

-- Drop existing enums to recreate them
DROP TYPE IF EXISTS public.condition_type CASCADE;
DROP TYPE IF EXISTS public.priority_type CASCADE;
DROP TYPE IF EXISTS public.status_type CASCADE;

-- Create updated enums
CREATE TYPE public.condition_type AS ENUM ('FN', 'OH', 'SV', 'AR', 'NS');
CREATE TYPE public.priority_type AS ENUM ('AOG', 'Routine', 'Planned');
CREATE TYPE public.status_type AS ENUM ('open', 'quoted', 'closed');
CREATE TYPE public.supplier_type AS ENUM ('MRO', 'Trader', 'OEM', 'Distributor');

-- Create RFQs table with new structure
CREATE TABLE public.rfqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  priority priority_type NOT NULL DEFAULT 'Routine',
  aircraft_type TEXT,
  delivery_to TEXT,
  deadline TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  status status_type NOT NULL DEFAULT 'open',
  attachments TEXT[], -- Array of file URLs/paths
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create part_lines table for RFQ parts
CREATE TABLE public.part_lines (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rfq_id UUID NOT NULL REFERENCES public.rfqs(id) ON DELETE CASCADE,
  part_number TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  condition_req condition_type,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create suppliers table with new structure
CREATE TABLE public.suppliers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  emails TEXT[] NOT NULL CHECK (array_length(emails, 1) > 0), -- Array of emails
  region TEXT,
  capabilities TEXT,
  types supplier_type[] DEFAULT ARRAY[]::supplier_type[], -- Multi-select supplier types
  opt_out BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create quotes table with expanded fields
CREATE TABLE public.quotes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rfq_id UUID NOT NULL REFERENCES public.rfqs(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  part_number TEXT NOT NULL,
  description TEXT,
  condition condition_type,
  qty_available INTEGER CHECK (qty_available >= 0),
  unit_price NUMERIC(12,2) CHECK (unit_price >= 0),
  currency TEXT DEFAULT 'USD',
  lead_time_days INTEGER CHECK (lead_time_days >= 0),
  moq INTEGER DEFAULT 1 CHECK (moq > 0),
  valid_until TIMESTAMP WITH TIME ZONE,
  warranty_months INTEGER DEFAULT 0 CHECK (warranty_months >= 0),
  incoterm TEXT,
  delivery_point TEXT,
  certs TEXT,
  score NUMERIC(5,2) DEFAULT 0 CHECK (score >= 0 AND score <= 100),
  attachments TEXT[], -- Array of file URLs/paths
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create email_threads table for tracking conversations
CREATE TABLE public.email_threads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rfq_id UUID NOT NULL REFERENCES public.rfqs(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
  thread_id TEXT, -- Email thread ID for tracking replies
  subject TEXT,
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.rfqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.part_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_threads ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allowing all operations for now - will add proper auth later)
CREATE POLICY "Enable all operations for authenticated users" ON public.rfqs FOR ALL USING (true);
CREATE POLICY "Enable all operations for authenticated users" ON public.part_lines FOR ALL USING (true);
CREATE POLICY "Enable all operations for authenticated users" ON public.suppliers FOR ALL USING (true);
CREATE POLICY "Enable all operations for authenticated users" ON public.quotes FOR ALL USING (true);
CREATE POLICY "Enable all operations for authenticated users" ON public.email_threads FOR ALL USING (true);

-- Create indexes for better performance
CREATE INDEX idx_part_lines_rfq_id ON public.part_lines(rfq_id);
CREATE INDEX idx_quotes_rfq_id ON public.quotes(rfq_id);
CREATE INDEX idx_quotes_supplier_id ON public.quotes(supplier_id);
CREATE INDEX idx_quotes_score ON public.quotes(score DESC);
CREATE INDEX idx_quotes_valid_until ON public.quotes(valid_until);
CREATE INDEX idx_email_threads_rfq_id ON public.email_threads(rfq_id);
CREATE INDEX idx_suppliers_active ON public.suppliers(active);
CREATE INDEX idx_suppliers_opt_out ON public.suppliers(opt_out);

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_rfqs_updated_at
  BEFORE UPDATE ON public.rfqs
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_suppliers_updated_at
  BEFORE UPDATE ON public.suppliers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_quotes_updated_at
  BEFORE UPDATE ON public.quotes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to auto-calculate quote scores
CREATE OR REPLACE FUNCTION public.calculate_quote_score()
RETURNS TRIGGER AS $$
DECLARE
  base_score NUMERIC := 50;
  price_score NUMERIC := 0;
  lead_time_score NUMERIC := 0;
  condition_bonus NUMERIC := 0;
  rfq_condition condition_type;
BEGIN
  -- Get RFQ condition requirement for this part
  SELECT pl.condition_req INTO rfq_condition
  FROM public.part_lines pl
  WHERE pl.rfq_id = NEW.rfq_id 
    AND pl.part_number = NEW.part_number
  LIMIT 1;

  -- Price scoring (lower price = higher score)
  IF NEW.unit_price IS NOT NULL AND NEW.unit_price > 0 THEN
    price_score := GREATEST(0, 30 - (NEW.unit_price / 1000)); -- Adjust scale as needed
  END IF;

  -- Lead time scoring (shorter lead time = higher score)
  IF NEW.lead_time_days IS NOT NULL THEN
    lead_time_score := GREATEST(0, 20 - NEW.lead_time_days);
  END IF;

  -- Condition match bonus
  IF rfq_condition IS NOT NULL AND NEW.condition = rfq_condition THEN
    condition_bonus := 20;
  END IF;

  -- Calculate final score (0-100)
  NEW.score := GREATEST(0, LEAST(100, base_score + price_score + lead_time_score + condition_bonus));

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-calculate scores
CREATE TRIGGER calculate_quote_score_trigger
  BEFORE INSERT OR UPDATE ON public.quotes
  FOR EACH ROW
  EXECUTE FUNCTION public.calculate_quote_score();

-- Create storage bucket for attachments
INSERT INTO storage.buckets (id, name, public) 
VALUES ('attachments', 'attachments', false)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for attachments
CREATE POLICY "Authenticated users can view attachments" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'attachments' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can upload attachments" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'attachments' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update attachments" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'attachments' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can delete attachments" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'attachments' AND auth.role() = 'authenticated');