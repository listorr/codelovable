import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { action } = body;
    
    // Environment validation
    const TENANT = Deno.env.get('MS_TENANT_ID');
    const CLIENT_ID = Deno.env.get('MS_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('MS_CLIENT_SECRET');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');

    const missing = [];
    for (const [k, v] of Object.entries({ 
      MS_TENANT_ID: TENANT, 
      MS_CLIENT_ID: CLIENT_ID, 
      MS_CLIENT_SECRET: CLIENT_SECRET, 
      SUPABASE_URL
    })) {
      if (!v) missing.push(k);
    }
    if (missing.length) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Missing env variables', 
        details: { missing } 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get access token
    const tokenRes = await fetch(`https://login.microsoftonline.com/${TENANT}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID!,
        client_secret: CLIENT_SECRET!,
        scope: 'https://graph.microsoft.com/.default',
        grant_type: 'client_credentials'
      })
    });

    if (!tokenRes.ok) {
      const error = await tokenRes.text();
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Token failed', 
        details: error 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const tokenData = await tokenRes.json();
    const accessToken = tokenData.access_token;

    console.log('[test-flow] Action:', action);

    if (action === 'list-subscriptions') {
      // List existing subscriptions
      const listRes = await fetch('https://graph.microsoft.com/v1.0/subscriptions', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      const listText = await listRes.text();
      console.log('[list-subscriptions] Status:', listRes.status);
      console.log('[list-subscriptions] Response:', listText);
      
      if (!listRes.ok) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Failed to list subscriptions',
          status: listRes.status,
          response: listText
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      const listData = JSON.parse(listText);
      
      // Filter inbox subscriptions
      const inboxSubscriptions = listData.value?.filter((sub: any) => 
        sub.resource?.includes('mailFolders') || sub.resource?.includes('messages')
      ) || [];
      
      return new Response(JSON.stringify({
        success: true,
        subscriptions: inboxSubscriptions,
        all: listData.value || [],
        count: inboxSubscriptions.length,
        details: inboxSubscriptions.map((sub: any) => ({
          id: sub.id,
          resource: sub.resource,
          notificationUrl: sub.notificationUrl,
          expirationDateTime: sub.expirationDateTime,
          clientState: sub.clientState
        }))
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (action === 'send-test-email') {
      const { emailData } = body;
      
      // Send test email with RFQ reference  
      const testEmailPayload = {
        message: {
          subject: emailData?.subject || "Test RFQ Quote - Ref: 15C0A68F",
          body: {
            contentType: "Text",
            content: emailData?.body || `Quote Response for RFQ 15C0A68F:

Item: Widget
Price: $100 USD
Lead Time: 5-7 days
Availability: In Stock
Valid Until: 2025-09-15
Warranty: 12 months
MOQ: 1 unit

Best regards,
Test Supplier`
          },
          toRecipients: [
            {
              emailAddress: {
                address: emailData?.to || "rfqs@suatfuels.com"
              }
            }
          ]
        }
      };

      console.log('[send-test-email] Payload:', JSON.stringify(testEmailPayload, null, 2));

      // Use specific user endpoint
      const sendRes = await fetch('https://graph.microsoft.com/v1.0/users/f543917d-5e3e-44cd-8800-b9a88705dbfb/sendMail', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(testEmailPayload)
      });

      const sendData = sendRes.ok ? 'Email sent' : await sendRes.text();
      console.log('[send-test-email] Response:', sendRes.status, sendData);

      return new Response(JSON.stringify({
        success: sendRes.ok,
        status: sendRes.status,
        response: sendData,
        payload: testEmailPayload
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (action === 'delete-subscription') {
      const { subscriptionId } = body;
      
      const deleteRes = await fetch(`https://graph.microsoft.com/v1.0/subscriptions/${subscriptionId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        }
      });

      console.log('[delete-subscription] Response:', deleteRes.status);

      return new Response(JSON.stringify({
        success: deleteRes.ok,
        status: deleteRes.status,
        deleted: subscriptionId
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (action === 'create-subscription') {
      // Create new subscription with extended expiration
      const subscriptionPayload = {
        changeType: 'created',
        notificationUrl: `${SUPABASE_URL}/functions/v1/msgraph-webhook`,
        resource: '/users/f543917d-5e3e-44cd-8800-b9a88705dbfb/mailFolders(\'Inbox\')/messages',
        expirationDateTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
        clientState: crypto.randomUUID()
      };

      console.log('[create-subscription] Creating subscription:', JSON.stringify(subscriptionPayload, null, 2));

      const createRes = await fetch('https://graph.microsoft.com/v1.0/subscriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(subscriptionPayload)
      });
      
      const createText = await createRes.text();
      console.log('[create-subscription] Response:', createRes.status, createText);
      
      if (!createRes.ok) {
        return new Response(JSON.stringify({
          success: false,
          status: createRes.status,
          error: 'Failed to create subscription',
          response: createText,
          payload: subscriptionPayload
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      const createData = JSON.parse(createText);
      
      return new Response(JSON.stringify({
        success: true,
        status: createRes.status,
        subscription: createData,
        details: {
          id: createData.id,
          resource: createData.resource,
          notificationUrl: createData.notificationUrl,
          expirationDateTime: createData.expirationDateTime
        }
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (action === 'renew-subscription') {
      const { subscriptionId } = body;
      
      // Get current subscription details first
      const currentSubResponse = await fetch(`https://graph.microsoft.com/v1.0/subscriptions/${subscriptionId}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      
      if (!currentSubResponse.ok) {
        const errorText = await currentSubResponse.text();
        return new Response(JSON.stringify({ 
          error: 'Failed to get current subscription', 
          details: errorText,
          status: currentSubResponse.status
        }), {
          status: currentSubResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const currentSub = await currentSubResponse.json();
      console.log('[renew] Current subscription:', JSON.stringify(currentSub, null, 2));
      console.log('[renew] Associated email: rfqs@suatfuels.com (User ID: f543917d-5e3e-44cd-8800-b9a88705dbfb)');

      // Renew subscription with new expiration
      const renewResponse = await fetch(`https://graph.microsoft.com/v1.0/subscriptions/${subscriptionId}`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          expirationDateTime: body.expirationDateTime || '2025-09-19T02:00:00Z'
        })
      });

      const renewResult = await renewResponse.json();
      console.log('[renew] Response status:', renewResponse.status);
      console.log('[renew] Response body:', JSON.stringify(renewResult, null, 2));

      return new Response(JSON.stringify({
        success: renewResponse.ok,
        data: renewResult,
        status: renewResponse.status,
        associatedEmail: 'rfqs@suatfuels.com'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (action === 'test-webhook') {
      // Test webhook accessibility
      const webhookUrl = `${SUPABASE_URL}/functions/v1/msgraph-webhook`;
      
      try {
        const testRes = await fetch(`${webhookUrl}?validationToken=test123`, {
          method: 'GET'
        });
        const testText = await testRes.text();
        
        console.log('[test-webhook] Response:', testRes.status, testText);
        
        return new Response(JSON.stringify({
          success: testRes.ok && testText === 'test123',
          status: testRes.status,
          response: testText,
          expected: 'test123',
          webhookUrl: webhookUrl
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      } catch (error: any) {
        console.log('[test-webhook] Error:', error);
        return new Response(JSON.stringify({
          success: false,
          error: error.message,
          webhookUrl: webhookUrl
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    if (action === 'test-process-msgraph') {
      // Test process-msgraph-email function directly
      const testMessageId = 'AQMkADY5OQAzMTI0Ni01NmI5LTQ3YWQtYTM0Yi0zYmFkNWY1N2NlMGEARgAAA8k-NG1Lyw1EtQ2t1pAiJJAHALxtiRL-LaRDruMMfQfJqaQAAAIBDAAAALxtiRL-LaRDruMMfQfJqaQAAAJNuAAAAA==';
      
      try {
        console.log('[test-process-msgraph] Testing process-msgraph-email function...');
        
        const processRes = await fetch(`${SUPABASE_URL}/functions/v1/process-msgraph-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
          },
          body: JSON.stringify({ messageId: testMessageId })
        });
        
        const processText = await processRes.text();
        console.log('[test-process-msgraph] Response:', processRes.status, processText);
        
        return new Response(JSON.stringify({
          success: processRes.ok,
          status: processRes.status,
          response: processText,
          functionUrl: `${SUPABASE_URL}/functions/v1/process-msgraph-email`,
          testMessageId: testMessageId
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      } catch (error: any) {
        console.log('[test-process-msgraph] Error:', error);
        return new Response(JSON.stringify({
          success: false,
          error: error.message,
          functionUrl: `${SUPABASE_URL}/functions/v1/process-msgraph-email`
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Unknown action: ' + action,
      availableActions: ['list-subscriptions', 'send-test-email', 'delete-subscription', 'create-subscription', 'renew-subscription', 'test-webhook', 'test-process-msgraph']
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('[test-flow] Error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
};

serve(handler);