import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Create a test quote directly to verify the flow works
    console.log('Creating test quote directly...');

    // First find or create an RFQ
    const testRfqId = '15c0a68f';
    let { data: rfq } = await supabase
      .from('rfqs')
      .select('*')
      .filter('id', 'ilike', `%${testRfqId}`)
      .maybeSingle();

    if (!rfq) {
      // Find any existing RFQ to use
      const { data: existingRfqs } = await supabase
        .from('rfqs')
        .select('*')
        .limit(1);
      
      if (existingRfqs && existingRfqs.length > 0) {
        rfq = existingRfqs[0];
        console.log('Using existing RFQ:', rfq.id);
      } else {
        return new Response(JSON.stringify({
          success: false,
          error: 'No RFQs found in database'
        }), {
          status: 404,
          headers: { "Content-Type": "application/json", ...corsHeaders }
        });
      }
    }

    // Create or find supplier
    const testEmail = 'test@example.com';
    let { data: supplier } = await supabase
      .from('suppliers')
      .select('*')
      .contains('emails', [testEmail])
      .maybeSingle();

    if (!supplier) {
      const { data: newSupplier } = await supabase
        .from('suppliers')
        .insert({
          name: 'Test Supplier',
          emails: [testEmail],
          active: true
        })
        .select()
        .single();
      supplier = newSupplier;
      console.log('Created test supplier:', supplier.id);
    }

    // Create test quote
    const testQuote = {
      rfq_id: rfq.id,
      supplier_id: supplier.id,
      part_number: 'TEST-WIDGET-001',
      description: 'Test Widget Pro Max - Direct Insert',
      unit_price: 150.00,
      currency: 'USD',
      lead_time_days: 5,
      qty_available: 25,
      moq: 1,
      warranty_months: 24,
      valid_until: new Date('2025-09-20T00:00:00Z').toISOString(),
      incoterm: 'FOB Miami',
      processing_status: 'processed',
      quote_status: 'pending_review',
      relevance_score: 95,
      score: 95,
      is_relevant: true,
      ai_analysis: {
        isRelevant: true,
        relevanceScore: 95,
        hasPrice: true,
        hasAvailability: true,
        hasCommercialTerms: true,
        isNegativeResponse: false,
        extractedData: {
          items: ['Widget Pro Max'],
          prices: ['$150 USD'],
          dates: ['3-5 days', '2025-09-20'],
          conditions: ['24 months warranty', 'FOB Miami', 'MOQ: 1 unit']
        },
        reasoning: 'Test quote with complete commercial information'
      },
      processed_at: new Date().toISOString()
    };

    const { data: quote, error: quoteError } = await supabase
      .from('quotes')
      .insert(testQuote)
      .select()
      .single();

    if (quoteError) {
      console.error('Error creating quote:', quoteError);
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to create quote',
        details: quoteError.message
      }), {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders }
      });
    }

    // Log communication
    await supabase.from('communication_history').insert({
      rfq_id: rfq.id,
      supplier_id: supplier.id,
      communication_type: 'test_quote_direct',
      subject: 'Direct Test Quote Creation',
      content: 'Test quote created directly via API for debugging purposes',
      received_at: new Date().toISOString(),
      metadata: {
        quote_id: quote.id,
        test_type: 'direct_creation',
        created_via: 'test-quote-direct function'
      }
    });

    console.log('Test quote created successfully:', quote.id);

    return new Response(JSON.stringify({
      success: true,
      message: 'Test quote created successfully',
      quote: {
        id: quote.id,
        rfq_id: rfq.id,
        supplier_id: supplier.id,
        part_number: quote.part_number,
        unit_price: quote.unit_price,
        currency: quote.currency,
        relevance_score: quote.relevance_score,
        ai_analysis: quote.ai_analysis
      }
    }), {
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });

  } catch (error: any) {
    console.error('Error in test-quote-direct:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });
  }
};

serve(handler);