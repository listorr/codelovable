import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
};

function ok(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status, headers: { "content-type": "application/json", ...cors }
  });
}
function safeJson(t: string) { try { return JSON.parse(t); } catch { return null; } }

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

  try {
    // --- Simple gate con token compartido ---
    const url = new URL(req.url);
    const token = url.searchParams.get("token");
    const ADMIN_TOKEN = Deno.env.get("ADMIN_TOKEN");
    if (!ADMIN_TOKEN || token !== ADMIN_TOKEN) {
      return ok({ success: false, error: "Unauthorized (token)" }, 401);
    }

    const action = url.searchParams.get("action") || "list";

    // --- Env vars necesarias ---
    const TENANT = Deno.env.get("MS_TENANT_ID");
    const CLIENT_ID = Deno.env.get("MS_CLIENT_ID");
    const CLIENT_SECRET = Deno.env.get("MS_CLIENT_SECRET");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const RFQ_INBOX_ADDRESS = Deno.env.get("RFQ_INBOX_ADDRESS");

    const missing: string[] = [];
    for (const [k, v] of Object.entries({ MS_TENANT_ID: TENANT, MS_CLIENT_ID: CLIENT_ID, MS_CLIENT_SECRET: CLIENT_SECRET, SUPABASE_URL, RFQ_INBOX_ADDRESS })) {
      if (!v) missing.push(k);
    }
    if (missing.length) return ok({ success: false, error: "Missing env", details: { missing } }, 400);

    // --- Token de Graph (application) ---
    const tokenRes = await fetch(`https://login.microsoftonline.com/${TENANT}/oauth2/v2.0/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: CLIENT_ID!,
        client_secret: CLIENT_SECRET!,
        scope: "https://graph.microsoft.com/.default",
        grant_type: "client_credentials",
      }),
    });
    const tokenText = await tokenRes.text();
    if (!tokenRes.ok) {
      return ok({ success: false, error: "Token error", details: safeJson(tokenText) ?? tokenText }, 400);
    }
    const accessToken = (safeJson(tokenText) as any)?.access_token as string;

    const graph = (path: string, init: RequestInit = {}) =>
      fetch(`https://graph.microsoft.com/v1.0${path}`, {
        ...init,
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          ...(init.headers || {}),
        },
      });

    // Resolver userId del buzón
    const userRes = await graph(`/users/${encodeURIComponent(RFQ_INBOX_ADDRESS!) }?$select=id,userPrincipalName`);
    const userText = await userRes.text();
    if (!userRes.ok) return ok({ success: false, error: "Users lookup failed", details: safeJson(userText) ?? userText }, 400);
    const user = safeJson(userText);
    const userId = user?.id;
    if (!userId) return ok({ success: false, error: "No userId resolved", details: user }, 400);

    if (action === "list") {
      const res = await graph("/subscriptions");
      const txt = await res.text();
      return ok({ success: res.ok, status: res.status, data: safeJson(txt) ?? txt });
    }

    if (action === "create") {
      const notificationUrl = `${SUPABASE_URL}/functions/v1/msgraph-webhook`; // tu webhook público
      let resource = `/users/${userId}/mailFolders('Inbox')/messages`;
      const expirationDateTime = new Date(Date.now() + 55 * 60 * 1000).toISOString();
      const clientState = crypto.randomUUID();

      const payload = { changeType: "created", notificationUrl, resource, expirationDateTime, clientState };

      let c1 = await graph("/subscriptions", { method: "POST", body: JSON.stringify(payload) });
      let t1 = await c1.text();

      if (!c1.ok && /mailFolders|Resource not found|Invalid/i.test(t1)) {
        resource = `/users/${userId}/messages`;
        const payload2 = { ...payload, resource };
        c1 = await graph("/subscriptions", { method: "POST", body: JSON.stringify(payload2) });
        t1 = await c1.text();
      }

      if (!c1.ok) return ok({ success: false, error: "Graph create-subscription failed", details: safeJson(t1) ?? t1, status: c1.status }, 400);
      return ok({ success: true, subscription: safeJson(t1) ?? t1 });
    }

    if (action === "delete") {
      const id = url.searchParams.get("id");
      if (!id) return ok({ success: false, error: "Missing id" }, 400);
      const d = await graph(`/subscriptions/${encodeURIComponent(id)}`, { method: "DELETE" });
      return ok({ success: d.ok, status: d.status });
    }

    return ok({ success: false, error: "Unknown action" }, 400);
  } catch (e: any) {
    return ok({ success: false, error: String(e?.message || e) }, 500);
  }
});