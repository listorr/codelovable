import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Max-Age': '86400',
};

const ok = (data: any, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', ...cors } });

const handler = async (req: Request): Promise<Response> => {
  // Preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  try {
    console.log('Processing emails from inbox...');

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get all unprocessed emails from inbox
    const { data: emails, error: emailsError } = await supabase
      .from('emails_inbox')
      .select('*')
      .limit(50);

    if (emailsError) {
      console.error('Error fetching emails:', emailsError);
      return ok({ success: false, error: 'Failed to fetch emails from inbox' });
    }

    console.log(`Found ${emails?.length || 0} emails to process`);

    let processed = 0;
    let failed = 0;
    const results = [];

    for (const email of emails || []) {
      try {
        console.log(`Processing email: ${email.subject} from ${email.sender}`);

        // Simulate Graph email format for process-msgraph-email
        const emailData = {
          id: email.id,
          subject: email.subject,
          receivedDateTime: email.received_at,
          from: {
            emailAddress: {
              address: email.sender,
              name: email.sender.split('@')[0]
            }
          },
          toRecipients: [{
            emailAddress: {
              address: 'rfqs@suatfuels.com'
            }
          }],
          body: {
            contentType: 'text',
            content: `Email from ${email.sender} regarding: ${email.subject}`
          },
          hasAttachments: false
        };

        // Extract RFQ reference from subject (supports both "RFQ-XXXXXXXX" and "Ref: XXXXXXXX")
        const rfqMatch = email.subject.match(/(?:RFQ[_\-\s]*|Ref:\s*)([A-Z0-9]{8})/i);
        const rfqReference = rfqMatch ? rfqMatch[1].toLowerCase() : null;
        
        console.log(`Email subject: "${email.subject}"`);
        console.log(`RFQ reference found: ${rfqReference}`);

        // Call process-quote-email-ai function directly for AI processing
        const { data: processResult, error: processError } = await supabase.functions.invoke('process-quote-email-ai', {
          body: { 
            from: email.sender,
            to: "rfqs@suatfuels.com",
            subject: email.subject,
            text: `Email from ${email.sender} regarding: ${email.subject}`,
            html: `<p>Email from ${email.sender} regarding: ${email.subject}</p>`
          }
        });

        if (processError) {
          console.error(`Failed to process email ${email.id}:`, processError);
          failed++;
          results.push({
            id: email.id,
            subject: email.subject,
            success: false,
            error: processError.message
          });
        } else {
          console.log(`Successfully processed email ${email.id}`);
          processed++;
          results.push({
            id: email.id,
            subject: email.subject,
            success: true,
            result: processResult
          });
        }

      } catch (error) {
        console.error(`Error processing email ${email.id}:`, error);
        failed++;
        results.push({
          id: email.id,
          subject: email.subject || 'Unknown',
          success: false,
          error: error.message
        });
      }
    }

    console.log(`Processing complete: ${processed} succeeded, ${failed} failed`);

    return ok({
      success: true,
      processed,
      failed,
      total: emails?.length || 0,
      results: results.slice(0, 10) // Limit results in response
    });

  } catch (error: any) {
    console.error('[edge-fn error]', error);
    return ok({ success: false, error: String(error.message || error) });
  }
};

serve(handler);