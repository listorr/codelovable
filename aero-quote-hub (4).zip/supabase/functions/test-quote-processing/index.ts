import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Simulate the email data from your reply
    const emailData = {
      from: "luis@suatfuels.com",
      to: "rfqs@suatfuels.com",
      subject: "Re: Routine RFQ - 1 Parts - Ref: 588D0F3E",
      text: "Hi\n\nWe have this part number available. 1000 USD each, 5 days lead-time, FOB MIAMI.\n\nLuis Torrente\nManaging Director",
      html: ""
    };

    console.log('Processing test email from:', emailData.from);

    // Call the AI processing function
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const response = await supabase.functions.invoke('process-quote-email-ai', {
      body: emailData
    });

    if (response.error) {
      console.error('Error calling AI function:', response.error);
      throw new Error(response.error.message);
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Test email processed successfully',
      result: response.data
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("Error in test-quote-processing function:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);