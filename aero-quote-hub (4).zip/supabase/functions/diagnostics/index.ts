import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-action',
  'Access-Control-Max-Age': '86400',
};

const ok = (data: any, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', ...cors } });

interface DiagnosticCheck {
  ok: boolean;
  status?: number;
  error?: string;
  details?: any;
  body?: any;
}

interface DiagnosticResult {
  success: boolean;
  checks: {
    env: DiagnosticCheck & { missing?: string[] };
    graph_token: DiagnosticCheck;
    graph_list_subs: DiagnosticCheck;
    graph_inbox_probe: DiagnosticCheck;
    webhook_validation: DiagnosticCheck & { url?: string };
    resend_domains: DiagnosticCheck;
    openai_models: DiagnosticCheck;
    supabase_db: DiagnosticCheck & { rows?: number };
  };
  hints?: string[];
}

const handler = async (req: Request): Promise<Response> => {
  // Preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  try {
    const result: DiagnosticResult = {
      success: true,
      checks: {
        env: { ok: true },
        graph_token: { ok: true },
        graph_list_subs: { ok: true },
        graph_inbox_probe: { ok: true },
        webhook_validation: { ok: true },
        resend_domains: { ok: true },
        openai_models: { ok: true },
        supabase_db: { ok: true },
      },
      hints: []
    };

    // 1. Check environment variables
    const requiredEnvs = [
      'MS_TENANT_ID', 'MS_CLIENT_ID', 'MS_CLIENT_SECRET',
      'RESEND_API_KEY', 'OPENAI_API_KEY',
      'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'
    ];
    const missing = requiredEnvs.filter(env => !Deno.env.get(env));
    const rfqInbox = Deno.env.get('RFQ_INBOX_ADDRESS') || 'rfqs@suatfuels.com';
    
    if (missing.length > 0) {
      result.checks.env = { ok: false, missing };
      result.hints?.push(`Missing environment variables: ${missing.join(', ')}`);
      result.success = false;
    }

    // 2. Check Graph token
    try {
      const tenantId = Deno.env.get('MS_TENANT_ID');
      const clientId = Deno.env.get('MS_CLIENT_ID');
      const clientSecret = Deno.env.get('MS_CLIENT_SECRET');
      
      if (tenantId && clientId && clientSecret) {
        const tokenResponse = await fetch(`https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            grant_type: 'client_credentials',
            client_id: clientId,
            client_secret: clientSecret,
            scope: 'https://graph.microsoft.com/.default'
          })
        });

        const tokenData = await tokenResponse.json();
        
        if (!tokenResponse.ok) {
          result.checks.graph_token = { 
            ok: false, 
            status: tokenResponse.status, 
            error: 'Token request failed',
            details: tokenData 
          };
          if (tokenResponse.status === 401 && tokenData.error === 'invalid_client') {
            result.hints?.push('Invalid MS_CLIENT_SECRET. Use the client secret value, not the ID.');
          }
        } else {
          const token = tokenData.access_token;
          
          // 3. Check Graph list subscriptions
          try {
            const subsResponse = await fetch('https://graph.microsoft.com/v1.0/subscriptions', {
              headers: { 'Authorization': `Bearer ${token}` }
            });
            const subsData = await subsResponse.json();
            
            if (!subsResponse.ok) {
              result.checks.graph_list_subs = { 
                ok: false, 
                status: subsResponse.status, 
                error: subsResponse.status === 401 || subsResponse.status === 403 ? 
                  'Graph 401/403. Check Mail.Read (Application) permissions and admin consent.' : 
                  'Failed to list subscriptions',
                body: subsData 
              };
              if (subsResponse.status === 401 || subsResponse.status === 403) {
                result.hints?.push('Missing Mail.Read application permission or admin consent required.');
              }
            } else {
              result.checks.graph_list_subs = { ok: true, body: subsData };
            }
            
            // 4. Check Graph inbox probe
            try {
              const inboxResponse = await fetch(
                `https://graph.microsoft.com/v1.0/users('${rfqInbox}')/mailFolders('Inbox')/messages?$top=1&$select=subject,receivedDateTime`,
                { headers: { 'Authorization': `Bearer ${token}` } }
              );
              const inboxData = await inboxResponse.json();
              
              if (!inboxResponse.ok) {
                result.checks.graph_inbox_probe = { 
                  ok: false, 
                  status: inboxResponse.status, 
                  body: inboxData 
                };
                if (inboxResponse.status === 404) {
                  result.hints?.push(`Mailbox ${rfqInbox} doesn't exist in this tenant or is not accessible.`);
                }
              } else {
                result.checks.graph_inbox_probe = { ok: true, body: inboxData };
              }
            } catch (error: any) {
              result.checks.graph_inbox_probe = { ok: false, error: error.message };
            }
          } catch (error: any) {
            result.checks.graph_list_subs = { ok: false, error: error.message };
          }
        }
      }
    } catch (error: any) {
      result.checks.graph_token = { ok: false, error: error.message };
    }

    // 5. Check webhook validation
    try {
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      if (supabaseUrl) {
        const webhookUrl = `${supabaseUrl}/functions/v1/msgraph-webhook?validationToken=PING`;
        const webhookResponse = await fetch(webhookUrl);
        const webhookBody = await webhookResponse.text();
        
        result.checks.webhook_validation = {
          ok: webhookResponse.ok && webhookBody === 'PING',
          status: webhookResponse.status,
          body: webhookBody,
          url: webhookUrl
        };
        
        if (!webhookResponse.ok || webhookBody !== 'PING') {
          result.hints?.push('Webhook validation failed. Check msgraph-webhook function.');
        }
      }
    } catch (error: any) {
      result.checks.webhook_validation = { ok: false, error: error.message };
    }

    // 6. Check Resend domains
    try {
      const resendKey = Deno.env.get('RESEND_API_KEY');
      if (resendKey) {
        const resendResponse = await fetch('https://api.resend.com/domains', {
          headers: { 'Authorization': `Bearer ${resendKey}` }
        });
        const resendData = await resendResponse.json();
        
        if (!resendResponse.ok) {
          result.checks.resend_domains = { 
            ok: false, 
            status: resendResponse.status, 
            error: 'Resend API error',
            body: resendData 
          };
          if (resendResponse.status === 401) {
            result.hints?.push('Invalid RESEND_API_KEY.');
          }
        } else {
          result.checks.resend_domains = { ok: true, body: resendData };
          const hasVerifiedDomain = resendData.data?.some((domain: any) => 
            domain.name === 'suatfuels.com' && domain.status === 'verified'
          );
          if (!hasVerifiedDomain) {
            result.hints?.push('suatfuels.com domain not verified in Resend.');
          }
        }
      }
    } catch (error: any) {
      result.checks.resend_domains = { ok: false, error: error.message };
    }

    // 7. Check OpenAI models
    try {
      const openaiKey = Deno.env.get('OPENAI_API_KEY');
      if (openaiKey) {
        const openaiResponse = await fetch('https://api.openai.com/v1/models', {
          headers: { 'Authorization': `Bearer ${openaiKey}` }
        });
        const openaiData = await openaiResponse.json();
        
        if (!openaiResponse.ok) {
          result.checks.openai_models = { 
            ok: false, 
            status: openaiResponse.status, 
            error: 'OpenAI API error' 
          };
          if (openaiResponse.status === 401) {
            result.hints?.push('Invalid OPENAI_API_KEY.');
          }
        } else {
          result.checks.openai_models = { ok: true };
        }
      }
    } catch (error: any) {
      result.checks.openai_models = { ok: false, error: error.message };
    }

    // 8. Check Supabase DB
    try {
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
      
      if (supabaseUrl && serviceRoleKey) {
        const dbResponse = await fetch(`${supabaseUrl}/rest/v1/rfqs?select=id&limit=1`, {
          headers: {
            'apikey': serviceRoleKey,
            'Authorization': `Bearer ${serviceRoleKey}`,
            'Accept': 'application/json'
          }
        });
        
        if (!dbResponse.ok) {
          result.checks.supabase_db = { 
            ok: false, 
            status: dbResponse.status, 
            error: 'Supabase DB connection failed' 
          };
        } else {
          const dbData = await dbResponse.json();
          result.checks.supabase_db = { ok: true, rows: Array.isArray(dbData) ? dbData.length : 0 };
        }
      }
    } catch (error: any) {
      result.checks.supabase_db = { ok: false, error: error.message };
    }

    // Set overall success
    result.success = Object.values(result.checks).every(check => check.ok);

    return ok(result);

  } catch (error: any) {
    console.error('[edge-fn error]', error);
    return ok({ 
      success: false, 
      error: String(error),
      hints: [`Unexpected error: ${error.message}`]
    });
  }
};

serve(handler);