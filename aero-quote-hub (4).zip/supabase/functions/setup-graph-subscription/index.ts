import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-action',
  'Access-Control-Max-Age': '86400',
};

const ok = (data: any) => new Response(JSON.stringify(data), { 
  status: 200, 
  headers: { 'content-type': 'application/json', ...cors } 
});

function safeJson(text: string) { 
  try { 
    return JSON.parse(text); 
  } catch { 
    return null; 
  } 
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  try {
    const url = new URL(req.url);
    console.log('[entry]', req.method, url.pathname, url.search);

    // --- Robust action parsing ---
    const qsAction = url.searchParams.get('action');
    let rawBody = '';
    if (req.method !== 'GET') { 
      try { 
        rawBody = await req.text(); 
      } catch {}
    }
    let bodyAction: string | undefined;
    try { 
      bodyAction = rawBody ? (JSON.parse(rawBody)?.action) : undefined; 
    } catch {}
    const headerAction = req.headers.get('x-action') || undefined;
    const action = qsAction || bodyAction || headerAction || 'list';
    console.log('[action]', action, 'rawBodyLen=', rawBody?.length || 0);

    // --- Environment validation ---
    const TENANT = Deno.env.get('MS_TENANT_ID');
    const CLIENT_ID = Deno.env.get('MS_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('MS_CLIENT_SECRET');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const RFQ_INBOX_ADDRESS = Deno.env.get('RFQ_INBOX_ADDRESS'); // can be GUID or SMTP/UPN

    const missing = [];
    for (const [k, v] of Object.entries({ 
      MS_TENANT_ID: TENANT, 
      MS_CLIENT_ID: CLIENT_ID, 
      MS_CLIENT_SECRET: CLIENT_SECRET, 
      SUPABASE_URL, 
      RFQ_INBOX_ADDRESS 
    })) {
      if (!v) missing.push(k);
    }
    if (missing.length) {
      return ok({ success: false, error: 'Missing env', details: { missing } });
    }

    // --- Get token ---
    const tokenRes = await fetch(`https://login.microsoftonline.com/${TENANT}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID!,
        client_secret: CLIENT_SECRET!,
        scope: 'https://graph.microsoft.com/.default',
        grant_type: 'client_credentials'
      })
    });
    const tokenText = await tokenRes.text();
    console.log('[token] status=', tokenRes.status);
    if (!tokenRes.ok) {
      return ok({ 
        success: false, 
        error: 'Token error', 
        details: { status: tokenRes.status, body: safeJson(tokenText) } 
      });
    }
    const tokenData = JSON.parse(tokenText);
    const accessToken = tokenData.access_token as string;
    
    // Log token info for debugging (without exposing the actual token)
    console.log('[token] scope=', tokenData.scope);
    console.log('[token] token_type=', tokenData.token_type);
    console.log('[token] expires_in=', tokenData.expires_in);

    // Graph API helper
    const graphFetch = (path: string, init: RequestInit = {}) =>
      fetch(`https://graph.microsoft.com/v1.0${path}`, {
        ...init,
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          ...(init.headers || {})
        }
      });

    // --- Resolve userId from mailbox (accepts GUID or address) ---
    const isGuid = /^[0-9a-f-]{36}$/i.test(RFQ_INBOX_ADDRESS!);
    const userPath = isGuid ? `/users/${RFQ_INBOX_ADDRESS}` : `/users/${encodeURIComponent(RFQ_INBOX_ADDRESS!)}`;
    const userRes = await graphFetch(`${userPath}?$select=id,userPrincipalName`);
    const userText = await userRes.text();
    console.log('[users lookup] status=', userRes.status, 'body=', userText);
    if (!userRes.ok) {
      return ok({ 
        success: false, 
        error: 'Graph users lookup failed', 
        details: { status: userRes.status, body: safeJson(userText) } 
      });
    }
    const user = safeJson(userText);
    const userId = user?.id;
    if (!userId) {
      return ok({ 
        success: false, 
        error: 'No userId resolved', 
        details: { user } 
      });
    }

    if (action === 'list') {
      const res = await graphFetch('/subscriptions');
      const text = await res.text();
      console.log('[list] status=', res.status, 'body=', text);
      const parsed = safeJson(text);
      return ok({ 
        success: res.ok, 
        status: res.status, 
        data: parsed ?? text 
      });
    }

    if (action === 'create') {
      let resource = `/users/${userId}/mailFolders('Inbox')/messages`; // preferred
      const notificationUrl = `${SUPABASE_URL}/functions/v1/msgraph-webhook`;
      const expirationDateTime = new Date(Date.now() + 55 * 60 * 1000).toISOString();
      const clientState = crypto.randomUUID();

      console.log('[create] resource=', resource);
      console.log('[create] notificationUrl=', notificationUrl);
      console.log('[create] userId=', userId);
      
      // Test webhook URL accessibility first
      try {
        const testRes = await fetch(`${notificationUrl}?validationToken=test`);
        const testText = await testRes.text();
        console.log('[webhook-test] status=', testRes.status, 'response=', testText);
        if (testRes.status !== 200 || testText !== 'test') {
          return ok({
            success: false,
            error: 'Webhook URL validation failed',
            details: { 
              webhookUrl: notificationUrl,
              testStatus: testRes.status,
              testResponse: testText,
              expected: 'test'
            }
          });
        }
      } catch (webhookError) {
        console.log('[webhook-test] error=', webhookError);
        return ok({
          success: false,
          error: 'Webhook URL not accessible',
          details: { 
            webhookUrl: notificationUrl,
            error: String(webhookError)
          }
        });
      }

    const subscriptionPayload = {
      changeType: 'created',
      notificationUrl,
      resource,
      expirationDateTime,
      clientState
    };

      console.log('[create] payload=', JSON.stringify(subscriptionPayload, null, 2));

      // IMPORTANT: Don't reuse rawBody or variables "body" from request
      let createRes = await graphFetch('/subscriptions', { 
        method: 'POST', 
        body: JSON.stringify(subscriptionPayload) 
      });
      let createText = await createRes.text();
      console.log('[create] status=', createRes.status);
      console.log('[create] response=', createText);

      // Retry if it complains about mailFolder
      if (!createRes.ok && /mailFolders|Resource not found|Invalid/i.test(createText)) {
        resource = `/users/${userId}/messages`;
        console.log('[create-retry] resource=', resource);
        const retryPayload = { ...subscriptionPayload, resource };
        console.log('[create-retry] payload=', JSON.stringify(retryPayload, null, 2));
        createRes = await graphFetch('/subscriptions', { 
          method: 'POST', 
          body: JSON.stringify(retryPayload) 
        });
        createText = await createRes.text();
        console.log('[create-retry] status=', createRes.status);
        console.log('[create-retry] response=', createText);
      }

      if (!createRes.ok) {
        const errorDetails = safeJson(createText);
        console.log('[create-error] Detailed error:', JSON.stringify(errorDetails, null, 2));
        
        return ok({ 
          success: false, 
          error: 'Graph create-subscription failed', 
          details: { 
            status: createRes.status, 
            body: errorDetails ?? createText,
            subscriptionPayload: subscriptionPayload,
            authInfo: {
              userId: userId,
              tokenScope: tokenData.scope || 'https://graph.microsoft.com/.default',
              grantType: 'client_credentials'
            }
          } 
        });
      }
      return ok({ 
        success: true, 
        subscription: safeJson(createText) ?? createText 
      });
    }

    if (action === 'delete') {
      let id: string | undefined;
      try { 
        id = rawBody ? JSON.parse(rawBody)?.id : undefined; 
      } catch {}
      if (!id) {
        return ok({ success: false, error: 'Missing id for delete' });
      }
      const delRes = await graphFetch(`/subscriptions/${encodeURIComponent(id)}`, { method: 'DELETE' });
      const delText = await delRes.text();
      console.log('[delete] status=', delRes.status, 'body=', delText);
      if (delRes.status === 404) {
        return ok({ success: true, deleted: true, note: 'already gone' });
      }
      return ok({ 
        success: delRes.ok, 
        status: delRes.status, 
        body: delText 
      });
    }

    return ok({ success: false, error: 'Unknown action' });

  } catch (error: any) {
    console.error('[edge-fn error]', error);
    // Never 500: return 200 with success:false so UI can handle it
    return ok({ 
      success: false, 
      error: String(error.message || error) 
    });
  }
};

serve(handler);