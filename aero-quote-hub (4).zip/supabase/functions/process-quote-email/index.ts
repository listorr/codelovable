import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface EmailWebhookData {
  from: string;
  to: string;
  subject: string;
  text: string;
  html?: string;
  attachments?: Array<{
    filename: string;
    content: string;
    contentType: string;
  }>;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Redirect to the new AI-powered function
    const response = await supabase.functions.invoke('process-quote-email-ai', {
      body: await req.json()
    });

    if (response.error) {
      console.error('Error calling AI function:', response.error);
      throw new Error(response.error.message);
    }

    return new Response(JSON.stringify(response.data), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("Error in process-quote-email function:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

// Helper functions for parsing email content
function extractCondition(content: string): string {
  const conditionMatch = content.match(/condition\s*:?\s*(FN|OH|SV|AR|NS|new|used|serviceable|overhauled)/i);
  if (conditionMatch) {
    const condition = conditionMatch[1].toUpperCase();
    if (['FN', 'OH', 'SV', 'AR', 'NS'].includes(condition)) return condition;
    if (condition === 'NEW') return 'FN';
    if (condition === 'SERVICEABLE') return 'SV';
    if (condition === 'OVERHAULED') return 'OH';
  }
  return 'SV'; // Default to serviceable
}

function extractPrice(priceText: string): number | null {
  if (!priceText) return null;
  const priceMatch = priceText.match(/([\d,]+\.?\d*)/);
  return priceMatch ? parseFloat(priceMatch[1].replace(/,/g, '')) : null;
}

function extractCurrency(content: string): string {
  const currencyMatch = content.match(/\b(USD|EUR|GBP|CAD)\b/i);
  return currencyMatch ? currencyMatch[1].toUpperCase() : 'USD';
}

function extractLeadTime(leadTimeText: string): number | null {
  if (!leadTimeText) return null;
  const timeMatch = leadTimeText.match(/(\d+)/);
  if (timeMatch) {
    let days = parseInt(timeMatch[1]);
    if (leadTimeText.toLowerCase().includes('week')) {
      days = days * 7;
    }
    return days;
  }
  return null;
}

function extractMOQ(content: string): number | null {
  const moqMatch = content.match(/(?:moq|minimum\s*order)\s*:?\s*(\d+)/i);
  return moqMatch ? parseInt(moqMatch[1]) : null;
}

function extractValidityDate(content: string): string | null {
  const validityMatch = content.match(/(?:valid|expires?)\s*(?:until|on)?\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i);
  if (validityMatch) {
    try {
      const dateStr = validityMatch[1];
      const date = new Date(dateStr);
      return date.toISOString();
    } catch {
      return null;
    }
  }
  // Default to 30 days from now
  const defaultDate = new Date();
  defaultDate.setDate(defaultDate.getDate() + 30);
  return defaultDate.toISOString();
}

function extractWarranty(content: string): number | null {
  const warrantyMatch = content.match(/warranty\s*:?\s*(\d+)\s*(?:months?|years?)/i);
  if (warrantyMatch) {
    let months = parseInt(warrantyMatch[1]);
    if (content.toLowerCase().includes('year')) {
      months = months * 12;
    }
    return months;
  }
  return null;
}

function extractIncoterm(content: string): string | null {
  const incotermMatch = content.match(/\b(EXW|FCA|CPT|CIP|DAT|DAP|DDP|FAS|FOB|CFR|CIF)\b/i);
  return incotermMatch ? incotermMatch[1].toUpperCase() : null;
}

function extractCertifications(content: string): string | null {
  const certMatches = content.match(/(?:cert|certificate|certification)\s*:?\s*([^\n\r]{1,200})/i);
  return certMatches ? certMatches[1].trim() : null;
}

serve(handler);