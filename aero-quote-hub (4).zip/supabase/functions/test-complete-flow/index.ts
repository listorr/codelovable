import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('[test-complete-flow] Starting complete flow test...');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // 1. Check existing subscriptions
    console.log('[test-complete-flow] 1. Checking subscriptions...');
    const subscriptionResponse = await supabase.functions.invoke('setup-graph-subscription', {
      body: { action: 'list' }
    });
    console.log('[test-complete-flow] Subscription status:', subscriptionResponse);

    // 2. Create a test RFQ if none exists
    console.log('[test-complete-flow] 2. Creating test RFQ...');
    const testRfqId = '588d0f3e-1234-5678-9abc-def012345678';
    const { data: existingRfq } = await supabase
      .from('rfqs')
      .select('*')
      .eq('id', testRfqId)
      .maybeSingle();

    if (!existingRfq) {
      const { data: newRfq, error: rfqError } = await supabase
        .from('rfqs')
        .insert({
          id: testRfqId,
          priority: 'Routine',
          status: 'open',
          notes: 'Test RFQ for email processing'
        })
        .select()
        .single();

      if (rfqError) {
        console.error('[test-complete-flow] Failed to create RFQ:', rfqError);
      } else {
        console.log('[test-complete-flow] Created test RFQ:', newRfq.id);
        
        // Add a part line
        await supabase.from('part_lines').insert({
          rfq_id: testRfqId,
          part_number: 'TEST-WIDGET-123',
          quantity: 1,
          condition_req: 'new'
        });
      }
    }

    // 3. Test the AI function directly with sample email
    console.log('[test-complete-flow] 3. Testing AI processing...');
    const testEmailData = {
      from: "luis@suatfuels.com",
      to: "rfqs@suatfuels.com", 
      subject: "Re: Routine RFQ - 1 Parts - Ref: 588D0F3E",
      text: "Hi\n\nWe have this part number TEST-WIDGET-123 available. 1000 USD each, 5 days lead-time, FOB MIAMI.\n\nBest regards,\nLuis Torrente\nManaging Director",
      html: ""
    };

    const aiResponse = await supabase.functions.invoke('process-quote-email-ai', {
      body: testEmailData
    });

    console.log('[test-complete-flow] AI processing result:', aiResponse);

    // 4. Check if quote was created
    const { data: quotes } = await supabase
      .from('quotes')
      .select('*')
      .eq('rfq_id', testRfqId)
      .order('created_at', { ascending: false })
      .limit(5);

    console.log('[test-complete-flow] Found quotes:', quotes?.length || 0);

    // 5. Test webhook simulation
    console.log('[test-complete-flow] 4. Testing webhook simulation...');
    const webhookTest = await supabase.functions.invoke('msgraph-webhook', {
      body: {
        value: [{
          subscriptionId: 'test-subscription',
          changeType: 'created',
          resource: '/users/f543917d-5e3e-44cd-8800-b9a88705dbfb/mailFolders(\'Inbox\')/messages(\'test-message-id\')',
          resourceData: {
            id: 'test-message-id'
          }
        }]
      }
    });

    console.log('[test-complete-flow] Webhook test result:', webhookTest);

    return new Response(JSON.stringify({
      success: true,
      message: 'Complete flow test completed',
      results: {
        subscription_check: subscriptionResponse,
        ai_processing: aiResponse,
        quotes_found: quotes?.length || 0,
        webhook_test: webhookTest,
        test_rfq_id: testRfqId
      }
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("[test-complete-flow] Error:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        stack: error.stack
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);