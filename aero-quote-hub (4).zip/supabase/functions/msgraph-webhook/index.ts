// supabase/functions/msgraph-webhook/index.ts
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Max-Age': '86400',
};

serve(async (req: Request): Promise<Response> => {
  const url = new URL(req.url);
  const timestamp = new Date().toISOString();
  
  // Log all requests for debugging
  console.log(`[webhook ${timestamp}] ${req.method} ${url.pathname}${url.search}`);
  console.log(`[webhook ${timestamp}] Headers:`, Object.fromEntries(req.headers.entries()));

  // Preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  try {
    // GET/POST: validación de suscripción (Graph envía ?validationToken=...)
    if (req.method === 'GET' || req.method === 'POST') {
      if (url.searchParams.has('validationToken')) {
        const token = url.searchParams.get('validationToken');
        console.log(`[webhook ${timestamp}] Validation token request:`, token);
        return new Response(token, {
          status: 200,
          headers: { 'Content-Type': 'text/plain' }
        });
      }
      if (req.method === 'GET') {
        console.log(`[webhook ${timestamp}] Health check GET request`);
        return new Response('OK', { status: 200, headers: cors });
      }
    }

    // POST: notificaciones; responde 202 rápido y procesa en background
    if (req.method === 'POST') {
      const raw = await req.text().catch(() => '');
      console.log(`[webhook ${timestamp}] Raw body:`, raw);
      
      const payload = raw ? JSON.parse(raw) : null;
      const list = Array.isArray(payload?.value) ? payload.value : [];
      
      console.log(`[webhook ${timestamp}] POST notifications count:`, list.length);
      console.log(`[webhook ${timestamp}] Notifications:`, JSON.stringify(list, null, 2));
      
      // Enhanced logging for each notification
      for (const notification of list) {
        console.log(`[webhook ${timestamp}] Notification details:`, {
          resource: notification.resource,
          resourceData: notification.resourceData,
          changeType: notification.changeType,
          clientState: notification.clientState,
          subscriptionId: notification.subscriptionId,
          subscriptionExpirationDateTime: notification.subscriptionExpirationDateTime
        });
      }

      // Log to communication_history for debugging
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
      );

      await supabase.from('communication_history').insert({
        rfq_id: null,
        supplier_id: null,
        communication_type: 'webhook_received',
        subject: `Webhook notification - ${list.length} items`,
        content: JSON.stringify(payload, null, 2),
        received_at: timestamp,
        metadata: {
          notification_count: list.length,
          notifications: list,
          timestamp: timestamp
        }
      });

      // Procesar después de responder
      queueMicrotask(async () => {
        try {
          const seen = new Set<string>();
          for (const n of list) {
            console.log(`[webhook ${timestamp}] Processing notification:`, JSON.stringify(n, null, 2));
            
            const m = (n.resource || '').match(/messages\('([^']+)'\)/);
            const messageId = n?.resourceData?.id || (m ? m[1] : null);
            
            if (!messageId || seen.has(messageId)) {
              console.log(`[webhook ${timestamp}] Skipping duplicate or invalid messageId:`, messageId);
              continue;
            }
            seen.add(messageId);

            console.log(`[webhook ${timestamp}] Invoking process-msgraph-email for messageId:`, messageId);

            // Call process-msgraph-email with POST method and proper body
            supabase.functions.invoke('process-msgraph-email', { 
              body: { messageId },
              headers: { 'Content-Type': 'application/json' }
            })
              .then(({ data, error }) => {
                if (error) {
                  console.error(`[webhook ${timestamp}] process-msgraph-email error:`, error);
                  console.error(`[webhook ${timestamp}] Error details:`, JSON.stringify(error, null, 2));
                } else {
                  console.log(`[webhook ${timestamp}] processed successfully:`, messageId);
                  console.log(`[webhook ${timestamp}] Response data:`, data);
                }
              })
              .catch((e) => {
                console.error(`[webhook ${timestamp}] invoke failed:`, e);
                console.log(`[webhook ${timestamp}] Full error details:`, JSON.stringify(e, null, 2));
              });
          }
        } catch (e) {
          console.error(`[webhook ${timestamp}] background processing error:`, e);
        }
      });

      return new Response('', { status: 202, headers: cors });
    }

    return new Response('Method not allowed', { status: 405, headers: cors });
  } catch (error: any) {
    console.error("[webhook error]", error);
    
    // Log error for debugging but still return 202 to avoid Graph retries
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    try {
      await supabase.from('communication_history').insert({
        rfq_id: null,
        supplier_id: null,
        communication_type: 'webhook_error',
        subject: 'Webhook Processing Error',
        content: error.message || 'Unknown webhook error',
        received_at: new Date().toISOString(),
        metadata: {
          error_type: 'webhook_processing',
          error_message: error.message,
          error_stack: error.stack?.substring(0, 1000),
          timestamp: new Date().toISOString()
        }
      });
    } catch (logError) {
      console.error('Failed to log webhook error:', logError);
    }
    
    // Graph no necesita 500; 202 está bien si algo falla internamente
    return new Response('', { status: 202, headers: cors });
  }
});
