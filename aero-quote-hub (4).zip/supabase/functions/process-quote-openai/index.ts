import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface QuoteItem {
  pn: string;
  status: 'AVAILABLE' | 'PARTIAL' | 'NQ' | 'OOS' | 'ALT' | 'REQUIRES_CLARIFICATION';
  price?: number;
  currency?: string;
  lead_time?: string;
  condition?: string;
  certs?: string[];
  alt_pn?: string;
  moq?: number;
  mov?: number;
  incoterms?: string;
  validity?: string;
  payment_terms?: string;
  delivery_point?: string;
  confidence_score: number;
  extraction_method: string;
  source_refs?: Array<{
    type: 'body' | 'attachment';
    name: string;
    locator: string;
  }>;
}

interface OpenAIResponse {
  rfq_id: string;
  supplier_display: string;
  items: QuoteItem[];
  globals: {
    currency?: string;
    incoterms?: string;
    validity?: string;
    payment_terms?: string;
  };
}

async function processWithOpenAI(
  rfqId: string,
  emailText: string,
  emailSubject: string,
  partNumbers: string[]
): Promise<OpenAIResponse> {
  const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!openaiApiKey) {
    throw new Error('OpenAI API key not configured');
  }

  const systemPrompt = `You are an expert at extracting structured line-by-line quotes for aircraft parts RFQs.

CRITICAL RULES:
1. Return STRICT JSON matching the provided schema
2. Never invent or hallucinate data
3. If availability differs per PN, reflect it PER LINE
4. If confidence is low (<0.7), set status=REQUIRES_CLARIFICATION
5. Never propagate global "NQ" to all lines if there are evidences per PN
6. Support mixed responses (some PNs available, others NQ/OOS)
7. Extract from tables in HTML emails when present

STATUS DEFINITIONS:
- AVAILABLE: Part available with pricing/terms
- PARTIAL: Partial quantity available 
- NQ: No quote / Cannot quote
- OOS: Out of stock
- ALT: Alternative part number offered
- REQUIRES_CLARIFICATION: Low confidence or unclear

EXTRACTION METHODS: regex, nlp, ocr, tabular

Return only valid JSON with the exact schema provided.`;

  const userPrompt = `
RFQ_ID: ${rfqId}
RFQ_PART_NUMBERS: ${JSON.stringify(partNumbers)}
EMAIL_SUBJECT: ${emailSubject}
EMAIL_TEXT:
"""
${emailText}
"""

Extract quotes following this JSON schema:
{
  "rfq_id": "${rfqId}",
  "supplier_display": "string",
  "items": [
    {
      "pn": "string",
      "status": "AVAILABLE|PARTIAL|NQ|OOS|ALT|REQUIRES_CLARIFICATION",
      "price": 0,
      "currency": "USD",
      "lead_time": "string",
      "condition": "NS|OH|AR|NE|SV",
      "certs": ["EASA Form 1", "8130-3"],
      "alt_pn": "string",
      "moq": 0,
      "mov": 0,
      "incoterms": "EXW|FCA|DAP",
      "validity": "string",
      "payment_terms": "string", 
      "delivery_point": "string",
      "confidence_score": 0.8,
      "extraction_method": "regex|nlp|ocr|tabular"
    }
  ],
  "globals": {
    "currency": "USD",
    "incoterms": "EXW",
    "validity": "string",
    "payment_terms": "string"
  }
}

Return only JSON.`;

  console.log('Calling OpenAI with model gpt-4.1-mini');

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4.1-mini-2025-04-14',
      max_completion_tokens: 2000,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ]
    })
  });

  if (!response.ok) {
    const errorData = await response.text();
    console.error('OpenAI API error:', response.status, errorData);
    throw new Error(`OpenAI API error: ${response.status} ${errorData}`);
  }

  const data = await response.json();
  console.log('OpenAI response received, parsing JSON');

  try {
    const result = JSON.parse(data.choices[0].message.content);
    console.log('OpenAI result parsed successfully:', {
      items_count: result.items?.length,
      supplier: result.supplier_display
    });
    return result;
  } catch (parseError) {
    console.error('Failed to parse OpenAI response as JSON:', parseError);
    console.error('Raw OpenAI response:', data.choices[0].message.content);
    throw new Error('OpenAI returned invalid JSON');
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const {
      rfq_id,
      supplier_id,
      email_text,
      email_subject,
      part_numbers,
      from_email,
      message_id
    } = await req.json();

    console.log('Processing quote with OpenAI for RFQ:', rfq_id);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Process with OpenAI
    const aiResult = await processWithOpenAI(
      rfq_id,
      email_text,
      email_subject,
      part_numbers
    );

    console.log('OpenAI processing complete, analyzing results');

    // Analyze if we should create a quote or just log
    const availableItems = aiResult.items.filter(item => 
      ['AVAILABLE', 'PARTIAL', 'ALT'].includes(item.status)
    );
    
    const shouldCreateQuote = availableItems.length > 0;
    
    console.log(`Analysis: ${availableItems.length}/${aiResult.items.length} items available, creating quote: ${shouldCreateQuote}`);

    // Log communication
    const { data: commData, error: commError } = await supabase
      .from('communication_history')
      .insert({
        rfq_id,
        supplier_id,
        communication_type: 'email_received',
        subject: email_subject,
        content: email_text,
        received_at: new Date().toISOString(),
        metadata: {
          from_email,
          message_id,
          ai_analysis: aiResult,
          items_available: availableItems.length,
          quote_created: shouldCreateQuote
        }
      })
      .select()
      .single();

    if (commError) {
      console.error('Failed to log communication:', commError);
      throw new Error(`Failed to log communication: ${commError.message}`);
    }

    if (shouldCreateQuote) {
      console.log('Creating quote with available items');
      
      // Create quote
      const { data: quoteData, error: quoteError } = await supabase
        .from('quotes')
        .insert({
          rfq_id,
          supplier_id,
          part_number: availableItems[0].pn, // Primary part number
          description: `Quote from ${aiResult.supplier_display}`,
          unit_price: availableItems[0].price,
          currency: availableItems[0].currency || aiResult.globals?.currency || 'USD',
          qty_available: 1, // Default, can be enhanced
          condition: availableItems[0].condition,
          lead_time_days: availableItems[0].lead_time ? parseInt(availableItems[0].lead_time) || null : null,
          moq: availableItems[0].moq || 1,
          incoterm: availableItems[0].incoterms || aiResult.globals?.incoterms,
          valid_until: availableItems[0].validity ? new Date(availableItems[0].validity).toISOString() : null,
          certs: availableItems[0].certs?.join(', '),
          delivery_point: availableItems[0].delivery_point,
          quote_status: availableItems.some(i => i.confidence_score < 0.7) ? 'needs_review' : 'pending_review',
          ai_analysis: aiResult,
          processing_status: 'processed',
          processed_at: new Date().toISOString(),
          is_relevant: true,
          relevance_score: Math.max(...availableItems.map(i => i.confidence_score)) * 100
        })
        .select()
        .single();

      if (quoteError) {
        console.error('Failed to create quote:', quoteError);
        throw new Error(`Failed to create quote: ${quoteError.message}`);
      }

      console.log('Quote created successfully:', quoteData.id);
      
      return new Response(JSON.stringify({
        success: true,
        quote_created: true,
        quote_id: quoteData.id,
        communication_id: commData.id,
        items_processed: aiResult.items.length,
        items_available: availableItems.length,
        ai_analysis: aiResult
      }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });

    } else {
      console.log('No quote created - all items NQ/OOS');
      
      return new Response(JSON.stringify({
        success: true,
        quote_created: false,
        communication_id: commData.id,
        reason: 'All items NQ/OOS',
        items_processed: aiResult.items.length,
        ai_analysis: aiResult
      }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

  } catch (error: any) {
    console.error("Error in process-quote-openai:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);