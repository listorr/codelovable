import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EmailWebhookData {
  from: string;
  to: string;
  subject: string;
  text: string;
  html: string;
  attachments?: Array<{
    filename: string;
    content: string;
    contentType: string;
  }>;
}

interface AIAnalysisResult {
  isRelevant: boolean;
  relevanceScore: number;
  hasPrice: boolean;
  hasAvailability: boolean;
  hasCommercialTerms: boolean;
  isNegativeResponse: boolean;
  extractedData: {
    items: string[];
    prices: string[];
    dates: string[];
    rates: string[];
    leadTimes?: string[];
    availability?: string;
    conditions?: string[];
  };
  reasoning: string;
}

const analyzeEmailWithAI = async (subject: string, content: string): Promise<AIAnalysisResult> => {
  const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!openaiApiKey) {
    console.error('OpenAI API key not found');
    return {
      isRelevant: true, // Default to relevant if AI fails
      relevanceScore: 50,
      hasPrice: false,
      hasAvailability: false,
      hasCommercialTerms: false,
      isNegativeResponse: false,
      extractedData: {
        items: [],
        prices: [],
        dates: [],
        rates: []
      },
      reasoning: 'AI analysis failed - defaulting to relevant'
    };
  }

  const prompt = `Analyze this aviation parts quote email and extract key commercial information.

Subject: ${subject}
Content: ${content}

Extract data and classify this email response:

1. Items/parts mentioned (specific part numbers, descriptions)
2. Pricing information (prices, rates, fees)
3. Dates (delivery dates, lead times, valid until dates)
4. Commercial rates (discount rates, markup rates, tax rates)
5. Determine if this is a relevant commercial response

Focus on extracting:
- Specific items/parts quoted
- All prices with currencies
- All dates mentioned (delivery, lead time, expiration)
- Any percentage rates mentioned

Respond in JSON format:
{
  "isRelevant": boolean,
  "relevanceScore": number (0-100),
  "hasPrice": boolean,
  "hasAvailability": boolean,
  "hasCommercialTerms": boolean,
  "isNegativeResponse": boolean,
  "extractedData": {
    "items": ["Widget", "Part ABC123"],
    "prices": ["$95", "$1,200 USD", "€1,000 EUR"],
    "dates": ["3 días", "5-7 days", "2025-09-15"],
    "rates": ["5%", "8% tax", "12% discount"]
  },
  "reasoning": "Brief explanation of the classification"
}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are an expert in aviation parts procurement and supply chain management. Analyze emails to determine if they contain relevant commercial quotes for aircraft parts.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 1000
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const analysisText = data.choices[0].message.content;
    
    try {
      return JSON.parse(analysisText);
    } catch (parseError) {
      console.error('Failed to parse AI response:', analysisText);
      // Fallback analysis
      return {
        isRelevant: !content.toLowerCase().match(/(no quote|nq|not available|out of stock|cannot quote)/),
        relevanceScore: 50,
        hasPrice: /(\$|USD|EUR|price|cost|\d+\.\d+)/.test(content),
        hasAvailability: /(available|in stock|lead time|delivery)/.test(content.toLowerCase()),
        hasCommercialTerms: /(warranty|incoterm|moq|terms)/.test(content.toLowerCase()),
        isNegativeResponse: /(no quote|nq|not available|out of stock)/.test(content.toLowerCase()),
        extractedData: {
          items: [],
          prices: [],
          dates: [],
          rates: []
        },
        reasoning: 'AI response parsing failed - used fallback analysis'
      };
    }
  } catch (error) {
    console.error('AI analysis failed:', error);
    // Fallback to basic pattern matching
    return {
      isRelevant: !content.toLowerCase().match(/(no quote|nq|not available|out of stock|cannot quote)/),
      relevanceScore: 50,
      hasPrice: /(\$|USD|EUR|price|cost|\d+\.\d+)/.test(content),
      hasAvailability: /(available|in stock|lead time|delivery)/.test(content.toLowerCase()),
      hasCommercialTerms: /(warranty|incoterm|moq|terms)/.test(content.toLowerCase()),
      isNegativeResponse: /(no quote|nq|not available|out of stock)/.test(content.toLowerCase()),
      extractedData: {
        items: [],
        prices: [],
        dates: [],
        rates: []
      },
      reasoning: 'AI analysis failed - used pattern matching fallback'
    };
  }
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const emailData: EmailWebhookData = await req.json();
    console.log('Processing email from:', emailData.from);

    // Extract RFQ reference from subject (supports both "RFQ-XXXXXXXX" and "Ref: XXXXXXXX")
    const rfqMatch = emailData.subject.match(/(?:RFQ[_\-\s]*|Ref:\s*)([A-Z0-9]{8})/i);
    console.log(`Analyzing subject: "${emailData.subject}"`);
    console.log(`RFQ regex match result:`, rfqMatch);
    if (!rfqMatch) {
      console.log('No RFQ reference found in subject:', emailData.subject);
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'No RFQ reference found' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const rfqReference = rfqMatch[1].toLowerCase();
    console.log('Found RFQ reference:', rfqReference);

    // Find RFQ by reference (last 8 chars of ID) - case insensitive
    console.log(`Looking for RFQ with reference: ${rfqReference}`);
    const { data: rfq, error: rfqError } = await supabase
      .from('rfqs')
      .select('*')
      .filter('id', 'ilike', `%${rfqReference}`)
      .maybeSingle();

    if (rfqError || !rfq) {
      console.error('RFQ not found for reference:', rfqReference, 'Error:', rfqError);
      
      // Log the communication even if RFQ not found
      await supabase.from('communication_history').insert({
        rfq_id: null,
        supplier_id: null,
        communication_type: 'unmatched_email',
        subject: emailData.subject,
        content: emailData.text || emailData.html,
        received_at: new Date().toISOString(),
        metadata: {
          email_from: emailData.from,
          rfq_reference: rfqReference,
          error: 'RFQ not found'
        }
      });
      
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'RFQ not found',
        rfq_reference: rfqReference
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Find supplier by email (using ANY to check if email exists in array)
    const { data: suppliers, error: supplierError } = await supabase
      .from('suppliers')
      .select('*')
      .filter('emails', 'cs', `{${emailData.from}}`);
    
    let supplier = suppliers?.[0];
    
    if (supplierError || !supplier) {
      console.log(`Supplier not found for email: ${emailData.from}, creating new supplier`);
      
      // Create new supplier
      const { data: newSupplier, error: createError } = await supabase
        .from('suppliers')
        .insert({
          name: emailData.from.split('@')[0],
          emails: [emailData.from],
          active: true,
          opt_out: false
        })
        .select()
        .maybeSingle();
        
      if (createError) {
        console.error('Failed to create supplier:', createError);
        return new Response(JSON.stringify({ 
          success: false, 
          message: 'Failed to create supplier',
          error: createError.message
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      supplier = newSupplier;
      console.log('Created new supplier:', supplier.name);
    }

    console.log('Found supplier:', supplier.name);

    // Analyze email content with AI
    const aiAnalysis = await analyzeEmailWithAI(emailData.subject, emailData.text || emailData.html);
    console.log('AI Analysis result:', aiAnalysis);

    // Only process if relevant (or if AI analysis failed)
    if (!aiAnalysis.isRelevant && aiAnalysis.relevanceScore < 30) {
      console.log('Email marked as not relevant, skipping quote creation');
      
      // Still log the communication
      await supabase.from('communication_history').insert({
        rfq_id: rfq.id,
        supplier_id: supplier.id,
        communication_type: 'quote_received',
        subject: emailData.subject,
        content: emailData.text || emailData.html,
        received_at: new Date().toISOString(),
        metadata: {
          ai_analysis: aiAnalysis,
          email_from: emailData.from,
          marked_as_irrelevant: true
        }
      });

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Email processed but marked as not relevant',
        analysis: aiAnalysis
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Extract part number from RFQ
    const { data: partLines } = await supabase
      .from('part_lines')
      .select('part_number')
      .eq('rfq_id', rfq.id)
      .limit(1);

    const partNumber = partLines && partLines.length > 0 ? partLines[0].part_number : 'Unknown';

    // Create quote with AI analysis
    const quoteData = {
      rfq_id: rfq.id,
      supplier_id: supplier.id,
      part_number: partNumber,
      description: aiAnalysis.extractedData.conditions?.join(', ') || 'AI processed quote',
      processing_status: 'processed',
      relevance_score: aiAnalysis.relevanceScore,
      ai_analysis: aiAnalysis,
      quote_status: 'pending_review',
      is_relevant: aiAnalysis.isRelevant,
      processed_at: new Date().toISOString(),
      // Extract pricing if available
      unit_price: aiAnalysis.extractedData.prices?.[0]?.match(/[\d,]+\.?\d*/)?.[0] ? 
        parseFloat(aiAnalysis.extractedData.prices[0].match(/[\d,]+\.?\d*/)[0].replace(/,/g, '')) : null,
      currency: aiAnalysis.extractedData.prices?.[0]?.match(/(USD|EUR|GBP)/)?.[0] || 'USD',
      // Extract lead time if available
      lead_time_days: aiAnalysis.extractedData.leadTimes?.[0]?.match(/\d+/)?.[0] ? 
        parseInt(aiAnalysis.extractedData.leadTimes[0].match(/\d+/)[0]) : null,
      score: Math.round(aiAnalysis.relevanceScore)
    };

    const { data: quote, error: quoteError } = await supabase
      .from('quotes')
      .insert(quoteData)
      .select()
      .maybeSingle();

    if (quoteError) {
      console.error('Error creating quote:', quoteError);
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Failed to create quote',
        error: quoteError.message
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Log communication history
    await supabase.from('communication_history').insert({
      rfq_id: rfq.id,
      supplier_id: supplier.id,
      communication_type: 'quote_received',
      subject: emailData.subject,
      content: emailData.text || emailData.html,
      received_at: new Date().toISOString(),
      metadata: {
        quote_id: quote.id,
        ai_analysis: aiAnalysis,
        email_from: emailData.from,
        processed_successfully: true
      }
    });

    // Update email thread
    await supabase
      .from('email_threads')
      .update({ last_message_at: new Date().toISOString() })
      .eq('rfq_id', rfq.id)
      .eq('supplier_id', supplier.id);

    console.log('Quote processed successfully:', quote.id);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Quote processed successfully',
      quote_id: quote.id,
      analysis: aiAnalysis
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error processing email:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      message: 'Internal server error',
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
};

serve(handler);