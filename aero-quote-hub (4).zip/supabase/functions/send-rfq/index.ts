import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendRFQRequest {
  rfq_id: string;
  supplier_ids: string[];
  message?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { rfq_id, supplier_ids, message }: SendRFQRequest = await req.json();

    console.log(`Processing RFQ ${rfq_id} for ${supplier_ids.length} suppliers`);

    // Get RFQ details
    const { data: rfq, error: rfqError } = await supabase
      .from('rfqs')
      .select(`
        *,
        part_lines (*)
      `)
      .eq('id', rfq_id)
      .single();

    if (rfqError || !rfq) {
      throw new Error('RFQ not found');
    }

    // Get supplier details
    const { data: suppliers, error: suppliersError } = await supabase
      .from('suppliers')
      .select('*')
      .in('id', supplier_ids)
      .eq('active', true)
      .eq('opt_out', false);

    if (suppliersError || !suppliers) {
      throw new Error('Suppliers not found');
    }

    // Get email configuration
    const { data: emailConfig, error: emailConfigError } = await supabase
      .from('email_config')
      .select('from_email, from_name')
      .limit(1)
      .single();

    if (emailConfigError) {
      console.warn('Email config not found, using default');
    }

    const fromEmail = emailConfig?.from_email || 'rfqs@suatfuels.com';
    const fromName = emailConfig?.from_name || 'AeroSourcing';

    const emailPromises = suppliers.map(async (supplier) => {
      try {
        // Generate part lines table
        const partLinesHTML = rfq.part_lines?.map((part: any) => `
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">${part.part_number}</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${part.quantity}</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${part.condition_req || 'Any'}</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${part.notes || '-'}</td>
          </tr>
        `).join('') || '';

        const emailHTML = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #2563eb;">Request for Quotation - ${rfq.priority} Priority</h2>
            
            <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3>RFQ Details</h3>
              <p><strong>Aircraft Type:</strong> ${rfq.aircraft_type || 'Not specified'}</p>
              <p><strong>Delivery Location:</strong> ${rfq.delivery_to || 'Not specified'}</p>
              <p><strong>Deadline:</strong> ${rfq.deadline ? new Date(rfq.deadline).toLocaleDateString() : 'Not specified'}</p>
              <p><strong>Priority:</strong> <span style="background-color: ${rfq.priority === 'AOG' ? '#dc2626' : rfq.priority === 'Routine' ? '#2563eb' : '#16a34a'}; color: white; padding: 2px 8px; border-radius: 4px;">${rfq.priority}</span></p>
            </div>

            ${message ? `
            <div style="background-color: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <h4>Additional Message:</h4>
              <p>${message}</p>
            </div>
            ` : ''}

            <h3>Parts Required</h3>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
              <thead>
                <tr style="background-color: #f1f5f9;">
                  <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Part Number</th>
                  <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Quantity</th>
                  <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Condition</th>
                  <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Notes</th>
                </tr>
              </thead>
              <tbody>
                ${partLinesHTML}
              </tbody>
            </table>

            ${rfq.notes ? `
            <div style="margin: 20px 0;">
              <h4>Additional Notes:</h4>
              <p style="background-color: #f8fafc; padding: 15px; border-radius: 8px;">${rfq.notes}</p>
            </div>
            ` : ''}

            <div style="background-color: #dc2626; color: white; padding: 20px; border-radius: 8px; margin: 30px 0;">
              <h3 style="margin: 0 0 10px 0;">How to Respond</h3>
              <p style="margin: 0;">Please reply to this email with your quotation including:</p>
              <ul style="margin: 10px 0;">
                <li>Part availability and condition</li>
                <li>Unit price and currency</li>
                <li>Lead time</li>
                <li>Minimum order quantity (MOQ)</li>
                <li>Validity period</li>
                <li>Warranty information</li>
                <li>Delivery terms (Incoterms)</li>
              </ul>
              <p style="margin: 0;"><strong>Reference ID:</strong> RFQ-${rfq_id.slice(-8).toUpperCase()}</p>
            </div>

            <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666;">
              <p>AeroSourcing Platform - Aviation Parts RFQ Management</p>
            </div>
          </div>
        `;

        // Send email to each supplier email
        const emailTasks = supplier.emails.map(async (email: string) => {
          const emailResponse = await resend.emails.send({
            from: `${fromName} <${fromEmail}>`,
            to: [email],
            subject: `${rfq.priority} RFQ - ${rfq.part_lines?.length || 0} Parts - Ref: ${rfq_id.slice(-8).toUpperCase()}`,
            html: emailHTML,
          });

          console.log(`Email sent to ${email}:`, emailResponse);
          return emailResponse;
        });

        await Promise.all(emailTasks);

        // Create email thread record
        await supabase
          .from('email_threads')
          .insert({
            rfq_id: rfq_id,
            supplier_id: supplier.id,
            subject: `${rfq.priority} RFQ - ${rfq.part_lines?.length || 0} Parts`,
            last_message_at: new Date().toISOString(),
          });

        return { supplier_id: supplier.id, status: 'sent', emails_sent: supplier.emails.length };
      } catch (error) {
        console.error(`Error sending email to supplier ${supplier.id}:`, error);
        return { supplier_id: supplier.id, status: 'failed', error: error.message };
      }
    });

    const results = await Promise.all(emailPromises);
    const successCount = results.filter(r => r.status === 'sent').length;
    const failCount = results.filter(r => r.status === 'failed').length;

    console.log(`RFQ ${rfq_id} sent: ${successCount} successful, ${failCount} failed`);

    return new Response(JSON.stringify({
      success: true,
      results,
      summary: {
        total_suppliers: suppliers.length,
        successful_sends: successCount,
        failed_sends: failCount
      }
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("Error in send-rfq function:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);