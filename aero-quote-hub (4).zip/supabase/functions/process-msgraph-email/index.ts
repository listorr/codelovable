import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

async function getGraphToken() {
  const tenantId = Deno.env.get('MS_TENANT_ID');
  const clientId = Deno.env.get('MS_CLIENT_ID');
  const clientSecret = Deno.env.get('MS_CLIENT_SECRET');
  console.log('[process-msgraph-email] Secrets status:', {
    tenantId: tenantId ? 'OK' : 'MISSING',
    clientId: clientId ? 'OK' : 'MISSING',
    clientSecret: clientSecret ? 'OK' : 'MISSING'
  });
  if (!tenantId || !clientId || !clientSecret) {
    throw new Error('Missing secrets: MS_TENANT_ID, MS_CLIENT_ID, or MS_CLIENT_SECRET');
  }
  const tokenUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: clientId,
      client_secret: clientSecret,
      scope: 'https://graph.microsoft.com/.default'
    })
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(`Failed to get token: ${JSON.stringify(data)}`);
  }
  return data.access_token;
}

async function getEmailDetails(messageId, token) {
  const userId = Deno.env.get('GRAPH_USER_ID') || 'f543917d-5e3e-44cd-8800-b9a88705dbfb';
  const graphUrl = `https://graph.microsoft.com/v1.0/users/${userId}/messages/${messageId}?$select=from,subject,body,internetMessageId,conversationId,toRecipients,ccRecipients,receivedDateTime,hasAttachments,internetMessageHeaders`;
  console.log(`[process-msgraph-email] Fetching email from Graph API: ${graphUrl}`);
  const response = await fetch(graphUrl, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });
  if (!response.ok) {
    const errorData = await response.text();
    console.error(`[process-msgraph-email] Graph API error: ${response.status} ${errorData}`);
    throw new Error(`Failed to get email: ${response.status} ${errorData}`);
  }
  const emailData = await response.json();
  console.log(`[process-msgraph-email] Email data received:`, {
    id: emailData.id,
    subject: emailData.subject,
    from: emailData.from?.emailAddress?.address,
    receivedDateTime: emailData.receivedDateTime
  });
  return emailData;
}

function extractRfqId(email) {
  for (const recipient of email.toRecipients){
    const emailAddr = recipient.emailAddress.address.toLowerCase();
    const match = emailAddr.match(/rfqs\+rfq([a-f0-9-]+)@suatfuels\.com/);
    if (match) {
      return match[1];
    }
  }
  const subject = email.subject || '';
  const subjectMatches = [
    /ref:\s*([a-f0-9-]+)/i,
    /rfq\s*#?\s*([a-f0-9-]+)/i,
    /reference:\s*([a-f0-9-]+)/i
  ];
  for (const regex of subjectMatches){
    const match = subject.match(regex);
    if (match) {
      return match[1];
    }
  }
  const inReplyTo = email.internetMessageHeaders?.find((h)=>h.name.toLowerCase() === 'in-reply-to')?.value;
  if (inReplyTo) {
    const match = inReplyTo.match(/rfq-([a-f0-9-]+)/i);
    if (match) {
      return match[1];
    }
  }
  // Añadido: más regex para body
  const body = email.body.content || '';
  const bodyMatch = body.match(/(?:ref|rfq|reference)[:#\s]*([a-f0-9]{8})/i);
  if (bodyMatch) {
    return bodyMatch[1].toLowerCase();
  }
  return null;
}

function cleanEmailText(email) {
  let content = email.body.content;
  if (email.body.contentType === 'html') {
    content = content.replace(/<style[^>]*>[^<]*<\/style>/gi, '')
    .replace(/<script[^>]*>[^<]*<\/script>/gi, '')
    .replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"');
  }
  content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n+/g, '\n').replace(/[ \t]+/g, ' ').trim();
  return content;
}

const handler = async (req) => {
  console.log(`[process-msgraph-email] Function called with method: ${req.method}`);
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  if (req.method === 'GET') {
    return new Response('Method Not Allowed: Use POST with { messageId } body', { status: 405, headers: corsHeaders });
  }
  try {
    // Try-catch para req.json() para evitar crash en body inválido
    let body;
    try {
      body = await req.json();
    } catch (e) {
      throw new Error('Invalid JSON body. Expect POST with { messageId }');
    }
    const { messageId } = body;
    if (!messageId) {
      throw new Error('Missing messageId in body');
    }
    console.log(`[process-msgraph-email] Processing email message ID: ${messageId}`);
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const token = await getGraphToken(); // Ahora llega aquí
    const emailData = await getEmailDetails(messageId, token);
    console.log('Email fetched:', {
      subject: emailData.subject,
      from: emailData.from.emailAddress.address,
      to: emailData.toRecipients.map((r)=>r.emailAddress.address),
      messageId: emailData.id,
      internetMessageId: emailData.internetMessageId,
      conversationId: emailData.conversationId,
      headers: emailData.internetMessageHeaders?.map((h)=>`${h.name}: ${h.value.substring(0, 50)}...`)
    });
    let rfqId = extractRfqId(emailData);
    if (!rfqId) {
      const emailContent = cleanEmailText(emailData);
      const contentMatch = emailContent.match(/(?:ref|rfq|reference)[:#\s]*([a-f0-9]{8})/i);
      if (contentMatch) {
        rfqId = contentMatch[1].toLowerCase();
        console.log('RFQ ID found in email content:', rfqId);
      }
    }
    console.log('Final extracted RFQ ID:', rfqId);
    if (!rfqId) {
      console.log('No RFQ ID found, logging as unmatched email');
      const inReplyTo = emailData.internetMessageHeaders?.find((h)=>h.name.toLowerCase() === 'in-reply-to')?.value;
      const references = emailData.internetMessageHeaders?.find((h)=>h.name.toLowerCase() === 'references')?.value;
      console.log('Email headers analysis:', {
        inReplyTo: inReplyTo?.substring(0, 100),
        references: references?.substring(0, 100),
        conversationId: emailData.conversationId
      });
      const { error } = await supabase.from('communication_history').insert({
        rfq_id: null,
        supplier_id: null,
        communication_type: 'email_received',
        subject: emailData.subject,
        content: cleanEmailText(emailData),
        sent_at: null,
        received_at: emailData.receivedDateTime,
        metadata: {
          from_email: emailData.from.emailAddress.address,
          from_name: emailData.from.emailAddress.name,
          message_id: emailData.id,
          internet_message_id: emailData.internetMessageId,
          conversation_id: emailData.conversationId,
          in_reply_to: inReplyTo,
          references: references,
          unmatched_rfq: true,
          analysis: 'No RFQ ID found in subject, content, or headers'
        }
      });
      if (error) console.error('Insert to communication_history failed:', error);
      return new Response(JSON.stringify({
        success: true,
        message: 'Email logged as unmatched (no RFQ ID found)',
        rfq_id: null,
        headers_analyzed: true
      }), {
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders
        }
      });
    }
    let { data: rfqData, error: rfqError } = await supabase.from('rfqs').select(`
        *,
        part_lines (
          part_number,
          quantity,
          condition_req
        )
      `).filter('id', 'ilike', `%${rfqId}%`).maybeSingle();
    if (!rfqData && rfqId.length >= 32) {
      const { data: exactMatch, error: exactError } = await supabase.from('rfqs').select(`
          *,
          part_lines (
            part_number,
            quantity,
            condition_req
          )
        `).eq('id', rfqId).maybeSingle();
      rfqData = exactMatch;
      rfqError = exactError;
    }
    if (rfqError || !rfqData) {
      console.error('RFQ not found for reference:', rfqId, 'Error:', rfqError);
      if (rfqId.length >= 32) {
        const { data: exactRfq, error: exactError } = await supabase.from('rfqs').select(`
            *,
            part_lines (
              part_number,
              quantity,
              condition_req
            )
          `).eq('id', rfqId).maybeSingle();
        if (exactError || !exactRfq) {
          console.error('RFQ not found by exact ID either:', rfqId);
        } else {
          rfqData = exactRfq;
          console.log('Found RFQ by exact ID match');
        }
      }
      if (!rfqData) {
        const { error } = await supabase.from('communication_history').insert({
          rfq_id: null,
          supplier_id: null,
          communication_type: 'email_received',
          subject: emailData.subject,
          content: cleanEmailText(emailData),
          sent_at: null,
          received_at: emailData.receivedDateTime,
          metadata: {
            from_email: emailData.from.emailAddress.address,
            from_name: emailData.from.emailAddress.name,
            message_id: emailData.id,
            internet_message_id: emailData.internetMessageId,
            invalid_rfq_id: rfqId,
            rfq_search_attempted: true
          }
        });
        if (error) console.error('Insert to communication_history failed:', error);
        return new Response(JSON.stringify({
          success: false,
          error: 'RFQ not found',
          rfq_id: rfqId,
          search_attempted: true
        }), {
          status: 404,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders
          }
        });
      }
    }
    const fromEmail = emailData.from.emailAddress.address;
    let { data: supplierData, error: supplierError } = await supabase.from('suppliers').select('id').contains('emails', [
      fromEmail
    ]).single();
    if (supplierError || !supplierData) {
      console.log('Supplier not found, creating new supplier');
      const { data: newSupplier, error: createSupplierError } = await supabase.from('suppliers').insert({
        name: emailData.from.emailAddress.name || fromEmail.split('@')[0],
        emails: [
          fromEmail
        ],
        contact_name: emailData.from.emailAddress.name
      }).select('id').single();
      if (createSupplierError) {
        throw new Error(`Failed to create supplier: ${createSupplierError.message}`);
      }
      supplierData = newSupplier;
    }
    console.log('Using supplier:', supplierData.id);
    const emailText = cleanEmailText(emailData);
    const partNumbers = rfqData.part_lines.map((pl)=>pl.part_number);
    console.log('Preparing AI processing:', {
      rfq_id: rfqId,
      supplier_id: supplierData.id,
      part_numbers: partNumbers,
      email_length: emailText.length,
      email_preview: emailText.substring(0, 200) + '...'
    });
    console.log('Invoking process-quote-email-ai function...');
    const { data: aiResult, error: aiError } = await supabase.functions.invoke('process-quote-email-ai', {
      body: {
        from: emailData.from.emailAddress.address,
        to: "rfqs@suatfuels.com",
        subject: emailData.subject,
        text: emailText,
        html: emailData.body.contentType === 'html' ? emailData.body.content : '',
        rfq_id: rfqId,
        supplier_id: supplierData.id,
        part_numbers: partNumbers,
        message_id: emailData.id,
        internet_message_id: emailData.internetMessageId
      }
    });
    if (aiError) {
      console.error('AI processing failed:', aiError);
      const { error: historyError } = await supabase.from('communication_history').insert({
        rfq_id: rfqData.id,
        supplier_id: supplierData.id,
        communication_type: 'quote_processing_failed',
        subject: emailData.subject,
        content: emailText,
        received_at: emailData.receivedDateTime,
        metadata: {
          from_email: emailData.from.emailAddress.address,
          from_name: emailData.from.emailAddress.name,
          message_id: emailData.id,
          ai_error: aiError.message || 'Unknown AI processing error',
          processing_failed: true
        }
      });
      if (historyError) console.error('Insert to communication_history failed:', historyError);
      throw new Error(`AI processing failed: ${aiError.message}`);
    }
    console.log('AI processing completed successfully:', aiResult);
    return new Response(JSON.stringify({
      success: true,
      message: 'Email processed successfully',
      rfq_id: rfqId,
      supplier_id: supplierData.id,
      ai_result: aiResult,
      processing_details: {
        email_subject: emailData.subject,
        from_email: emailData.from.emailAddress.address,
        part_numbers: partNumbers,
        email_length: emailText.length
      }
    }), {
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders
      }
    });
  } catch (error) {
    console.error("[process-msgraph-email] Error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders
      }
    });
  }
};

serve(handler);